class Custom
{
	class Bootstrap
	{
		file="Custom";
		class preInit
		{
			preInit = 1;
		};
	};
};