class MakeCamera: Exile_AbstractCraftingRecipe
{
	name = "Камера";
	pictureItem = "Exile_Item_BaseCameraKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] =
	{
		{1, "Exile_Item_BaseCameraKit"}
	};
	components[] = 
	{		
		{1, "Exile_Item_CodeLock"},
		{1, "Exile_Item_DuctTape"},
		{2, "Exile_Item_ExtensionCord"},
		{4, "Exile_Item_MetalPole"},
		{4, "Exile_Item_PlasticBottleEmpty"}
	};
};

class MakeLaptop: Exile_AbstractCraftingRecipe
{
	name = "Ноутбук";
	pictureItem = "Exile_Item_Laptop";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] =
	{
		{1, "Exile_Item_Laptop"}
	};
	components[] = 
	{
		{1, "Exile_Item_CodeLock"},
		{1, "Exile_Item_DuctTape"},
		{2, "Exile_Item_ExtensionCord"},
		{2, "Exile_Item_MetalPole"},
		{4, "Exile_Item_PlasticBottleEmpty"}
	};
};

class Exile_melee_Axe: Exile_AbstractCraftingRecipe
{
    name = "Топор";
    pictureItem = "Exile_melee_Axe";
    requiresFire = 1;
    requiredInteractionModelGroup = "WorkBench";
    returnedItems[] =
    {
        {1, "Exile_melee_Axe"}
    };
    components[] =
    {
        {2, "Exile_Item_JunkMetal"},
        {1, "Exile_Item_WoodLog"}
    };
};

class Exile_Item_JunkMetal: Exile_AbstractCraftingRecipe
{
    name = "Металлолом";
    pictureItem = "Exile_Item_JunkMetal";
    tools[] = {"Exile_Item_Pliers","Exile_Item_Grinder"};
    requiredInteractionModelGroup = "WorkBench";
    returnedItems[] =
    {
        {1, "Exile_Item_JunkMetal"}
    };
    components[] =
    {
        {10, "Exile_Item_Can_Empty"}
    };
};

class Exile_Item_MetalBoard: Exile_AbstractCraftingRecipe
{
    name = "Лист Металла";
    pictureItem = "Exile_Item_MetalBoard";
    tools[] = {"Exile_Item_Pliers","Exile_Item_Grinder"};
    requiredInteractionModelGroup = "WorkBench";
    returnedItems[] =
    {
        {1, "Exile_Item_MetalBoard"}
    };
    components[] =
    {
        {2, "Exile_Item_FuelCanisterEmpty"}
    };
};
class CraftGrenade: Exile_AbstractCraftingRecipe
{
	name = "Граната";
	pictureItem = "HandGrenade";
	requiredInteractionModelGroup = "WorkBench";
	tools[] = {"Exile_Item_Pliers"};
	returnedItems[] = 
	{
		{1, "HandGrenade"}
	};
	components[] = 
	{
		{1, "Exile_Item_PlasticBottleEmpty"},		
		{1, "Exile_Item_Matches"},
		{1, "5Rnd_127x108_Mag"},
		{1, "Exile_Item_JunkMetal"}
	};
};
class CraftCanOpener: Exile_AbstractCraftingRecipe
{
	name = "Консервный Нож";
	pictureItem = "Exile_Item_CanOpener";
	requiredInteractionModelGroup = "WorkBench";
	tools[] = {"Exile_Item_Pliers","Exile_Item_Grinder"};
	returnedItems[] = 
	{
		{1, "Exile_Item_CanOpener"}
	};
	components[] = 
	{
		{1, "Exile_Item_MetalBoard"}		
	};
};
class CraftCookingPot: Exile_AbstractCraftingRecipe
{
	name = "Котелок";
	pictureItem = "Exile_Item_CookingPot";
	requiredInteractionModelGroup = "WorkBench";
	tools[] = {"Exile_Item_Grinder"};	
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "Exile_Item_CookingPot"}
	};
	components[] = 
	{
		{3, "Exile_Item_MetalBoard"}
	};
};

class Exile_Item_MetalScrews: Exile_AbstractCraftingRecipe
{
    name = "Саморезы";
    pictureItem = "Exile_Item_MetalScrews";
    // // requiresFire = 1;
    requiredInteractionModelGroup = "WorkBench";
    returnedItems[] =
    {
        {3, "Exile_Item_MetalScrews"}
    };
	tools[] =
	{
		"Exile_Item_Grinder"
	};
    components[] =
    {
        {1, "Exile_Item_MetalWire"},
		{3, "Exile_Item_JunkMetal"}
    };
};
class SatchelCharge_Remote_Mag: Exile_AbstractCraftingRecipe
{
    name = "Подрывной заряд";
    pictureItem = "SatchelCharge_Remote_Mag";
    // // requiresFire = 1;
    requiredInteractionModelGroup = "WorkBench";
    returnedItems[] =
    {
        {1, "SatchelCharge_Remote_Mag"}
    };
	tools[] =
	{
		"Exile_Item_Hammer"
	};
    components[] =
    {
        {1, "IEDLandSmall_Remote_Mag"},
		{1, "Exile_Item_MetalScrews"},
		{1, "Exile_Item_Can_Empty"},
		{1, "Laserbatteries"},
		{1, "Exile_Item_DuctTape"}
		
    };
};
class Exile_Item_CookingPot: Exile_AbstractCraftingRecipe
{
    name = "Самодельная печка";
    pictureItem = "Exile_Item_CookingPot";
    // requiresFire = 1;
    requiredInteractionModelGroup = "WorkBench";
    returnedItems[] =
    {
        {1, "Exile_Item_CookingPot"}
    };
    components[] =
    {
        {2, "Exile_Item_Junkmetal"}
    };
};
class Exile_Item_SafeKit: Exile_AbstractCraftingRecipe
{
    name = "Самодельный сейф";
    pictureItem = "Exile_Item_SafeKit";
    // requiresFire = 1;
    requiredInteractionModelGroup = "WorkBench";
    returnedItems[] =
    {
        {1, "Exile_Item_SafeKit"}
    };
    components[] =
    {
        {2, "Exile_Item_MetalPole"},
        {4, "Exile_Item_MetalBoard"},
        {1, "Exile_Item_Codelock"}
    };
};
class Exile_Item_CamoTentKit: Exile_AbstractCraftingRecipe
{
    name = "Тент камо";
    pictureItem = "Exile_Item_CamoTentKit";
    // requiresFire = 1;
    requiredInteractionModelGroup = "WorkBench";
    returnedItems[] =
    {
        {1, "Exile_Item_CamoTentKit"}
    };
    components[] =
    {
        {2, "Exile_Item_DuctTape"},
        {4, "Exile_Item_WoodPlank"},
        {2, "Exile_Item_Rope"}
    };
};
class HandMadeAspirin: Exile_AbstractCraftingRecipe
{
	name = "Болеутоляющее";
	pictureItem = "Exile_Item_Vishpirin";
	//requiresFire = 0;
	returnedItems[] =
	{
		{1, "Exile_Item_Vishpirin"}
	};
	tools[] =
	{
		
	};
	components[] = 
	{
		{1, "Exile_Item_Bandage"},
		{1, "Exile_Item_Beer"},
		{1, "Exile_Item_Can_Empty"}
	};
};
class HandMadeInstaDoc: Exile_AbstractCraftingRecipe
{
	name = "Аптечка";
	pictureItem = "Exile_Item_InstaDoc";
	//requiresFire = 0;
	returnedItems[] =
	{
		{1, "Exile_Item_InstaDoc"}
	};
	tools[] =
	{
		
	};
	components[] = 
	{
		{2, "Exile_Item_Bandage"},
		{1, "Exile_Item_Vishpirin"},
		{1, "Exile_Item_Beer"},
		{1, "Exile_Item_Can_Empty"}
	};
};

class BreachingChargeMetal: Exile_AbstractCraftingRecipe
{
	name = "Breaching Charge (Metal)";
	pictureItem = "Exile_Item_BreachingCharge_Metal";
	returnedItems[] =
	{
		{1, "Exile_Item_BreachingCharge_Metal"}
	};
	tools[] =
	{
		"Exile_Item_Foolbox"
	};
	components[] = 
	{
		{1, "Exile_Item_DuctTape"},
		{1, "SatchelCharge_Remote_Mag"}
	};
};

class BreachingChargeWood: Exile_AbstractCraftingRecipe
{
	name = "Breaching Charge (Wood)";
	pictureItem = "Exile_Item_BreachingCharge_Wood";
	returnedItems[] =
	{
		{1, "Exile_Item_BreachingCharge_Wood"}
	};
	tools[] =
	{
		"Exile_Item_Foolbox"
	};
	components[] = 
	{
		{1, "Exile_Item_DuctTape"},
		{1, "DemoCharge_Remote_Mag"}
	};
};

class CookBBQSandwich: Exile_AbstractCraftingRecipe
{
	name = "Cook BBQ Sandwich";
	pictureItem = "Exile_Item_BBQSandwich_Cooked";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "Exile_Item_BBQSandwich_Cooked"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot"
	};
	components[] = 
	{
		{1, "Exile_Item_BBQSandwich"}
	};
};

class CookCatFood: Exile_AbstractCraftingRecipe
{
	name = "Cook Cat Food";
	pictureItem = "Exile_Item_CatFood_Cooked";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "Exile_Item_CatFood_Cooked"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot"
	};
	components[] = 
	{
		{1, "Exile_Item_CatFood"}
	};
};

class CookChristmasTinner: Exile_AbstractCraftingRecipe
{
	name = "Cook Christmas Tinner";
	pictureItem = "Exile_Item_ChristmasTinner_Cooked";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "Exile_Item_ChristmasTinner_Cooked"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot"
	};
	components[] = 
	{
		{1, "Exile_Item_ChristmasTinner"}
	};
};
class CookCoffee: Exile_AbstractCraftingRecipe
{
	name = "Brew Coffee";
	pictureItem = "Exile_Item_PlasticBottleCoffee";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "Exile_Item_PlasticBottleCoffee"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot"
	};
	components[] = 
	{
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{1, "Exile_Item_InstantCoffee"}
	};
};
class CookDogFood: Exile_AbstractCraftingRecipe
{
	name = "Cook Dog Food";
	pictureItem = "Exile_Item_DogFood_Cooked";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "Exile_Item_DogFood_Cooked"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot"
	};
	components[] = 
	{
		{1, "Exile_Item_DogFood"}
	};
};

class CookGloriousKnakworst: Exile_AbstractCraftingRecipe
{
	name = "Cook Glorious Knakworst";
	pictureItem = "Exile_Item_GloriousKnakworst_Cooked";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "Exile_Item_GloriousKnakworst_Cooked"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot"
	};
	components[] = 
	{
		{1, "Exile_Item_GloriousKnakworst"}
	};
};

class CookMacasCheese: Exile_AbstractCraftingRecipe
{
	name = "Cook Macas Cheese";
	pictureItem = "Exile_Item_MacasCheese_Cooked";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "Exile_Item_MacasCheese_Cooked"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot"
	};
	components[] = 
	{
		{1, "Exile_Item_MacasCheese"}
	};
};

class CookPlasticBottleDirtyWater: Exile_AbstractCraftingRecipe
{
	name = "Cook Dirty Water";
	pictureItem = "Exile_Item_PlasticBottleFreshWater";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "Exile_Item_PlasticBottleFreshWater"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot"
	};
	components[] = 
	{
		{1, "Exile_Item_PlasticBottleDirtyWater"}
	};
};
class CookPlasticBottleSaltWater: Exile_AbstractCraftingRecipe
{
	name = "Cook Salt Water";
	pictureItem = "Exile_Item_PlasticBottleFreshWater";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "Exile_Item_PlasticBottleFreshWater"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot"
	};
	components[] = 
	{
		{1, "Exile_Item_PlasticBottleSaltWater"}
	};
};

class CookSausageGravy: Exile_AbstractCraftingRecipe
{
	name = "Cook Sausage Gravy";
	pictureItem = "Exile_Item_SausageGravy_Cooked";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "Exile_Item_SausageGravy_Cooked"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot"
	};
	components[] = 
	{
		{1, "Exile_Item_SausageGravy"}
	};
};

class CookSurstromming: Exile_AbstractCraftingRecipe
{
	name = "Cook Surströmming";
	pictureItem = "Exile_Item_Surstromming_Cooked";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "Exile_Item_Surstromming_Cooked"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot"
	};
	components[] = 
	{
		{1, "Exile_Item_Surstromming"}
	};
};

class CraftBandage: Exile_AbstractCraftingRecipe
{
	name = "Craft Bandage";
	pictureItem = "Exile_Item_Bandage";
	returnedItems[] =
	{
		{1, "Exile_Item_Bandage"}
	};
	components[] = 
	{
		{4, "Exile_Item_ToiletPaper"}
	};
};

class CraftConcreteDoorway: Exile_AbstractCraftingRecipe
{
	name = "Craft Concrete Doorway";
	pictureItem = "Exile_Item_ConcreteDoorwayKit";
	requiresConcreteMixer = true;
	returnedItems[] = 
	{
		{1, "Exile_Item_ConcreteDoorwayKit"},
		{3, "Exile_Item_WaterCanisterEmpty"},
		{1, "Exile_Item_FuelCanisterEmpty"}
	};
	components[] = 
	{
		{3, "Exile_Item_Cement"},
		{3, "Exile_Item_Sand"},
		{3, "Exile_Item_MetalPole"},
		{3, "Exile_Item_WaterCanisterDirtyWater"},
		{1, "Exile_Item_FuelCanisterFull"}
	};
};
class CraftConcreteDrawbridge: Exile_AbstractCraftingRecipe
{
	name = "Craft Concrete Drawbridge";
	pictureItem = "Exile_Item_ConcreteDrawBridgeKit";
	requiresConcreteMixer = true;
	returnedItems[] = 
	{
		{1, "Exile_Item_ConcreteDrawBridgeKit"},
		{4, "Exile_Item_WaterCanisterEmpty"},
		{1, "Exile_Item_FuelCanisterEmpty"}
	};
	components[] = 
	{
		{4, "Exile_Item_Cement"},
		{4, "Exile_Item_Sand"},
		{4, "Exile_Item_MetalPole"},
		{3, "Exile_Item_JunkMetal"},
		{4, "Exile_Item_WaterCanisterDirtyWater"},
		{1, "Exile_Item_FuelCanisterFull"}
	};
};
class CraftConcreteFloor: Exile_AbstractCraftingRecipe
{
	name = "Craft Concrete Floor";
	pictureItem = "Exile_Item_ConcreteFloorKit";
	requiresConcreteMixer = true;
	returnedItems[] = 
	{
		{1, "Exile_Item_ConcreteFloorKit"},
		{2, "Exile_Item_WaterCanisterEmpty"},
		{1, "Exile_Item_FuelCanisterEmpty"}
	};
	components[] = 
	{
		{2, "Exile_Item_Cement"},
		{2, "Exile_Item_Sand"},
		{2, "Exile_Item_MetalPole"},
		{2, "Exile_Item_WaterCanisterDirtyWater"},
		{1, "Exile_Item_FuelCanisterFull"}
	};
};
class CraftConcreteFloorPort: Exile_AbstractCraftingRecipe
{
	name = "Craft Concrete Floor Port";
	pictureItem = "Exile_Item_ConcreteFloorPortKit";
	requiresConcreteMixer = true;
	returnedItems[] = 
	{
		{1, "Exile_Item_ConcreteFloorPortKit"},
		{3, "Exile_Item_WaterCanisterEmpty"},
		{1, "Exile_Item_FuelCanisterEmpty"}
	};
	components[] = 
	{
		{3, "Exile_Item_Cement"},
		{3, "Exile_Item_Sand"},
		{3, "Exile_Item_MetalPole"},
		{3, "Exile_Item_WaterCanisterDirtyWater"},
		{1, "Exile_Item_FuelCanisterFull"}
	};
};
class CraftConcreteFloorPortSmall: Exile_AbstractCraftingRecipe
{
	name = "Craft Concrete Floor Port (Small)";
	pictureItem = "Exile_Item_ConcreteFloorPortSmallKit";
	requiresConcreteMixer = true;
	returnedItems[] = 
	{
		{1, "Exile_Item_ConcreteFloorPortSmallKit"},
		{3, "Exile_Item_WaterCanisterEmpty"},
		{1, "Exile_Item_FuelCanisterEmpty"}
	};
	components[] = 
	{
		{3, "Exile_Item_Cement"},
		{2, "Exile_Item_Sand"},
		{2, "Exile_Item_MetalPole"},
		{3, "Exile_Item_WaterCanisterDirtyWater"},
		{1, "Exile_Item_FuelCanisterFull"}
	};
};
class CraftConcreteGate: Exile_AbstractCraftingRecipe
{
	name = "Craft Concrete Gate";
	pictureItem = "Exile_Item_ConcreteGateKit";
	requiresConcreteMixer = true;
	returnedItems[] = 
	{
		{1, "Exile_Item_ConcreteGateKit"},
		{4, "Exile_Item_WaterCanisterEmpty"},
		{1, "Exile_Item_FuelCanisterEmpty"}
	};
	components[] = 
	{
		{4, "Exile_Item_Cement"},
		{4, "Exile_Item_Sand"},
		{4, "Exile_Item_MetalPole"},
		{4, "Exile_Item_WaterCanisterDirtyWater"},
		{1, "Exile_Item_FuelCanisterFull"}
	};
};
class CraftConcreteLadderHatch: Exile_AbstractCraftingRecipe
{
	name = "Craft Concrete Ladder Hatch";
	pictureItem = "Exile_Item_ConcreteLadderHatchKit";
	requiresConcreteMixer = true;
	returnedItems[] = 
	{
		{1, "Exile_Item_ConcreteLadderHatchKit"},
		{3, "Exile_Item_WaterCanisterEmpty"},
		{1, "Exile_Item_FuelCanisterEmpty"}
	};
	components[] = 
	{
		{3, "Exile_Item_Cement"},
		{2, "Exile_Item_Sand"},
		{2, "Exile_Item_MetalPole"},
		{3, "Exile_Item_JunkMetal"},
		{3, "Exile_Item_WaterCanisterDirtyWater"},
		{1, "Exile_Item_FuelCanisterFull"}
	};
};
class CraftConcretStairs: Exile_AbstractCraftingRecipe
{
	name = "Craft Concrete Stairs";
	pictureItem = "Exile_Item_ConcreteStairsKit";
	requiresConcreteMixer = true;
	returnedItems[] = 
	{
		{1, "Exile_Item_ConcreteStairsKit"},
		{1, "Exile_Item_WaterCanisterEmpty"},
		{1, "Exile_Item_FuelCanisterEmpty"}
	};
	components[] = 
	{
		{1, "Exile_Item_Cement"},
		{1, "Exile_Item_Sand"},
		{1, "Exile_Item_MetalPole"},
		{1, "Exile_Item_WaterCanisterDirtyWater"},
		{1, "Exile_Item_FuelCanisterFull"}
	};
};
class CraftConcretSupport: Exile_AbstractCraftingRecipe
{
	name = "Craft Concrete Support";
	pictureItem = "Exile_Item_ConcreteSupportKit";
	requiresConcreteMixer = true;
	returnedItems[] = 
	{
		{1, "Exile_Item_ConcreteSupportKit"},
		{1, "Exile_Item_WaterCanisterEmpty"},
		{1, "Exile_Item_FuelCanisterEmpty"}
	};
	components[] = 
	{
		{1, "Exile_Item_Cement"},
		{1, "Exile_Item_Sand"},
		{1, "Exile_Item_MetalPole"},
		{1, "Exile_Item_WaterCanisterDirtyWater"},
		{1, "Exile_Item_FuelCanisterFull"}
	};
};
class CraftConcreteWall: Exile_AbstractCraftingRecipe
{
	name = "Craft Concrete Wall";
	pictureItem = "Exile_Item_ConcreteWallKit";
	requiresConcreteMixer = true;
	returnedItems[] = 
	{
		{1, "Exile_Item_ConcreteWallKit"},
		{2, "Exile_Item_WaterCanisterEmpty"},
		{1, "Exile_Item_FuelCanisterEmpty"}
	};
	components[] = 
	{
		{2, "Exile_Item_Cement"},
		{2, "Exile_Item_Sand"},
		{2, "Exile_Item_MetalPole"},
		{2, "Exile_Item_WaterCanisterDirtyWater"},
		{1, "Exile_Item_FuelCanisterFull"}
	};
};
class CraftFirePlace: Exile_AbstractCraftingRecipe
{
	name = "Craft Fire Place";
	pictureItem = "Exile_Item_CampFireKit";
	returnedItems[] = 
	{
		{1, "Exile_Item_CampFireKit"}
	};
	components[] = 
	{
		{2, "Exile_Item_WoodLog"}
	};
};
class CraftFloodLight: Exile_AbstractCraftingRecipe
{
	name = "Craft Flood Light";
	pictureItem = "Exile_Item_FloodLightKit";
	requiresFire = 1;
	returnedItems[] = 
	{
		{1, "Exile_Item_FloodLightKit"}
	};
	components[] = 
	{
		{1, "Exile_Item_MetalPole"},
		{1, "Exile_Item_LightBulb"},
		{1, "Exile_Item_ExtensionCord"}
	};
};
class CraftFortificationUpgrade: Exile_AbstractCraftingRecipe
{
	name = "Craft Fortification Upgrade";
	pictureItem = "Exile_Item_MetalBoard"; //<< CHANGE IT
	requiresFire = 1;
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] = 
	{
		{1, "Exile_Item_FortificationUpgrade"}
	};
	components[] = 
	{
		{2, "Exile_Item_MetalPole"},
		{4, "Exile_Item_MetalBoard"}
	};
	tools[] = {"Exile_Item_Grinder"};
};
class CraftHBarrier5Kit: Exile_AbstractCraftingRecipe
{
	name = "Craft H-barrier (5 Blocks)";
	pictureItem = "Exile_Item_HBarrier5Kit";
	requiredInteractionModelGroup = "WorkBench";
	tools[] = 
	{
		"Exile_Item_Pliers"
	};
	returnedItems[] = 
	{
		{1, "Exile_Item_HBarrier5Kit"}
	};
	components[] = 
	{
		{3, "Exile_Item_SandBagsKit_Long"},
		{2, "Exile_Item_MetalWire"}
	};
};
class CraftMetalBoard: Exile_AbstractCraftingRecipe
{
	name = "Craft Metal Board";
	pictureItem = "Exile_Item_MetalBoard";
	requiresFire = 1;
	returnedItems[] = 
	{
		{1, "Exile_Item_MetalBoard"}
	};
	components[] = 
	{
		{2, "Exile_Item_JunkMetal"}
	};
	tools[] = {"Exile_Item_Grinder"};
};
class CraftMetalHedgehog: Exile_AbstractCraftingRecipe
{
	name = "Craft Metal Hedgehog";
	pictureItem = "Exile_Item_MetalHedgehogKit";
	requiresFire = 1;
	returnedItems[] = 
	{
		{1, "Exile_Item_MetalHedgehogKit"}
	};
	components[] = 
	{
		{4, "Exile_Item_MetalPole"}
	};
	tools[] = {"Exile_Item_Grinder"};
};
class CraftMetalLadder: Exile_AbstractCraftingRecipe
{
	name = "Craft Metal Ladder";
	pictureItem = "Exile_Item_MetalLadderKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] =
	{
		{1, "Exile_Item_MetalLadderKit"}
	};
	components[] =
	{
		{6, "Exile_Item_JunkMetal"}
	};
};
class CraftMetalLadderDouble: Exile_AbstractCraftingRecipe
{
	name = "Craft Metal Ladder (Double Tall)";
	pictureItem = "Exile_Item_MetalLadderDoubleKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] =
	{
		{1, "Exile_Item_MetalLadderDoubleKit"}
	};
	components[] =
	{
		{2, "Exile_Item_MetalLadderKit"}
	};
};
class CraftMetalPole: Exile_AbstractCraftingRecipe
{
	name = "Craft Metal Pole";
	pictureItem = "Exile_Item_MetalPole";
	requiresFire = 1;
	returnedItems[] = 
	{
		{1, "Exile_Item_MetalPole"}
	};
	components[] = 
	{
		{4, "Exile_Item_JunkMetal"}
	};
	tools[] = {"Exile_Item_Grinder"};
};
class CraftOldChest: Exile_AbstractCraftingRecipe
{
	name = "Craft Old Chest";
	pictureItem = "Exile_Item_OldChestKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] = 
	{
		{1, "Exile_Item_OldChestKit"}
	};
	components[] = 
	{
		{3, "Exile_Item_WoodPlank"},
		{3, "Exile_Item_JunkMetal"}
	};
};
class CraftPortableGenerator: Exile_AbstractCraftingRecipe
{
	name = "Craft Portable Generator";
	pictureItem = "Exile_Item_PortableGeneratorKit";
	requiresFire = 1;
	returnedItems[] = 
	{
		{1, "Exile_Item_PortableGeneratorKit"}
	};
	components[] = 
	{
		{4, "Exile_Item_MetalBoard"},
		{1, "Exile_Item_FuelCanisterFull"},
		{1, "Exile_Item_ExtensionCord"}
	};
};
class CraftRepairKitConcrete: Exile_AbstractCraftingRecipe
{
	name = "Craft Concrete Repair Kit";
	pictureItem = "Exile_Item_Cement";
	requiresConcreteMixer = true;
	returnedItems[] = 
	{
		{1, "Exile_Item_RepairKitConcrete"},
		{1, "Exile_Item_WaterCanisterEmpty"},
		{1, "Exile_Item_FuelCanisterEmpty"}
	};
	components[] = 
	{
		{4, "Exile_Item_Cement"},
		{2, "Exile_Item_Sand"},
		{1, "Exile_Item_WaterCanisterDirtyWater"},
		{1, "Exile_Item_FuelCanisterFull"}
	};
};
class CraftRepairKitMetal: Exile_AbstractCraftingRecipe
{
	name = "Craft Metal Repair Kit";
	pictureItem = "Exile_Item_RepairKitMetal";
	requiresFire = 0;
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] = 
	{
		{1, "Exile_Item_RepairKitMetal"}
	};
	components[] = 
	{
		{4, "Exile_Item_MetalBoard"}
	};
	tools[] = 
	{
		"Exile_Item_Foolbox",
		"Exile_Item_Grinder"
	};
};
class CraftRepairKitWood: Exile_AbstractCraftingRecipe
{
	name = "Craft Wood Repair Kit";
	pictureItem = "Exile_Item_RepairKitWood";
	requiresFire = 0;
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] = 
	{
		{1, "Exile_Item_RepairKitWood"}
	};
	components[] = 
	{
		{4, "Exile_Item_WoodPlank"}
	};
	tools[] = 
	{
		"Exile_Item_Foolbox"
	};
};
class CraftSandBagsKitCorner: Exile_AbstractCraftingRecipe
{
	name = "Craft Sandbags Kit (Corner)";
	pictureItem = "Exile_Item_SandBagsKit_Corner";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] = 
	{
		{1, "Exile_Item_SandBagsKit_Corner"}
	};
	components[] = 
	{
		{3, "Exile_Item_Sand"}
	};
};
class CraftSandBagsKitLong: Exile_AbstractCraftingRecipe
{
	name = "Craft Sand Bags Kit (Long)";
	pictureItem = "Exile_Item_SandBagsKit_Long";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] = 
	{
		{1, "Exile_Item_SandBagsKit_Long"}
	};
	components[] = 
	{
		{6, "Exile_Item_Sand"}
	};
};
class CraftStorageCrate: Exile_AbstractCraftingRecipe
{
	name = "Craft Storage Crate";
	pictureItem = "Exile_Item_StorageCrateKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] = 
	{
		{1, "Exile_Item_StorageCrateKit"}
	};
	components[] = 
	{
		{5, "Exile_Item_WoodPlank"}
	};
};
class CraftWaterBarrel: Exile_AbstractCraftingRecipe
{
	name = "Craft Water Barrel";
	pictureItem = "Exile_Item_WaterBarrelKit";
	requiredInteractionModelGroup = "WorkBench";
	requiresFire = 1;
	returnedItems[] = 
	{
		{1, "Exile_Item_WaterBarrelKit"}
	};
	components[] = 
	{
		{20, "Exile_Item_PlasticBottleEmpty"}
	};
};
class CraftWireFenceKit: Exile_AbstractCraftingRecipe
{
	name = "Craft Wire Fence Kit";
	pictureItem = "Exile_Item_WireFenceKit";
	requiredInteractionModelGroup = "WorkBench";
	tools[] = 
	{
		"Exile_Item_Grinder", 
		"Exile_Item_Pliers",
		"Exile_Item_Screwdriver"
	};
	returnedItems[] = 
	{
		{1, "Exile_Item_WireFenceKit"}
	};
	components[] = 
	{
		{4, "Exile_Item_MetalPole"},
		{6, "Exile_Item_MetalWire"},
		{1, "Exile_Item_MetalScrews"}
	};
};
class CraftWoodDoorWay: Exile_AbstractCraftingRecipe
{
	name = "Craft Wood Doorway";
	pictureItem = "Exile_Item_WoodDoorwayKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] = 
	{
		{1, "Exile_Item_WoodDoorwayKit"}
	};
	components[] = 
	{
		{6, "Exile_Item_WoodPlank"}
	};
};
class CraftWoodDrawBridge: Exile_AbstractCraftingRecipe
{
	name = "Craft Wood Draw Bridge";
	pictureItem = "Exile_Item_WoodDrawBridgeKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] =
	{
		{1, "Exile_Item_WoodDrawBridgeKit"}
	};
	components[] =
	{
		{8, "Exile_Item_WoodPlank"},
		{1, "Exile_Item_JunkMetal"},
		{1, "Exile_Item_MetalScrews"}
	};
};
class CraftWoodFloor: Exile_AbstractCraftingRecipe
{
	name = "Craft Wood Floor";
	pictureItem = "Exile_Item_WoodFloorKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] = 
	{
		{1, "Exile_Item_WoodFloorKit"}
	};
	components[] = 
	{
		{4, "Exile_Item_WoodPlank"}
	};
};
class CraftWoodFloorPort: Exile_AbstractCraftingRecipe
{
	name = "Craft Wood Floor Port";
	pictureItem = "Exile_Item_WoodFloorPortKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] = 
	{
		{1, "Exile_Item_WoodFloorPortKit"}
	};
	components[] = 
	{
		{6, "Exile_Item_WoodPlank"}
	};
};
class CraftWoodFloorPortSmall: Exile_AbstractCraftingRecipe
{
	name = "Craft Wood Floor Port (Small)";
	pictureItem = "Exile_Item_WoodFloorPortSmallKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] =
	{
		{1, "Exile_Item_WoodFloorPortSmallKit"}
	};
	components[] =
	{
		{6, "Exile_Item_WoodPlank"}
	};
};
class CraftWoodGate: Exile_AbstractCraftingRecipe
{
	name = "Craft Wood Gate";
	pictureItem = "Exile_Item_WoodGateKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] = 
	{
		{1, "Exile_Item_WoodGateKit"}
	};
	components[] = 
	{
		{8, "Exile_Item_WoodPlank"}
	};
};
class CraftWoodLadder: Exile_AbstractCraftingRecipe
{
	name = "Craft Wood Ladder";
	pictureItem = "Exile_Item_WoodLadderKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] =
	{
		{1, "Exile_Item_WoodLadderKit"}
	};
	components[] =
	{
		{6, "Exile_Item_WoodPlank"}
	};
};
class CraftWoodLadderHatch: Exile_AbstractCraftingRecipe
{
	name = "Craft Wood Ladder Hatch";
	pictureItem = "Exile_Item_WoodLadderHatchKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] =
	{
		{1, "Exile_Item_WoodLadderHatchKit"}
	};
	components[] =
	{
		{6, "Exile_Item_WoodPlank"},
		{3, "Exile_Item_JunkMetal"}
	};
};
class CraftWoodPlank: Exile_AbstractCraftingRecipe
{
	name = "Craft Wood Plank";
	pictureItem = "Exile_Item_WoodPlank";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] = 
	{
		{1, "Exile_Item_WoodPlank"}
	};
	components[] = 
	{
		{2, "Exile_Item_WoodLog"}
	};
	tools[] = {"Exile_Item_Handsaw"};
};
class CraftWoodStairs: Exile_AbstractCraftingRecipe
{
	name = "Craft Wood Stairs";
	pictureItem = "Exile_Item_WoodStairsKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] = 
	{
		{1, "Exile_Item_WoodStairsKit"}
	};
	components[] = 
	{
		{6, "Exile_Item_WoodPlank"}
	};
};
class CraftWoodSupport: Exile_AbstractCraftingRecipe
{
	name = "Craft Wood Support";
	pictureItem = "Exile_Item_WoodSupportKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] = 
	{
		{1, "Exile_Item_WoodSupportKit"}
	};
	components[] = 
	{
		{6, "Exile_Item_WoodPlank"}
	};
};
class CraftWoodWall: Exile_AbstractCraftingRecipe
{
	name = "Craft Wood Wall";
	pictureItem = "Exile_Item_WoodWallKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] = 
	{
		{1, "Exile_Item_WoodWallKit"}
	};
	components[] = 
	{
		{4, "Exile_Item_WoodPlank"}
	};
};
class CraftWoodWallHalf: Exile_AbstractCraftingRecipe
{
	name = "Craft 1/2 Wood Wall";
	pictureItem = "Exile_Item_WoodWallHalfKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] = 
	{
		{1, "Exile_Item_WoodWallHalfKit"}
	};
	components[] = 
	{
		{2, "Exile_Item_WoodPlank"}
	};
};
class CraftWoodWindow: Exile_AbstractCraftingRecipe
{
	name = "Craft Wood Window";
	pictureItem = "Exile_Item_WoodWindowKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] = 
	{
		{1, "Exile_Item_WoodWindowKit"}
	};
	components[] = 
	{
		{6, "Exile_Item_WoodPlank"}
	};
};
class CraftWorkBench: Exile_AbstractCraftingRecipe
{
	name = "Craft Work Bench";
	pictureItem = "Exile_Item_WorkBenchKit";
	returnedItems[] = 
	{
		{1, "Exile_Item_WorkBenchKit"}
	};
	components[] = 
	{
		{4, "Exile_Item_WoodLog"}
	};
};
class EmptyFuelCanister: Exile_AbstractCraftingRecipe
{
	name = "Empty Fuel Canister";
	pictureItem = "Exile_Item_FuelCanisterEmpty";
	returnedItems[] = 
	{
		{1, "Exile_Item_FuelCanisterEmpty"}
	};
	components[] = 
	{
		{1, "Exile_Item_FuelCanisterFull"}
	};
};
class EmptyPlasticBottleDirtyWater: Exile_AbstractCraftingRecipe
{
	name = "Empty Dirty Water";
	pictureItem = "Exile_Item_PlasticBottleEmpty";
	returnedItems[] =
	{
		{1, "Exile_Item_PlasticBottleEmpty"}
	};
	components[] =
	{
		{1, "Exile_Item_PlasticBottleDirtyWater"}
	};
};
class EmptyPlasticBottleSaltWater: Exile_AbstractCraftingRecipe
{
	name = "Empty Salt Water";
	pictureItem = "Exile_Item_PlasticBottleEmpty";
	returnedItems[] =
	{
		{1, "Exile_Item_PlasticBottleEmpty"}
	};
	components[] =
	{
		{1, "Exile_Item_PlasticBottleSaltWater"}
	};
};
class FillEmptyPlasticBottleWithDirtyWater: Exile_AbstractCraftingRecipe
{
	name = "Fill Dirty Water";
	pictureItem = "Exile_Item_PlasticBottleDirtyWater";
	requiredInteractionModelGroup = "WaterSource";
	returnedItems[] =
	{
		{1, "Exile_Item_PlasticBottleDirtyWater"}
	};
	components[] = 
	{
		{1, "Exile_Item_PlasticBottleEmpty"}
	};
};
class FillEmptyPlasticBottleWithFreshWater: Exile_AbstractCraftingRecipe
{
	name = "Fill Fresh Water";
	pictureItem = "Exile_Item_PlasticBottleFreshWater";
	requiredInteractionModelGroup = "CleanWaterSource";
	returnedItems[] =
	{
		{1, "Exile_Item_PlasticBottleFreshWater"}
	};
	components[] = 
	{
		{1, "Exile_Item_PlasticBottleEmpty"}
	};
};
class FillEmptyPlasticBottleWithSaltWater: Exile_AbstractCraftingRecipe
{
	name = "Fill Salt Water";
	pictureItem = "Exile_Item_PlasticBottleSaltWater";
	requiresOcean = 1;
	returnedItems[] = 
	{
		{1, "Exile_Item_PlasticBottleSaltWater"}
	};
	components[] = 
	{
		{1, "Exile_Item_PlasticBottleEmpty"}
	};
};
class FillEmptyWaterCanisterWithDirtyWater: Exile_AbstractCraftingRecipe
{
	name = "Fill Dirty Water";
	pictureItem = "Exile_Item_WaterCanisterDirtyWater";
	requiredInteractionModelGroup = "WaterSource";
	returnedItems[] =
	{
		{1, "Exile_Item_WaterCanisterDirtyWater"}
	};
	components[] = 
	{
		{1, "Exile_Item_WaterCanisterEmpty"}
	};
};
class FillFuelCanister: Exile_AbstractCraftingRecipe
{
	name = "Fill Fuel Canister";
	pictureItem = "Exile_Item_FuelCanisterFull";
	requiredInteractionModelGroup = "FuelSource";
	returnedItems[] = 
	{
		{1, "Exile_Item_FuelCanisterFull"}
	};
	components[] = 
	{
		{1, "Exile_Item_FuelCanisterEmpty"}
	};
};
class UpgradeToConcreteDoor: Exile_AbstractCraftingRecipe
{
	name = "Upgrade to Concrete Door";
	pictureItem = "Exile_Item_ConcreteDoorKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] = 
	{
		{1, "Exile_Item_ConcreteDoorKit"}
	};
	components[] = 
	{
		{1, "Exile_Item_ConcreteDoorwayKit"},
		{2, "Exile_Item_MetalPole"},
		{4, "Exile_Item_MetalBoard"}
	};
};
class UpgradeToConcreteFloorPort: Exile_AbstractCraftingRecipe
{
	name = "Upgrade to Concrete Floor Port";
	pictureItem = "Exile_Item_ConcreteFloorPortKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] = 
	{
		{1, "Exile_Item_ConcreteFloorPortKit"}
	};
	components[] = 
	{
		{1, "Exile_Item_ConcreteFloorKit"},
		{2, "Exile_Item_MetalPole"},
		{4, "Exile_Item_MetalBoard"}
	};
};
class UpgradeToConcreteGate: Exile_AbstractCraftingRecipe
{
	name = "Upgrade to Concrete Gate";
	pictureItem = "Exile_Item_ConcreteGateKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] = 
	{
		{1, "Exile_Item_ConcreteGateKit"}
	};
	components[] = 
	{
		{1, "Exile_Item_ConcreteWallKit"},
		{2, "Exile_Item_MetalPole"},
		{4, "Exile_Item_MetalBoard"}
	};
};
class UpgradeToConcreteWindow: Exile_AbstractCraftingRecipe
{
	name = "Upgrade to Concrete Window";
	pictureItem = "Exile_Item_ConcreteWindowKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] = 
	{
		{1, "Exile_Item_ConcreteWindowKit"}
	};
	components[] = 
	{
		{1, "Exile_Item_ConcreteWallKit"},
		{2, "Exile_Item_MetalPole"},
		{4, "Exile_Item_MetalBoard"}
	};
};
class UpgradeToWoodDoor: Exile_AbstractCraftingRecipe
{
	name = "Upgrade to Wood Door";
	pictureItem = "Exile_Item_WoodDoorKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] = 
	{
		{1, "Exile_Item_WoodDoorKit"}
	};
	components[] = 
	{
		{1, "Exile_Item_WoodDoorwayKit"},
		{2, "Exile_Item_WoodPlank"}
	};
};
class UpgradeToWoodDrawBridge: Exile_AbstractCraftingRecipe
{
	name = "Upgrade to Wood Draw Bridge";
	pictureItem = "Exile_Item_WoodDrawBridgeKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] =
	{
		{1, "Exile_Item_WoodDrawBridgeKit"}
	};
	components[] =
	{
		{1, "Exile_Item_WoodGateKit"},
		{2, "Exile_Item_WoodPlank"},
		{1, "Exile_Item_JunkMetal"},
		{1, "Exile_Item_MetalScrews"}
	};
};
class UpgradeToWoodFloorPort: Exile_AbstractCraftingRecipe
{
	name = "Upgrade to Wood Floor Port";
	pictureItem = "Exile_Item_WoodFloorPortKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] = 
	{
		{1, "Exile_Item_WoodFloorPortKit"}
	};
	components[] = 
	{
		{1, "Exile_Item_WoodFloorKit"},
		{2, "Exile_Item_WoodPlank"}
	};
};
class UpgradeToWoodGate: Exile_AbstractCraftingRecipe
{
	name = "Upgrade to Wood Gate";
	pictureItem = "Exile_Item_WoodGateKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] = 
	{
		{1, "Exile_Item_WoodGateKit"}
	};
	components[] = 
	{
		{1, "Exile_Item_WoodWallKit"},
		{4, "Exile_Item_WoodPlank"}
	};
};
class UpgradeToWoodWall: Exile_AbstractCraftingRecipe
{
	name = "Upgrade to Wood Wall";
	pictureItem = "Exile_Item_WoodWallHalfKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] = 
	{
		{1, "Exile_Item_WoodWallKit"}
	};
	components[] = 
	{
		{2, "Exile_Item_WoodWallHalfKit"}
	};
};
class UpgradeToWoodWindow: Exile_AbstractCraftingRecipe
{
	name = "Upgrade to Wood Window";
	pictureItem = "Exile_Item_WoodWindowKit";
	requiredInteractionModelGroup = "WorkBench";
	returnedItems[] = 
	{
		{1, "Exile_Item_WoodWindowKit"}
	};
	components[] = 
	{
		{1, "Exile_Item_WoodWallKit"},
		{2, "Exile_Item_WoodPlank"}
	};
};
//Extended Survival Pack
class CookCanteenCoffee: Exile_AbstractCraftingRecipe
{
	name = "Brew Coffee";
	pictureItem = "DDR_Item_Canteen_Coffee";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Canteen_Coffee"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot"
	};
	components[] = 
	{
		{1, "DDR_Item_Canteen_Fresh"},
		{1, "Exile_Item_InstantCoffee"}
	};
};
class CookCanteenDirtyWater: Exile_AbstractCraftingRecipe
{
	name = "Cook Dirty Water";
	pictureItem = "DDR_Item_Canteen_Fresh";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Canteen_Fresh"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot"
	};
	components[] =
	{
		{1, "DDR_Item_Canteen_Dirty"}
	};
};
class PurificationCanteenDirtyWater: Exile_AbstractCraftingRecipe
{
	name = "Purification Dirty Water";
	pictureItem = "DDR_Item_Canteen_Fresh";
	returnedItems[] =
	{
		{1, "DDR_Item_Canteen_Fresh"}
	};
	components[] =
	{
		{1, "DDR_Item_Purificationtablets"},
		{1, "DDR_Item_Canteen_Dirty"}
	};
};
class CookCanteenSaltWater: Exile_AbstractCraftingRecipe
{
	name = "Cook Salt Water";
	pictureItem = "DDR_Item_Canteen_Fresh";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Canteen_Fresh"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot"
	};
	components[] =
	{
		{1, "DDR_Item_Canteen_Salt"}
	};
};
class EmptyCanteenDirtyWater: Exile_AbstractCraftingRecipe
{
	name = "Empty Dirty Water";
	pictureItem = "DDR_Item_Canteen";
	returnedItems[] =
	{
		{1, "DDR_Item_Canteen"}
	};
	components[] =
	{
		{1, "DDR_Item_Canteen_Dirty"}
	};	
};
class EmptyCanteenSaltWater: Exile_AbstractCraftingRecipe
{
	name = "Empty Salt Water";
	pictureItem = "DDR_Item_Canteen";
	returnedItems[] =
	{
		{1, "DDR_Item_Canteen"}
	};
	components[] =
	{
		{1, "DDR_Item_Canteen_Salt"}
	};
};
class FillEmptyCanteenWithDirtyWater: Exile_AbstractCraftingRecipe
{
	name = "Fill Dirty Water";
	pictureItem = "DDR_Item_Canteen_Dirty";
	requiredInteractionModelGroup = "WaterSource";
	returnedItems[] =
	{
		{1, "DDR_Item_Canteen_Dirty"}
	};
	components[] =
	{
		{1, "DDR_Item_Canteen"}
	};
};
class FillEmptyCanteenWithFreshWater: Exile_AbstractCraftingRecipe
{
	name = "Fill Fresh Water";
	pictureItem = "DDR_Item_Canteen_Fresh";
	requiredInteractionModelGroup = "CleanWaterSource";
	returnedItems[] =
	{
		{1, "DDR_Item_Canteen_Fresh"}
	};
	components[] =
	{
		{1, "DDR_Item_Canteen"}
	};
};
class FillEmptyCanteenWithSaltWater: Exile_AbstractCraftingRecipe
{
	name = "Fill Salt Water";
	pictureItem = "DDR_Item_Canteen_Salt";
	requiresOcean = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Canteen_Salt"}
	};
	components[] =
	{
		{1, "DDR_Item_Canteen"}
	};
};
class CookCanteenDirtyWater_can: Exile_AbstractCraftingRecipe
{
	name = "Cook Dirty Water (Can)";
	pictureItem = "DDR_Item_Canteen_Fresh";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Canteen_Fresh"}
	};
	tools[] =
	{
		"Exile_Item_Can_Empty"
	};
	components[] =
	{
		{1, "DDR_Item_Canteen_Dirty"}
	};
};
class CookCanteenSaltWater_can: Exile_AbstractCraftingRecipe
{
	name = "Cook Salt Water (Can)";
	pictureItem = "DDR_Item_Canteen_Fresh";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Canteen_Fresh"}
	};
	tools[] =
	{
		"Exile_Item_Can_Empty"
	};
	components[] =
	{
		{1, "DDR_Item_Canteen_Salt"}
	};
};
class CookCanteenCoffee_can: Exile_AbstractCraftingRecipe
{
	name = "Brew Coffee (Can)";
	pictureItem = "DDR_Item_Canteen_Coffee";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Canteen_Coffee"}
	};
	tools[] =
	{
		"Exile_Item_Can_Empty"
	};
	components[] =
	{
		{1, "DDR_Item_Canteen_Fresh"},
		{1, "Exile_Item_InstantCoffee"}
	};
};
class CookCanteenMilkCoffee: Exile_AbstractCraftingRecipe
{
	name = "Brew Coffee with Milk";
	pictureItem = "DDR_Item_Canteen_Coffee_Milk";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Canteen_Coffee_Milk"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot"
	};
	components[] = 
	{
		{1, "DDR_Item_Canteen_Fresh"},
		{1, "DDR_Item_Milkpowder"},
		{1, "Exile_Item_InstantCoffee"}
	};
};
class CookCanteenMilkCoffee_can: Exile_AbstractCraftingRecipe
{
	name = "Brew Coffee with Milk (Can)";
	pictureItem = "DDR_Item_Canteen_Coffee_Milk";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Canteen_Coffee_Milk"}
	};
	tools[] =
	{
		"Exile_Item_Can_Empty"
	};
	components[] =
	{
		{1, "DDR_Item_Canteen_Fresh"},
		{1, "DDR_Item_Milkpowder"},
		{1, "Exile_Item_InstantCoffee"}
	};
};
class CookBakedbeans: Exile_AbstractCraftingRecipe
{
	name = "Cook Baked Beans";
	pictureItem = "DDR_Item_Bakedbeans_Cooked";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Bakedbeans_Cooked"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot"
	};
	components[] =
	{
		{1, "DDR_Item_Bakedbeans"}
	};
};
class CookTacticalbacon: Exile_AbstractCraftingRecipe
{
	name = "Cook Tactical Bacon";
	pictureItem = "DDR_Item_Tacticalbacon_Cooked";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Tacticalbacon_Cooked"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot"
	};
	components[] =
	{
		{1, "DDR_Item_Tacticalbacon"}
	};
};
class CookRice: Exile_AbstractCraftingRecipe
{
	name = "Cook Rice";
	pictureItem = "DDR_Item_Rice_Cooked";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Rice_Cooked"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot"
	};
	components[] =
	{
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerChickenRiceC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Chicken/Rice)";
	pictureItem = "DDR_Item_Container_Chicken_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Chicken_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_ChickenFilet_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerChickenRiceB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Chicken/Rice)";
	pictureItem = "DDR_Item_Container_Chicken_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Chicken_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_ChickenFilet_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerAlsatianRiceC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Alsatian/Rice)";
	pictureItem = "DDR_Item_Container_Alsatian_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Alsatian_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_AlsatianSteak_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerAlsatianRiceB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Alsatian/Rice)";
	pictureItem = "DDR_Item_Container_Alsatian_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Alsatian_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_AlsatianSteak_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerCatSharkRiceC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Cat Shark Filet/Rice)";
	pictureItem = "DDR_Item_Container_CatShark_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_CatShark_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_CatSharkFilet_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerCatSharkRiceB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Cat Shark Filet/Rice)";
	pictureItem = "DDR_Item_Container_CatShark_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_CatShark_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_CatSharkFilet_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerFinRiceC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Fin/Rice)";
	pictureItem = "DDR_Item_Container_Fin_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Fin_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_FinSteak_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerFinRiceB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Fin/Rice)";
	pictureItem = "DDR_Item_Container_Fin_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Fin_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_FinSteak_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerGoatRiceC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Goat/Rice)";
	pictureItem = "DDR_Item_Container_Goat_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Goat_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_GoatSteak_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerGoatRiceB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Goat/Rice)";
	pictureItem = "DDR_Item_Container_Goat_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Goat_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_GoatSteak_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerMackerelRiceC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Mackerel Filet/Rice)";
	pictureItem = "DDR_Item_Container_Mackerel_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Mackerel_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_MackerelFilet_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerMackerelRiceB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Mackerel Filet/Rice)";
	pictureItem = "DDR_Item_Container_Mackerel_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Mackerel_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_MackerelFilet_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerMulletRiceC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Mullet Filet/Rice)";
	pictureItem = "DDR_Item_Container_Mullet_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Mullet_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_MulletFilet_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerMulletRiceB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Mullet Filet/Rice)";
	pictureItem = "DDR_Item_Container_Mullet_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Mullet_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_MulletFilet_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerOrnateRiceC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Ornate Filet/Rice)";
	pictureItem = "DDR_Item_Container_Ornate_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Ornate_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_OrnateFilet_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerOrnateRiceB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Ornate Filet/Rice)";
	pictureItem = "DDR_Item_Container_Ornate_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Ornate_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_OrnateFilet_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerRabbitRiceC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Rabbit/Rice)";
	pictureItem = "DDR_Item_Container_Rabbit_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Rabbit_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_RabbitSteak_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerRabbitRiceB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Rabbit/Rice)";
	pictureItem = "DDR_Item_Container_Rabbit_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Rabbit_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_RabbitSteak_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerRoosterRiceC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Rooster/Rice)";
	pictureItem = "DDR_Item_Container_Rooster_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Rooster_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_RoosterFilet_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerRoosterRiceB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Rooster/Rice)";
	pictureItem = "DDR_Item_Container_Rooster_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Rooster_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_RoosterFilet_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerSalemaRiceC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Salema Filet/Rice)";
	pictureItem = "DDR_Item_Container_Salema_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Salema_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_SalemaFilet_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerSalemaRiceB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Salema Filet/Rice)";
	pictureItem = "DDR_Item_Container_Salema_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Salema_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_SalemaFilet_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerSheepRiceC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Sheep/Rice)";
	pictureItem = "DDR_Item_Container_Sheep_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Sheep_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_SheepSteak_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerSheepRiceB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Sheep/Rice)";
	pictureItem = "DDR_Item_Container_Sheep_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Sheep_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_SheepSteak_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerSnakeRiceC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Snake Filet/Rice)";
	pictureItem = "DDR_Item_Container_Snake_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Snake_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_SnakeFilet_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerSnakeRiceB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Snake/Rice)";
	pictureItem = "DDR_Item_Container_Snake_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Snake_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_SnakeFilet_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerTunaRiceC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Tuna Filet/Rice)";
	pictureItem = "DDR_Item_Container_Tuna_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Tuna_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_TunaFilet_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerTunaRiceB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Tuna Filet/Rice)";
	pictureItem = "DDR_Item_Container_Tuna_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Tuna_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_TunaFilet_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerTurtleRiceC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Turtle Filet/Rice)";
	pictureItem = "DDR_Item_Container_Turtle_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Turtle_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_TurtleFilet_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerTurtleRiceB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Turtle Filet/Rice)";
	pictureItem = "DDR_Item_Container_Turtle_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Turtle_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_TurtleFilet_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerSalemaaRiceC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Salema Fresh/Rice)";
	pictureItem = "DDR_Item_Container_Salemaa_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Salemaa_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_Salema"},
		{1, "DDR_Item_Canteen_Fresh"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerSalemaaRiceB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Salema Fresh/Rice)";
	pictureItem = "DDR_Item_Container_Salemaa_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Salemaa_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_Salema"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerMackerellRiceC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Mackerel Fresh/Rice)";
	pictureItem = "DDR_Item_Container_Mackerell_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Mackerell_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_Mackerel"},
		{1, "DDR_Item_Canteen_Fresh"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerMackerellRiceB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Mackerel Fresh/Rice)";
	pictureItem = "DDR_Item_Container_Mackerell_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Mackerell_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_Mackerel"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerTunaaRiceC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Tuna Fresh/Rice)";
	pictureItem = "DDR_Item_Container_Tunaa_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Tunaa_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_Tunaa"},
		{1, "DDR_Item_Canteen_Fresh"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerTunaaRiceB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Tuna Fresh/Rice)";
	pictureItem = "DDR_Item_Container_Tunaa_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Tunaa_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_Tunaa"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerMullettRiceC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Mullet Fresh/Rice)";
	pictureItem = "DDR_Item_Container_Mullett_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Mullett_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_Mullet"},
		{1, "DDR_Item_Canteen_Fresh"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerMullettRiceB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Mullet Fresh/Rice)";
	pictureItem = "DDR_Item_Container_Mullett_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Mullett_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_Mullet"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerCatSharkkRiceC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Cat Shark Fresh/Rice)";
	pictureItem = "DDR_Item_Container_CatSharkk_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_CatSharkk_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_CatShark"},
		{1, "DDR_Item_Canteen_Fresh"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerCatSharkkRiceB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Cat Shark Fresh/Rice)";
	pictureItem = "DDR_Item_Container_CatSharkk_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_CatSharkk_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_CatShark"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerOrnateeRiceC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Ornate Fresh/Rice)";
	pictureItem = "DDR_Item_Container_Ornatee_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Ornatee_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_Ornate"},
		{1, "DDR_Item_Canteen_Fresh"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerOrnateeRiceB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Ornate Fresh/Rice)";
	pictureItem = "DDR_Item_Container_Ornatee_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Ornatee_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_Ornate"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerTurtleeRiceC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Turtle Fresh/Rice)";
	pictureItem = "DDR_Item_Container_Turtlee_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Turtlee_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_Turtle"},
		{1, "DDR_Item_Canteen_Fresh"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerTurtleeRiceB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Turtle Fresh/Rice)";
	pictureItem = "DDR_Item_Container_Turtlee_Rice";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Turtlee_Rice"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_Turtle"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{1, "DDR_Item_Rice"}
	};
};
class CookFoodContainerChickenPotatoC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Chicken/Potato)";
	pictureItem = "DDR_Item_Container_Chicken_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Chicken_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_ChickenFilet_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerChickenPotatoB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Chicken/Potato)";
	pictureItem = "DDR_Item_Container_Chicken_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Chicken_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_ChickenFilet_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerAlsatianPotatoC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Alsatian/Potato)";
	pictureItem = "DDR_Item_Container_Alsatian_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Alsatian_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_AlsatianSteak_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerAlsatianPotatoB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Alsatian/Potato)";
	pictureItem = "DDR_Item_Container_Alsatian_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Alsatian_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_AlsatianSteak_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerCatSharkPotatoC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Cat Shark Filet/Potato)";
	pictureItem = "DDR_Item_Container_CatShark_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_CatShark_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_CatSharkFilet_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerCatSharkPotatoB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Cat Shark Filet/Potato)";
	pictureItem = "DDR_Item_Container_CatShark_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_CatShark_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_CatSharkFilet_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerFinPotatoC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Fin/Potato)";
	pictureItem = "DDR_Item_Container_Fin_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Fin_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_FinSteak_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerFinPotatoB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Fin/Potato)";
	pictureItem = "DDR_Item_Container_Fin_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Fin_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_FinSteak_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerGoatPotatoC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Goat/Potato)";
	pictureItem = "DDR_Item_Container_Goat_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Goat_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_GoatSteak_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerGoatPotatoB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Goat/Potato)";
	pictureItem = "DDR_Item_Container_Goat_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Goat_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_GoatSteak_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerMackerelPotatoC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Mackerel Filet/Potato)";
	pictureItem = "DDR_Item_Container_Mackerel_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Mackerel_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_MackerelFilet_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerMackerelPotatoB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Mackerel Filet/Potato)";
	pictureItem = "DDR_Item_Container_Mackerel_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Mackerel_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_MackerelFilet_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerMulletPotatoC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Mullet Filet/Potato)";
	pictureItem = "DDR_Item_Container_Mullet_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Mullet_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_MulletFilet_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerMulletPotatoB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Mullet Filet/Potato)";
	pictureItem = "DDR_Item_Container_Mullet_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Mullet_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_MulletFilet_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerOrnatePotatoC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Ornate Filet/Potato)";
	pictureItem = "DDR_Item_Container_Ornate_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Ornate_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_OrnateFilet_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerOrnatePotatoB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Ornate Filet/Potato)";
	pictureItem = "DDR_Item_Container_Ornate_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Ornate_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_OrnateFilet_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerRabbitPotatoC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Rabbit/Potato)";
	pictureItem = "DDR_Item_Container_Rabbit_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Rabbit_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_RabbitSteak_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerRabbitPotatoB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Rabbit/Potato)";
	pictureItem = "DDR_Item_Container_Rabbit_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Rabbit_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_RabbitSteak_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerRoosterPotatoC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Rooster/Potato)";
	pictureItem = "DDR_Item_Container_Rooster_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Rooster_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_RoosterFilet_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerRoosterPotatoB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Rooster/Potato)";
	pictureItem = "DDR_Item_Container_Rooster_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Rooster_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_RoosterFilet_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerSalemaPotatoC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Salema Filet/Potato)";
	pictureItem = "DDR_Item_Container_Salema_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Salema_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_SalemaFilet_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerSalemaPotatoB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Salema Filet/Potato)";
	pictureItem = "DDR_Item_Container_Salema_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Salema_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_SalemaFilet_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerSheepPotatoC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Sheep/Potato)";
	pictureItem = "DDR_Item_Container_Sheep_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Sheep_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_SheepSteak_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerSheepPotatoB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Sheep/Potato)";
	pictureItem = "DDR_Item_Container_Sheep_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Sheep_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_SheepSteak_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerSnakePotatoC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Snake Filet/Potato)";
	pictureItem = "DDR_Item_Container_Snake_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Snake_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_SnakeFilet_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerSnakePotatoB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Snake/Potato)";
	pictureItem = "DDR_Item_Container_Snake_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Snake_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_SnakeFilet_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerTunaPotatoC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Tuna Filet/Potato)";
	pictureItem = "DDR_Item_Container_Tuna_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Tuna_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_TunaFilet_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerTunaPotatoB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Tuna Filet/Potato)";
	pictureItem = "DDR_Item_Container_Tuna_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Tuna_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_TunaFilet_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerTurtlePotatoC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Turtle Filet/Potato)";
	pictureItem = "DDR_Item_Container_Turtle_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Turtle_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_TurtleFilet_Raw"},
		{1, "DDR_Item_Canteen_Fresh"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerTurtlePotatoB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Turtle Filet/Potato)";
	pictureItem = "DDR_Item_Container_Turtle_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Turtle_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "Exile_Item_TurtleFilet_Raw"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerSalemaaPotatoC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Salema Fresh/Potato)";
	pictureItem = "DDR_Item_Container_Salemaa_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Salemaa_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_Salema"},
		{1, "DDR_Item_Canteen_Fresh"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerSalemaaPotatoB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Salema Fresh/Potato)";
	pictureItem = "DDR_Item_Container_Salemaa_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Salemaa_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_Salema"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerMackerellPotatoC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Mackerel Fresh/Potato)";
	pictureItem = "DDR_Item_Container_Mackerell_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Mackerell_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_Mackerel"},
		{1, "DDR_Item_Canteen_Fresh"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerMackerellPotatoB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Mackerel Fresh/Potato)";
	pictureItem = "DDR_Item_Container_Mackerell_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Mackerell_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_Mackerel"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerTunaaPotatoC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Tuna Fresh/Potato)";
	pictureItem = "DDR_Item_Container_Tunaa_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Tunaa_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_Tunaa"},
		{1, "DDR_Item_Canteen_Fresh"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerTunaaPotatoB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Tuna Fresh/Potato)";
	pictureItem = "DDR_Item_Container_Tunaa_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Tunaa_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_Tunaa"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerMullettPotatoC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Mullet Fresh/Potato)";
	pictureItem = "DDR_Item_Container_Mullett_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Mullett_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_Mullet"},
		{1, "DDR_Item_Canteen_Fresh"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerMullettPotatoB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Mullet Fresh/Potato)";
	pictureItem = "DDR_Item_Container_Mullett_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Mullett_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_Mullet"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerCatSharkkPotatoC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Cat Shark Fresh/Potato)";
	pictureItem = "DDR_Item_Container_CatSharkk_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_CatSharkk_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_CatShark"},
		{1, "DDR_Item_Canteen_Fresh"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerCatSharkkPotatoB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Cat Shark Fresh/Potato)";
	pictureItem = "DDR_Item_Container_CatSharkk_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_CatSharkk_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_CatShark"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerOrnateePotatoC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Ornate Fresh/Potato)";
	pictureItem = "DDR_Item_Container_Ornatee_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Ornatee_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_Ornate"},
		{1, "DDR_Item_Canteen_Fresh"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerOrnateePotatoB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Ornate Fresh/Potato)";
	pictureItem = "DDR_Item_Container_Ornatee_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Ornatee_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_Ornate"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerTurtleePotatoC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Turtle Fresh/Potato)";
	pictureItem = "DDR_Item_Container_Turtlee_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Turtlee_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_Turtle"},
		{1, "DDR_Item_Canteen_Fresh"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerTurtleePotatoB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Turtle Fresh/Potato)";
	pictureItem = "DDR_Item_Container_Turtlee_Potato";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Turtlee_Potato"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{1, "DDR_Item_Turtle"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{5, "DDR_Item_Potato"}
	};
};
class CookFoodContainerContainerSoupC: Exile_AbstractCraftingRecipe
{
	name = "Food Container (C) (Special Soup)";
	pictureItem = "DDR_Item_Container_Soup";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Soup"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{2, "DDR_Item_Tomato"},
		{2, "DDR_Item_Beet"},
		{2, "DDR_Item_Cucumber"},
		{2, "DDR_Item_Carrot"},
		{1, "DDR_Item_Canteen_Fresh"},
		{2, "DDR_Item_Potato"}
	};
};
class CookFoodContainerContainerSoupB: Exile_AbstractCraftingRecipe
{
	name = "Food Container (B) (Special Soup)";
	pictureItem = "DDR_Item_Container_Soup";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "DDR_Item_Container_Soup"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot",
		"DDR_Item_Salt_Shaker",
		"DDR_Item_Pepper_Shaker"
	};
	components[] =
	{
		{1, "DDR_Item_Container"},
		{2, "DDR_Item_Tomato"},
		{2, "DDR_Item_Beet"},
		{2, "DDR_Item_Cucumber"},
		{2, "DDR_Item_Carrot"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{2, "DDR_Item_Potato"}
	};
};
class CraftFirstaid: Exile_AbstractCraftingRecipe
{
    name = "Craft First Aid Kit";
    pictureItem = "DDR_Item_Firstaid";	
    returnedItems[] =
    {
        {1, "DDR_Item_Firstaid"}
    };
    components[] =
    {
        {1, "Exile_Item_Vishpirin"},
        {1, "DDR_Item_Painkillers"},
        {1, "DDR_Item_Antibiotic"},
        {1, "Exile_Item_InstaDoc"},
        {1, "Exile_Item_Bandage"}
    };
};

class CraftSilverBar: Exile_AbstractCraftingRecipe
{
    name = "Craft Silver Bar";
    pictureItem = "DDR_Item_Silver_Bar";
	requiresFire = 1;	
    returnedItems[] =
    {
        {1, "DDR_Item_Silver_Bar"}
    };
	tools[] =
	{
		"DDR_Item_Old_Pot"
	};
    components[] =
    {
        {8, "DDR_Item_Silver_Ore"}
    };
};
class CraftGoldBar: Exile_AbstractCraftingRecipe
{
    name = "Craft Gold Bar";
    pictureItem = "DDR_Item_Gold_Bar";
	requiresFire = 1;
    returnedItems[] =
    {
        {1, "DDR_Item_Gold_Bar"}
    };
	tools[] =
	{
		"DDR_Item_Old_Pot"
	};
    components[] =
    {
        {8, "DDR_Item_Gold_Ore"}
    };
};
class crafted_Disinfectants: Exile_AbstractCraftingRecipe
{
	name = "Craft Disinfectant Spray (B)";
	pictureItem = "DDR_Item_Disinfectant";
	returnedItems[] =
	{
		{1, "DDR_Item_Disinfectant"}
	};
	tools[] =
	{
		"Exile_Item_Can_Empty"
	};
	components[] =
	{
		{1, "DDR_Item_Antibiotic"},	
		{1, "Exile_Item_PlasticBottleFreshWater"}
	};
};
class crafted_Disinfectantss: Exile_AbstractCraftingRecipe
{
	name = "Craft Disinfectant Spray (C)";
	pictureItem = "DDR_Item_Disinfectant";
	returnedItems[] =
	{
		{1, "DDR_Item_Disinfectant"}
	};
	tools[] =
	{
		"Exile_Item_Can_Empty"
	};
	components[] =
	{
		{1, "DDR_Item_Antibiotic"},	
		{1, "DDR_Item_Canteen_Fresh"}
	};
};
class crafted_CleanDirtyBandage: Exile_AbstractCraftingRecipe
{
	name = "Clean Dirty Bandage (B)";
	pictureItem = "DDR_Item_Bandage_Dirty";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "Exile_Item_Bandage"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot"
	};
	components[] =
	{
		{1, "DDR_Item_Bandage_Dirty"},
		{1, "Exile_Item_PlasticBottleFreshWater"}
	};
};
class crafted_CleanDirtyBandagee: Exile_AbstractCraftingRecipe
{
	name = "Clean Dirty Bandage (C)";
	pictureItem = "DDR_Item_Bandage_Dirty";
    requiresFire = 1;
	returnedItems[] =
	{
		{1, "Exile_Item_Bandage"}
	};
	tools[] =
	{
		"Exile_Item_CookingPot"
	};
	components[] =
	{
		{1, "DDR_Item_Bandage_Dirty"},
		{1, "DDR_Item_Canteen_Fresh"}
	};
};
class CraftPlasticCaniste: Exile_AbstractCraftingRecipe
{
	name = "Craft Plastic Canister";
	pictureItem = "Exile_Item_WaterCanisterEmpty";
	returnedItems[] =
	{
		{1, "Exile_Item_WaterCanisterEmpty"}
	};
	tools[] =
	{
		"Exile_Item_Knife"
	};
	components[] =
	{
		{15, "Exile_Item_PlasticBottleFreshWater"}
	};	
};

/////////////////////Standard recipes with pan///////////////////////

class CookAlsatianSteak: Exile_AbstractCraftingRecipe
{
    name = "Cook Alsatian Steak";
    pictureItem = "Exile_Item_AlsatianSteak_Cooked";
    requiresFire = 1;
    returnedItems[] =
    {
        {1, "Exile_Item_AlsatianSteak_Cooked"}
    };
    tools[] =
    {
        "DDR_Item_Pan"
    };
    components[] =
    {
        {1, "Exile_Item_AlsatianSteak_Raw"}
    };
};
class CookCatSharkFilet: Exile_AbstractCraftingRecipe
{
    name = "Cook Cat Shark Filet";
    pictureItem = "Exile_Item_CatSharkFilet_Cooked";
    requiresFire = 1;
    returnedItems[] =
    {
        {1, "Exile_Item_CatSharkFilet_Cooked"}
    };
    tools[] =
    {
        "DDR_Item_Pan"
    };
    components[] =
    {
        {1, "Exile_Item_CatSharkFilet_Raw"}
    };
};
class CookChickenFilet: Exile_AbstractCraftingRecipe
{
    name = "Cook Chicken Filet";
    pictureItem = "Exile_Item_ChickenFilet_Cooked";
    requiresFire = 1;
    returnedItems[] =
    {
        {1, "Exile_Item_ChickenFilet_Cooked"}
    };
    tools[] =
    {
        "DDR_Item_Pan"
    };
    components[] =
    {
        {1, "Exile_Item_ChickenFilet_Raw"}
    };
};
class CookFinSteak: Exile_AbstractCraftingRecipe
{
    name = "Cook Fin Steak";
    pictureItem = "Exile_Item_FinSteak_Cooked";
    requiresFire = 1;
    returnedItems[] =
    {
        {1, "Exile_Item_FinSteak_Cooked"}
    };
    tools[] =
    {
        "DDR_Item_Pan"
    };
    components[] =
    {
        {1, "Exile_Item_FinSteak_Raw"}
    };
};
class CookGoatSteak: Exile_AbstractCraftingRecipe
{
    name = "Cook Goat Steak";
    pictureItem = "Exile_Item_GoatSteak_Cooked";
    requiresFire = 1;
    returnedItems[] =
    {
        {1, "Exile_Item_GoatSteak_Cooked"}
    };
    tools[] =
    {
        "DDR_Item_Pan"
    };
    components[] =
    {
        {1, "Exile_Item_GoatSteak_Raw"}
    };
};
class CookMackerelFilet: Exile_AbstractCraftingRecipe
{
    name = "Cook Mackerel Filet";
    pictureItem = "Exile_Item_MackerelFilet_Cooked";
    requiresFire = 1;
    returnedItems[] =
    {
        {1, "Exile_Item_MackerelFilet_Cooked"}
    };
    tools[] =
    {
        "DDR_Item_Pan"
    };
    components[] =
    {
        {1, "Exile_Item_MackerelFilet_Raw"}
    };
};
class CookMulletFilet: Exile_AbstractCraftingRecipe
{
    name = "Cook Mullet Filet";
    pictureItem = "Exile_Item_MulletFilet_Cooked";
    requiresFire = 1;
    returnedItems[] =
    {
        {1, "Exile_Item_MulletFilet_Cooked"}
    };
    tools[] =
    {
        "DDR_Item_Pan"
    };
    components[] =
    {
        {1, "Exile_Item_MulletFilet_Raw"}
    };
};
class CookOrnateFilet: Exile_AbstractCraftingRecipe
{
    name = "Cook Ornate Filet";
    pictureItem = "Exile_Item_OrnateFilet_Cooked";
    requiresFire = 1;
    returnedItems[] =
    {
        {1, "Exile_Item_OrnateFilet_Cooked"}
    };
    tools[] =
    {
        "DDR_Item_Pan"
    };
    components[] =
    {
        {1, "Exile_Item_OrnateFilet_Raw"}
    };
};
class CookRabbitSteak: Exile_AbstractCraftingRecipe
{
    name = "Cook Rabbit Steak";
    pictureItem = "Exile_Item_RabbitSteak_Cooked";
    requiresFire = 1;
    returnedItems[] =
    {
        {1, "Exile_Item_RabbitSteak_Cooked"}
    };
    tools[] =
    {
        "DDR_Item_Pan"
    };
    components[] =
    {
        {1, "Exile_Item_RabbitSteak_Raw"}
    };
};
class CookRoosterFilet: Exile_AbstractCraftingRecipe
{
    name = "Cook Rooster Filet";
    pictureItem = "Exile_Item_RoosterFilet_Cooked";
    requiresFire = 1;
    returnedItems[] =
    {
        {1, "Exile_Item_RoosterFilet_Cooked"}
    };
    tools[] =
    {
        "DDR_Item_Pan"
    };
    components[] =
    {
        {1, "Exile_Item_RoosterFilet_Raw"}
    };
};
class CookSalemaFilet: Exile_AbstractCraftingRecipe
{
    name = "Cook Salema Filet";
    pictureItem = "Exile_Item_SalemaFilet_Cooked";
    requiresFire = 1;
    returnedItems[] =
    {
        {1, "Exile_Item_SalemaFilet_Cooked"}
    };
    tools[] =
    {
        "DDR_Item_Pan"
    };
    components[] =
    {
        {1, "Exile_Item_SalemaFilet_Raw"}
    };
};
class CookSheepSteak: Exile_AbstractCraftingRecipe
{
    name = "Cook Sheep Steak";
    pictureItem = "Exile_Item_SheepSteak_Cooked";
    requiresFire = 1;
    returnedItems[] =
    {
        {1, "Exile_Item_SheepSteak_Cooked"}
    };
    tools[] =
    {
        "DDR_Item_Pan"
    };
    components[] =
    {
        {1, "Exile_Item_SheepSteak_Raw"}
    };
};
class CookSnakeFilet: Exile_AbstractCraftingRecipe
{
    name = "Cook Snake Filet";
    pictureItem = "Exile_Item_SnakeFilet_Cooked";
    requiresFire = 1;
    returnedItems[] =
    {
        {1, "Exile_Item_SnakeFilet_Cooked"}
    };
    tools[] =
    {
        "DDR_Item_Pan"
    };
    components[] =
    {
        {1, "Exile_Item_SnakeFilet_Raw"}
    };
};
class CookTunaFilet: Exile_AbstractCraftingRecipe
{
    name = "Cook Tuna Filet";
    pictureItem = "Exile_Item_TunaFilet_Cooked";
    requiresFire = 1;
    returnedItems[] =
    {
        {1, "Exile_Item_TunaFilet_Cooked"}
    };
    tools[] =
    {
        "DDR_Item_Pan"
    };
    components[] =
    {
        {1, "Exile_Item_TunaFilet_Raw"}
    };
};
class CookTurtleFilet: Exile_AbstractCraftingRecipe
{
    name = "Cook Turtle Filet";
    pictureItem = "Exile_Item_TurtleFilet_Cooked";
    requiresFire = 1;
    returnedItems[] =
    {
        {1, "Exile_Item_TurtleFilet_Cooked"}
    };
    tools[] =
    {
        "DDR_Item_Pan"
    };
    components[] =
    {
        {1, "Exile_Item_TurtleFilet_Raw"}
    };
};