
class CfgFunctions
{
	
	// Add functions for DycE
	#include "cfgFunctions.hpp"
	
};

