	class Exile_Trader_Armory
	{
		name = "Wapons/Оружие";
		showWeaponFilter = 1;
		categories[] = 
		{
			"PointerAttachments",
			"BipodAttachments",
			"MuzzleAttachments",
			"OpticAttachments",
			"Ammunition",
			"Pistols",
			"Shotguns",
			"SubMachineGuns",
			"LightMachineGuns",
			"AssaultRifles",
			"SniperRifles",
			"APEXMuzzleAttachments",
			"APEXOpticAttachments",
			"APEXAmmunition",
			"APEXPistols",
			"APEXSubMachineGuns",
			"APEXAssaultRifles",
			"APEXSniperRifles",
			"CUPMuzzleAttachments",
			"CUPOpticAttachments",
			"CUPAmmunition",
			"CUPPistols",
			"CUPSubMachineGuns",
			"CUPLightMachineGuns",
			"CUPAssaultRifles",
			"CUPSniperRifles",			
			"RHSPointerAttachments",
			"RHSMuzzleAttachments",
			"RHSBipodAttachments",
			"RHSOpticAttachments",
			"RHSAmmunition",
			"RHSPistols",
			"RHSSubMachineGuns",
			"RHSLightMachineGuns",
			"RHSAssaultRifles",
			"RHSSniperRifles",
			"RFPointerAttachments",
			"RFMuzzleAttachments",
			"RFOpticAttachments",
			"RFAmmunition",
			"RFSubMachineGuns",
			"RFLightMachineGuns",
			"RFAssaultRifles",
			"RFSniperRifles"
		};
	};

	class Exile_Trader_SpecialOperations
	{
		name = "Special/Спец.товары";
		showWeaponFilter = 1;
		categories[] = 
		{
			"Flares",
			"Smokes",
			"UAVs",
			"StaticMGs",
			"StaticPVO",
			"Explosives",
			"Navigation",
			"Diving",
			"A3Launchers",
			"A3LauncherAmmo",
			"ApexLaunchers",
			"APEXLauncherAmmo",
			"CUPLaunchers",
			"CUPLauncherAmmo",
			"CUPExplosive",
			"RHSLaunchers",
			"RHSLauncherAmmo",
			"RHSNavigation",
			"RHSExplosive",
			"RHSExplosives",
			"RFLaunchers",
			"RFLauncherAmmo",
			"FirstAid"
		};
	};

	class Exile_Trader_Equipment
	{	
		name = "Clothes/Одежда";
		showWeaponFilter = 0;
		categories[] = 
		{
			"Headgear",
			"Glasses",
			"Uniforms",
			"Vests",
			"Backpacks",
			"APEXHeadgear",
		    "APEXUniforms",
			"APEXVests",
			"APEXBackpacks",
			"CUPHeadgear",
			"CUPUniforms",
			"CUPVests",
			"CUPBackpacks",
			"RHSHeadgear",
			"RHSUniforms",
			"RHSVests",
			"RFHeadgear",
			"RFGlasses",
			"RFUniforms",
			"RFVests",
			"RFBackpacks",
			"EBMBackpacks"
		};
	};
	
	class Exile_Trader_Food
	{
		name = "Food/Еда";
		showWeaponFilter = 0;
		categories[] = 
		{
			"Food",
			"Drinks"
		};
	};

	class Exile_Trader_Hardware
	{
		name = "Equipment/Снаряжение";
		showWeaponFilter = 0;
		categories[] = 
		{
			"Hardware",
			"Tools",
			"APEXTools",
			"CBuilding",
			"ExtendedBaseMod"
		};
	};

	class Exile_Trader_Vehicle
	{
		name = "Ground vehicles/Наземная техника";
		showWeaponFilter = 0;
		categories[] = 
		{
			"Cars",
			"ArmedCars",
			"Trucks",
			"Tank",
			"APEXCars",
			"APEXArmedCars",
			"APEXTrucks",
			"CUPUnarmed",
			"CUPTrucks",
			"CUPArmed",
			"CUPTanks",
			"RHSCars",
			"RHSTrucks",
			"RHSArmedCars",
			"RHSTanks",
			"RFCars",
			"RFTrucks",
			"RFArmedCars",
			"RFTanks",
			//"MASCars",
			//"MASTrucks",
			//"MASArmed",
			//"MASTanks",
			"A3UGVs",
			"Artillery"
		};
	};

	class Exile_Trader_Aircraft
	{
		name = "Air vehicles/Воздушная техника";
		showWeaponFilter = 0;
		categories[] = 
		{
			"Choppers",
			"ArmedChoppers",
			//"Planes",
			"ArmedPlanes",
		    "APEXPlanes",
			"APEXArmedPlanes",
			"CUPChoppers",
			"CUPArmedChoppers",
			"CUPPlanes",
			"CUPArmedPlanes",
			"RHSChoppers",
			"RHSArmedChoppers",
			"RHSPlanes",
			"RFChoppers",
			"RFArmedChoppers",
			"RFPlanes",
			//"MASChoppers",
			//"MASArmedChoppers",
			//"MASPlanes",
			"A3UAVs"
		};
	};

	class Exile_Trader_Boat
	{
		name = "Boats/Водная техника";
		showWeaponFilter = 0;
		categories[] = 
		{
			"Boats"
			//"ApexBoats",
			//"RHSBoats",
			//"CUPBoats"
		};
	};
/*
	class Exile_Trader_Diving
	{
		name = "Дайвинг";
		showWeaponFilter = 0;
		categories[] = 
		{
			"Diving"
		};
	};*/

	class Exile_Trader_CommunityCustoms
	{
		name = "Extended Survival Pack";
		showWeaponFilter = 0;
		categories[] = 
		{
            "Extended_Survival_Pack"
		};
	};

	class Exile_Trader_CommunityCustoms2
	{
		name = "Armed Air vehicles/Боевая авиация";
		showWeaponFilter = 0;
		categories[] = 
		{
			"Community2"
		};
	};

	class Exile_Trader_CommunityCustoms3
	{
		name = "3";
		showWeaponFilter = 0;
		categories[] = 
		{
           "Community3"
		};
	};

	class Exile_Trader_CommunityCustoms4
	{
		name = "4";
		showWeaponFilter = 0;
		categories[] = 
		{
			"Community4"
		};
	};

	class Exile_Trader_CommunityCustoms5
	{
		name = "5";
		showWeaponFilter = 0;
		categories[] = 
		{
			"Community5"
		};
	};

	class Exile_Trader_CommunityCustoms6
	{
		name = "6";
		showWeaponFilter = 0;
		categories[] = 
		{
			"Community6"
		};
	};

	class Exile_Trader_CommunityCustoms7
	{
		name = "7";
		showWeaponFilter = 0;
		categories[] = 
		{
			"Community7"
		};
	};

	class Exile_Trader_CommunityCustoms8
	{
		name = "8";
		showWeaponFilter = 0;
		categories[] = 
		{
			"Community8"
		};
	};

	class Exile_Trader_CommunityCustoms9
	{
		name = "9";
		showWeaponFilter = 0;
		categories[] = 
		{
			"Community9"
		};
	};

	class Exile_Trader_CommunityCustoms10
	{
		name = "10";
		showWeaponFilter = 0;
		categories[] = 
		{
			"Community10"
		};
	};