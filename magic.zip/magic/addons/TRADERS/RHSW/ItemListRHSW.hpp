	///////////////////////////////////////////////////////////////////////
	// Униформа
	///////////////////////////////////////////////////////////////////////
//	class rhs_uniform_gorka_r_yb              { quality = 1; price = 60; };
	class rhs_uniform_gorka_r_g               { quality = 2; price = 60; };
	class rhs_uniform_mflora_patchless        { quality = 2; price = 60; };
	class rhs_uniform_vdv_mflora              { quality = 2; price = 60; };
	class rhs_uniform_df15                    { quality = 2; price = 60; };
	class rhs_uniform_df15_tan                { quality = 2; price = 60; };
	class rhs_uniform_emr_patchless           { quality = 2; price = 60; };
	class rhs_uniform_vdv_emr                 { quality = 2; price = 60; };
	class rhs_uniform_emr_des_patchless       { quality = 2; price = 60; };
	class rhs_uniform_vdv_emr_des             { quality = 2; price = 60; };
	class rhs_uniform_mvd_izlom               { quality = 2; price = 60; };
	class rhs_uniform_m88_patchless           { quality = 2; price = 60; };
	class rhs_uniform_flora_patchless         { quality = 2; price = 60; };
	class rhs_uniform_flora_patchless_alt     { quality = 2; price = 60; };
	class rhs_uniform_vdv_flora               { quality = 2; price = 60; };
	class rhs_uniform_vmf_flora               { quality = 2; price = 60; };
	class rhs_uniform_vmf_flora_subdued       { quality = 2; price = 60; };
	class rhs_uniform_flora                   { quality = 2; price = 60; };
	class rhs_uniform_rva_flora               { quality = 2; price = 60; };
	//USA
	class rhs_uniform_cu_ocp_101st            { quality = 2; price = 60; };             
	class rhs_uniform_cu_ocp_10th             { quality = 2; price = 60; };
	class rhs_uniform_cu_ocp_1stcav           { quality = 2; price = 60; };
	class rhs_uniform_cu_ocp_82nd             { quality = 2; price = 60; };
	class rhs_uniform_cu_ucp_101st            { quality = 2; price = 60; };
	class rhs_uniform_cu_ucp_10th             { quality = 2; price = 60; };
	class rhs_uniform_cu_ucp_1stcav           { quality = 2; price = 60; };
	class rhs_uniform_cu_ucp_82nd             { quality = 2; price = 60; };
	class rhs_uniform_FROG01_d                { quality = 2; price = 60; };
	class rhs_uniform_FROG01_wd               { quality = 2; price = 60; };
	class rhs_uniform_g3_blk                  { quality = 2; price = 60; };
	class rhs_uniform_g3_m81                  { quality = 2; price = 60; };
	class rhs_uniform_g3_mc                   { quality = 2; price = 60; };
	class rhs_uniform_g3_rgr                  { quality = 2; price = 60; };
	class rhs_uniform_g3_tan                  { quality = 2; price = 60; };
	
	//////////////////////////////////////////////////////////////////////////////////////
	// Бронежилеты
	//////////////////////////////////////////////////////////////////////////////////////
	class rhs_6b13_Flora_6sh92_vog            { quality = 3; price = 70; };
	class rhs_6b13_Flora_6sh92_radio          { quality = 3; price = 70; };
	class rhs_6b13_6sh92_vog                  { quality = 3; price = 70; };
	class rhs_6b13_6sh92_radio                { quality = 3; price = 70; };
	class rhs_6b13_EMR_6sh92_vog              { quality = 3; price = 70; };
	class rhs_6b13_EMR_6sh92_radio            { quality = 3; price = 70; };
	class rhs_6b23_6sh116_vog_od              { quality = 3; price = 70; };
	class rhs_6b23_6sh92_vog                  { quality = 3; price = 70; };
	class rhs_6b23_6sh92_vog_headset          { quality = 3; price = 70; };
	class rhs_6b23_6sh92_radio                { quality = 3; price = 70; };
	class rhs_6b23_digi_6sh92_Vog_Radio_Spetsnaz   { quality = 3; price = 70; };
	class rhs_6b23_digi_6sh92_headset_spetsnaz     { quality = 3; price = 70; };
	class rhs_6b23_digi_6sh92_Spetsnaz        { quality = 3; price = 70; };
	class rhs_6b23_ML_6sh92_vog               { quality = 3; price = 70; };
	class rhs_6b23_ML_6sh92_vog_headset       { quality = 3; price = 70; };
	class rhs_6b23_ML_6sh92_radio             { quality = 3; price = 70; };
	class rhs_6b23_6sh116_vog                 { quality = 3; price = 70; };
	class rhs_6b23_digi_6sh92_vog             { quality = 3; price = 70; };
	class rhs_6b23_digi_6sh92_vog_headset     { quality = 3; price = 70; };
	class rhs_6b23_digi_6sh92_radio           { quality = 3; price = 70; };
	class rhs_6b23_digi_6sh92_Vog_Spetsnaz    { quality = 3; price = 70; };
	class rhs_6b23_6sh116_vog_flora           { quality = 3; price = 70; };
	class rhs_6sh92_vog                       { quality = 3; price = 70; };
	class rhs_6sh92_vog_headset               { quality = 3; price = 70; };
	class rhs_6sh92_radio                     { quality = 3; price = 70; };
	class rhs_6sh92_vsr_vog                   { quality = 3; price = 70; };
	class rhs_6sh92_vsr_vog_headset           { quality = 3; price = 70; };
	class rhs_6sh92_vsr_radio                 { quality = 3; price = 70; };
	class rhs_6sh92_digi_vog                  { quality = 3; price = 70; };
	class rhs_6sh92_digi_vog_headset          { quality = 3; price = 70; };
	class rhs_6sh92_digi_radio                { quality = 3; price = 70; };
	//USA
	class rhsusf_iotv_ocp_Grenadier           { quality = 3; price = 70; };       
	class rhsusf_iotv_ucp_Grenadier           { quality = 3; price = 70; };
	class rhsusf_iotv_ocp_Medic               { quality = 3; price = 70; };
	class rhsusf_iotv_ucp_Medic               { quality = 3; price = 70; };
	class rhsusf_iotv_ocp_Repair              { quality = 3; price = 70; };
	class rhsusf_iotv_ucp_Repair              { quality = 3; price = 70; };
	class rhsusf_iotv_ocp_Squadleader         { quality = 3; price = 70; };
	class rhsusf_iotv_ucp_Squadleader         { quality = 3; price = 70; };
	class rhsusf_iotv_ocp_Teamleader          { quality = 3; price = 70; };
	class rhsusf_iotv_ucp_Teamleader          { quality = 3; price = 70; };
	class rhsusf_spc_squadleader              { quality = 3; price = 70; };
	class rhsusf_spc_teamleader               { quality = 3; price = 70; };
	
	//////////////////////////////////////////////////////////////////////////////////////
	// Головные уборы|Шлемы
	//////////////////////////////////////////////////////////////////////////////////////
	class rhs_6b26_bala                       { quality = 2; price = 80; };
	class rhs_6b26_ess                        { quality = 2; price = 80; };
	class rhs_6b26_ess_bala                   { quality = 2; price = 80; };
	class rhs_6b27m_ml_bala                   { quality = 2; price = 80; };
	class rhs_6b27m_ml_ess                    { quality = 2; price = 80; };
	class rhs_6b27m_ML_ess_bala               { quality = 2; price = 80; };
	class rhs_6b27m_digi_bala                 { quality = 2; price = 80; };
	class rhs_6b27m_digi_ess_bala             { quality = 2; price = 80; };
	class rhs_6b27m_bala                      { quality = 2; price = 80; };
	class rhs_6b27m_ess                       { quality = 2; price = 80; };
	class rhs_6b27m_ess_bala                  { quality = 2; price = 80; };
	class rhs_6b28_bala                       { quality = 2; price = 80; };
	class rhs_6b28_ess                        { quality = 2; price = 80; };
	class rhs_6b28_ess_bala                   { quality = 2; price = 80; };
	class rhs_6b47_bala                       { quality = 2; price = 80; };
	class rhs_6b47_ess                        { quality = 2; price = 80; };
	class rhs_6b47_ess_bala                   { quality = 2; price = 80; };
	class rhs_6b7_1m_bala2_emr                { quality = 2; price = 80; };
	class rhs_6b7_1m_bala1_emr                { quality = 2; price = 80; };
	class rhs_6b7_1m_bala2_olive              { quality = 2; price = 80; };
	class rhs_6b7_1m_bala1_olive              { quality = 2; price = 80; };
	class rhs_beret_mp1                       { quality = 1; price = 35; };//берет
	class rhs_beret_mp2                       { quality = 1; price = 25; };
	class rhs_beret_vdv1                      { quality = 1; price = 25; };
	class rhs_beret_vdv2                      { quality = 1; price = 25; };
	class rhs_beret_vdv3                      { quality = 1; price = 25; };
	class rhs_beret_milp                      { quality = 1; price = 35; };//берет
	class rhs_altyn_novisor                   { quality = 2; price = 80; };
	class rhs_altyn_novisor_bala              { quality = 2; price = 80; };
	class rhs_altyn_novisor_ess               { quality = 2; price = 80; };
	class rhs_altyn_novisor_ess_bala          { quality = 2; price = 80; };
	class rhs_altyn_visordown                 { quality = 2; price = 80; };
	class rhs_altyn                           { quality = 2; price = 80; };
	class rhs_altyn_bala                      { quality = 2; price = 80; };
	class rhs_zsh7a_mike_green_alt            { quality = 2; price = 80; };
	class rhs_zsh7a_mike_alt                  { quality = 2; price = 80; };
	class rhs_zsh7a                           { quality = 2; price = 80; };
	class rhs_zsh7a_alt                       { quality = 2; price = 80; };
	class rhs_tsh4                            { quality = 4; price = 90; };//шлемофон
	class rhs_tsh4_bala                       { quality = 4; price = 90; };//шлемофон
	class rhs_tsh4_ess                        { quality = 4; price = 90; };//шлемофон
	class rhs_tsh4_ess_bala                   { quality = 4; price = 90; };//шлемофон
	 //USA
	class rhsusf_ach_bare_des_headset         { quality = 2; price = 80; };    
	class rhsusf_ach_bare_des_headset_ess     { quality = 2; price = 80; };
	class rhsusf_ach_bare_semi_headset        { quality = 2; price = 80; };
	class rhsusf_ach_bare_semi_headset_ess    { quality = 2; price = 80; };
	class rhsusf_ach_bare_tan_headset         { quality = 2; price = 80; };
	class rhsusf_ach_bare_tan_headset_ess     { quality = 2; price = 80; };
	class rhsusf_ach_bare_wood_headset        { quality = 2; price = 80; };
	class rhsusf_ach_bare_wood_headset_ess    { quality = 2; price = 80; };
	class rhsusf_ach_helmet_headset_ucp       { quality = 2; price = 80; };
	class rhsusf_ach_helmet_headset_ess_ucp   { quality = 2; price = 80; };
	class rhsusf_cvc_green_alt_helmet         { quality = 2; price = 80; };
	class rhsusf_cvc_green_ess                { quality = 2; price = 80; };
	class rhsusf_cvc_alt_helmet               { quality = 2; price = 80; };
	class rhsusf_cvc_ess                      { quality = 2; price = 80; };
	class rhsusf_Bowman                       { quality = 1; price = 25; };
	class rhsusf_bowman_cap                   { quality = 1; price = 25; };
	class rhs_xmas_antlers                    { quality = 1; price = 25; };
	class rhsusf_opscore_aor1_pelt            { quality = 2; price = 80; };
	class rhsusf_opscore_aor1_pelt_nsw        { quality = 2; price = 80; };
	class rhsusf_opscore_bk_pelt              { quality = 2; price = 80; };
	class rhsusf_opscore_coy_cover_pelt       { quality = 2; price = 80; };
	class rhsusf_opscore_fg_pelt_cam          { quality = 2; price = 80; };
	class rhsusf_opscore_fg_pelt_nsw          { quality = 2; price = 80; };
	class rhsusf_hgu56p_black                 { quality = 2; price = 80; };
	class rhsusf_hgu56p_mask_black            { quality = 2; price = 80; };
	class rhsusf_hgu56p_mask_black_skull      { quality = 2; price = 80; };
	class rhsusf_hgu56p_visor_black           { quality = 2; price = 80; };
	class rhsusf_hgu56p_visor_mask_black      { quality = 2; price = 80; };
	class rhsusf_hgu56p_visor_mask_Empire_black  { quality = 2; price = 80; };
	class rhsusf_hgu56p_visor_mask_black_skull   { quality = 2; price = 80; };
	class rhsusf_hgu56p_usa                   { quality = 2; price = 80; };
	class rhsusf_hgu56p_visor_usa             { quality = 2; price = 80; };
	class RHS_jetpilot_usaf                   { quality = 2; price = 80; };
	
	//////////////////////////////////////////////////////////////////////////////////////
	// Защита лица
	//////////////////////////////////////////////////////////////////////////////////////
	class rhsusf_shemagh_grn                    { quality = 1; price = 20; };
	class rhsusf_shemagh2_grn                   { quality = 1; price = 20; };
	class rhsusf_shemagh_od                     { quality = 1; price = 20; };
	class rhsusf_shemagh2_od                    { quality = 1; price = 20; };
	class rhsusf_shemagh_tan                    { quality = 1; price = 20; };
	class rhsusf_shemagh2_tan                   { quality = 1; price = 20; };
	class rhsusf_shemagh_white                  { quality = 1; price = 20; };
	class rhsusf_shemagh2_white                 { quality = 1; price = 20; };
	class rhsusf_shemagh_gogg_grn               { quality = 1; price = 30; };
	class rhsusf_shemagh2_gogg_grn              { quality = 1; price = 30; };
	class rhsusf_shemagh_gogg_od                { quality = 1; price = 30; };
	class rhsusf_shemagh2_gogg_od               { quality = 1; price = 30; };
	class rhsusf_shemagh_gogg_tan               { quality = 1; price = 30; };
	class rhsusf_shemagh2_gogg_tan              { quality = 1; price = 30; };
	class rhsusf_shemagh_gogg_white             { quality = 1; price = 30; };
	class rhsusf_shemagh2_gogg_white            { quality = 1; price = 30; };
	class rhsusf_oakley_goggles_blk             { quality = 1; price = 15; };
	class rhsusf_oakley_goggles_clr             { quality = 1; price = 15; };
	class rhsusf_oakley_goggles_ylw             { quality = 1; price = 15; };
	class rhs_googles_clear                     { quality = 1; price = 15; };
	class rhs_googles_orange                    { quality = 1; price = 15; };
	class rhs_googles_yellow                    { quality = 1; price = 15; };
	class rhs_ess_black                         { quality = 1; price = 15; };
	class rhs_googles_black                     { quality = 1; price = 15; };
	class rhs_balaclava                         { quality = 1; price = 30; };
	class rhs_balaclava1_olive                  { quality = 1; price = 30; };
	class rhs_scarf                             { quality = 1; price = 20; };
	 
	//////////////////////////////////////////////////////////////////////////////////////
	// Пистолеты
	//////////////////////////////////////////////////////////////////////////////////////
	class rhs_weap_pb_6p9                    { quality = 2; price = 500; sellPrice = 15; };
	class rhs_weap_makarov_pm                { quality = 2; price = 500; };
	class rhs_weap_pya                       { quality = 2; price = 500; };
	class rhsusf_weap_glock17g4              { quality = 2; price = 500; };
	class rhsusf_weap_m9                     { quality = 2; price = 500; };
	class rhsusf_weap_m1911a1                { quality = 2; price = 500; };
	
	///////////////////////////////////////////////////////////////////////
	// Пист.пулемёты,дробовики
	///////////////////////////////////////////////////////////////////////
	class rhs_weap_pp2000_folded             { quality = 3; price = 1500; };
	class rhs_weap_M320                      { quality = 3; price = 1500; };
	class rhs_weap_pp2000                    { quality = 3; price = 1500; };
	class rhs_weap_M590_8RD                  { quality = 3; price = 1500; };
	class rhs_weap_M590_5RD                  { quality = 3; price = 1500; };
	class rhsusf_weap_MP7A2                  { quality = 3; price = 1500; };
	class rhsusf_weap_MP7A2_aor1             { quality = 3; price = 1500; };
	class rhsusf_weap_MP7A2_desert           { quality = 3; price = 1500; };
	class rhsusf_weap_MP7A2_winter           { quality = 3; price = 1500; };
	
	///////////////////////////////////////////////////////////////////////
	// Пулемёты
	///////////////////////////////////////////////////////////////////////
	class rhs_weap_pkm                   { quality = 4; price = 15000; };
	class rhs_weap_pkp                   { quality = 4; price = 15000; };
	class rhs_weap_m240B                 { quality = 4; price = 15000; };
	class rhs_weap_m249_pip_S_vfg        { quality = 4; price = 15000; };
	class rhs_weap_m249_pip              { quality = 4; price = 15000; };

	///////////////////////////////////////////////////////////////////
    // Автоматы	
	///////////////////////////////////////////////////////////////////
/*	class rhs_weap_ak105                 { quality = 3; price = 5000; sellPrice = 50; };
	class rhs_weap_ak103_npz             { quality = 3; price = 5000; sellPrice = 50; };
	class rhs_weap_ak103_gp25_npz        { quality = 3; price = 6000; sellPrice = 60; };
	class rhs_weap_ak105_npz             { quality = 3; price = 5000; sellPrice = 50; };
	class rhs_weap_ak74                  { quality = 3; price = 5000; sellPrice = 50; };
	class rhs_weap_ak74_gp25             { quality = 3; price = 6000; sellPrice = 60; };
	class rhs_weap_ak74m_2mag_npz        { quality = 3; price = 5000; sellPrice = 50; };
	class rhs_weap_ak74m_2mag_camo       { quality = 3; price = 5000; sellPrice = 50; };
	class rhs_weap_ak74m_gp25            { quality = 3; price = 6000; sellPrice = 60; };
	class rhs_weap_ak74n_npz             { quality = 3; price = 5000; sellPrice = 50; };
	class rhs_weap_ak74n_gp25_npz        { quality = 3; price = 6000; sellPrice = 60; };*/
	class rhs_weap_asval_grip_npz        { quality = 4; price = 7000; };
	class rhs_weap_asval_npz             { quality = 4; price = 7000; };
	class rhs_weap_hk416d10              { quality = 4; price = 8000; };
	class rhs_weap_hk416d10_m320         { quality = 5; price = 9000; };
	class rhs_weap_hk416d10_LMT_d        { quality = 4; price = 8000; };
	class rhs_weap_hk416d10_LMT_wd       { quality = 4; price = 8000; };
	class rhs_weap_hk416d145             { quality = 4; price = 8000; };
	class rhs_weap_hk416d145_d           { quality = 4; price = 8000; };
	class rhs_weap_hk416d145_d_2         { quality = 4; price = 8000; };
	class rhs_weap_hk416d145_m320        { quality = 5; price = 9000; };
	class rhs_weap_m27iar                { quality = 4; price = 8000; };
	class rhs_weap_m27iar_grip           { quality = 4; price = 8000; };
	class rhs_weap_m4_carryhandle_mstock { quality = 4; price = 8000; };
	class rhs_weap_m4a1_blockII_d        { quality = 4; price = 8000; };
	class rhs_weap_m4a1_blockII_M203_d   { quality = 5; price = 9000; };
	class rhs_weap_mk18_KAC_bk           { quality = 4; price = 8000; };
	class rhs_weap_mk18_KAC_d            { quality = 4; price = 8000; };
	class rhs_weap_mk18_m320             { quality = 5; price = 9000; };
	class rhs_weap_m16a4                 { quality = 4; price = 8000; };
	class rhs_weap_m16a4_pmag            { quality = 4; price = 8000; };
	class rhs_weap_m16a4_carryhandle     { quality = 4; price = 8000; };
	class rhs_weap_m16a4_carryhandle_pmag  { quality = 4; price = 8000; };
	class rhs_weap_m16a4_carryhandle_M203  { quality = 5; price = 9000; };
	
	///////////////////////////////////////////////////////////////////
	// Снайперские винтовки
	///////////////////////////////////////////////////////////////////
	class rhs_weap_t5000                { quality = 5; price = 12000; };
	class rhs_weap_vss_grip_npz         { quality = 5; price = 12000; };
	class rhs_weap_vss_npz              { quality = 5; price = 12000; };
	class rhs_weap_svdp_wd_npz          { quality = 5; price = 12000; };
	class rhs_weap_svdp_npz             { quality = 5; price = 12000; };
	class rhs_weap_M107                 { quality = 6; price = 16000; };
	class rhs_weap_M107_d               { quality = 6; price = 16000; };
	class rhs_weap_M107_w               { quality = 6; price = 16000; };
	class rhs_weap_m14ebrri             { quality = 5; price = 12000; };
	class rhs_weap_m24sws               { quality = 5; price = 12000; };
	class rhs_weap_m24sws_blk           { quality = 5; price = 12000; };
	class rhs_weap_m24sws_ghillie       { quality = 5; price = 12000; };
	class rhs_weap_m40a5                { quality = 5; price = 12000; };
	class rhs_weap_m40a5_d              { quality = 5; price = 12000; };
	class rhs_weap_m40a5_wd             { quality = 5; price = 12000; };
	class rhs_weap_sr25                 { quality = 5; price = 12000; };
	class rhs_weap_sr25_d               { quality = 5; price = 12000; };
	class rhs_weap_sr25_ec              { quality = 5; price = 12000; };
	class rhs_weap_sr25_ec_d            { quality = 5; price = 12000; };
	class rhs_weap_sr25_ec_wd           { quality = 5; price = 12000; };
	class rhs_weap_sr25_wd              { quality = 5; price = 12000; };
	class rhs_weap_XM2010               { quality = 5; price = 12000; };
	class rhs_weap_XM2010_wd            { quality = 5; price = 12000; };
	class rhs_weap_XM2010_sa            { quality = 5; price = 12000; };
	class rhs_weap_XM2010_d	            { quality = 5; price = 12000; };
	
	///////////////////////////////////////////////////////////////////
	// Вспомогательное
	///////////////////////////////////////////////////////////////////
	class acc_flashlight_pistol            { quality = 1; price = 25; sellPrice = 0.5; };
	class rhs_acc_2dpZenit                 { quality = 1; price = 25; sellPrice = 0.5; };
	class rhs_acc_perst1ik                 { quality = 1; price = 25; sellPrice = 0.5; };
	class rhs_acc_2dpZenit_ris             { quality = 1; price = 25; sellPrice = 0.5; };
	class rhs_acc_perst1ik_ris             { quality = 1; price = 25; sellPrice = 0.5; };
	class rhs_acc_perst3                   { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_anpeq15side           { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_anpeq15_top           { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_anpeq15_wmx           { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_anpeq15side_bk        { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_anpeq15_bk_top        { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_anpeq15               { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_anpeq15_bk            { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_anpeq15A              { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_anpeq16a_top          { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_anpeq16a              { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_M952V                 { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_wmx                   { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_wmx_bk                { quality = 1; price = 25; sellPrice = 0.5; };
	
	////////////////////////////////////////////////////////////////////////////////////////
	// Оптика
	////////////////////////////////////////////////////////////////////////////////////////
	class rhs_acc_1p29                 { quality = 2; price = 120; sellPrice = 5; };
	class rhs_acc_1p63                 { quality = 2; price = 120; sellPrice = 5; };
	class rhs_acc_1p78                 { quality = 3; price = 150; sellPrice = 5; };
	class rhs_acc_1pn93_1              { quality = 3; price = 150; sellPrice = 5; };
	class rhs_acc_1pn93_2              { quality = 3; price = 150; sellPrice = 5; };
	class rhs_acc_ekp1c                { quality = 2; price = 120; sellPrice = 5; };
	class rhs_acc_ekp8_02              { quality = 2; price = 120; sellPrice = 5; };
	class rhs_acc_nita                 { quality = 3; price = 150; sellPrice = 5; };
//	class rhs_acc_pgo7v_ak             { quality = 3; price = 180; sellPrice = 5; };
//	class rhs_acc_pgo7v2_ak            { quality = 3; price = 180; sellPrice = 5; };
//	class rhs_acc_pgo7v3_ak            { quality = 3; price = 180; sellPrice = 5; };
	class rhs_acc_pkas                 { quality = 2; price = 120; sellPrice = 5; };
//	class rhs_acc_pso1m2_ak            { quality = 4; price = 280; sellPrice = 5; };
//	class rhs_acc_pso1m21_ak           { quality = 4; price = 200; sellPrice = 5; };
	class rhs_acc_rakursPM             { quality = 2; price = 120; sellPrice = 5; };
	class rhs_acc_1p87                 { quality = 2; price = 120; sellPrice = 5; };
	class rhs_acc_dh520x56             { quality = 4; price = 200; sellPrice = 5; };
	class rhs_acc_ekp8_18              { quality = 2; price = 120; sellPrice = 5; };
	class rhsusf_acc_M2A1              { quality = 2; price = 120; sellPrice = 5; };
	class rhsusf_acc_T1_high           { quality = 2; price = 120; sellPrice = 5; };
	class rhsusf_acc_T1_low            { quality = 2; price = 120; sellPrice = 5; };
	class rhsusf_acc_anpas13gv1        { quality = 5; price = 300; sellPrice = 5; };
	class rhsusf_acc_ACOG2_USMC        { quality = 3; price = 180; sellPrice = 5; };
	class rhsusf_acc_ACOG3_USMC        { quality = 3; price = 180; sellPrice = 5; };
	class rhsusf_acc_ACOG_USMC         { quality = 3; price = 180; sellPrice = 5; };
	class rhsusf_acc_anpvs27           { quality = 4; price = 200; sellPrice = 5; };
	class rhsusf_acc_EOTECH            { quality = 2; price = 120; sellPrice = 5; };
	class rhsusf_acc_g33_T1            { quality = 2; price = 140; sellPrice = 5; };
	class rhsusf_acc_g33_xps3          { quality = 2; price = 140; sellPrice = 5; };
	class rhsusf_acc_g33_xps3_tan      { quality = 2; price = 140; sellPrice = 5; };
	class rhsusf_acc_ELCAN             { quality = 2; price = 140; sellPrice = 5; };
	class rhsusf_acc_ELCAN_ard         { quality = 2; price = 140; sellPrice = 5; };
	class rhsusf_acc_ACOG              { quality = 2; price = 140; sellPrice = 5; };
	class rhsusf_acc_ACOG2             { quality = 2; price = 140; sellPrice = 5; };
	class rhsusf_acc_ACOG_anpvs27      { quality = 3; price = 180; sellPrice = 5; };
	class rhsusf_acc_eotech_552        { quality = 2; price = 120; sellPrice = 5; };
	class rhsusf_acc_eotech_552_d      { quality = 2; price = 120; sellPrice = 5; };
	class rhsusf_acc_compm4            { quality = 2; price = 120; sellPrice = 5; };
	class rhsusf_acc_M8541             { quality = 4; price = 200; sellPrice = 5; };
	class rhsusf_acc_M8541_low         { quality = 4; price = 200; sellPrice = 5; };
	class rhsusf_acc_M8541_low_d       { quality = 4; price = 200; sellPrice = 5; };
	class rhsusf_acc_premier_anpvs27   { quality = 4; price = 280; sellPrice = 5; };
	class rhsusf_acc_LEUPOLDMK4_2      { quality = 4; price = 200; sellPrice = 5; };
	class rhsusf_acc_LEUPOLDMK4_2_d    { quality = 4; price = 200; sellPrice = 5; };
	class rhsusf_acc_RM05              { quality = 2; price = 120; sellPrice = 5; };
	class rhsusf_acc_RX01_NoFilter     { quality = 2; price = 120; sellPrice = 5; };
	class rhsusf_acc_RX01              { quality = 2; price = 120; sellPrice = 5; };
	class rhsusf_acc_SpecterDR         { quality = 3; price = 180; sellPrice = 5; };
	class rhsusf_acc_ACOG_MDO          { quality = 4; price = 200; sellPrice = 5; };
	class rhsusf_acc_ACOG_RMR          { quality = 3; price = 180; sellPrice = 5; };
	class rhsusf_acc_eotech_xps3       { quality = 3; price = 180; sellPrice = 5; };
	class rhs_acc_pgo7v                { quality = 3; price = 180; sellPrice = 5; };
	class rhs_acc_pgo7v2               { quality = 3; price = 180; sellPrice = 5; };
	class rhs_acc_pgo7v3               { quality = 3; price = 180; sellPrice = 5; };
	class rhs_optic_maaws              { quality = 4; price = 200; sellPrice = 5; };
	class rhs_weap_optic_smaw          { quality = 4; price = 200; sellPrice = 5; };
	
	////////////////////////////////////////////////////////////////
	//  Глушители
	////////////////////////////////////////////////////////////////
	class rhs_acc_6p9_suppressor       { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_omega9k           { quality = 1; price = 25; sellPrice = 0.5; };
	class rhs_acc_uuk                  { quality = 1; price = 25; sellPrice = 0.5; };
//	class rhs_acc_ak5                  { quality = 1; price = 25; sellPrice = 0.5; };
	class rhs_acc_dtk                  { quality = 1; price = 25; sellPrice = 0.5; };
	class rhs_acc_dtk1                 { quality = 1; price = 25; sellPrice = 0.5; };
	class rhs_acc_dtk2                 { quality = 1; price = 25; sellPrice = 0.5; };
	class rhs_acc_dtk3                 { quality = 1; price = 25; sellPrice = 0.5; };
	class rhs_acc_dtk4short            { quality = 1; price = 25; sellPrice = 0.5; };
	class rhs_acc_dtk1983              { quality = 1; price = 25; sellPrice = 0.5; };
	class rhs_acc_pgs64                { quality = 1; price = 25; sellPrice = 0.5; };
	class rhs_acc_tgpa                 { quality = 1; price = 25; sellPrice = 0.5; };
	class rhs_acc_tgpv                 { quality = 1; price = 25; sellPrice = 0.5; };
	class rhs_acc_tgpv2                { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_nt4_black         { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_nt4_tan           { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_rotex5_tan        { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_rotex5_grey       { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_SF3P556           { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_SFMB556           { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_ARDEC_M240        { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_SR25S             { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_SR25S_d           { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_SR25S_wd          { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_rotex_mp7_aor1    { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_rotex_mp7         { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_rotex_mp7_desert  { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_rotex_mp7_winter  { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_M2010S            { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_M2010S_d          { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_M2010S_sa         { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_M2010S_wd         { quality = 1; price = 25; sellPrice = 0.5; };
	
	////////////////////////////////////////////////////////////////
	// Сошки
	////////////////////////////////////////////////////////////////
	class rhs_acc_harris_swivel        { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_harris_bipod      { quality = 1; price = 25; sellPrice = 0.5; };
	class rhs_acc_grip_ffg2            { quality = 1; price = 25; sellPrice = 0.5; };
	class rhs_acc_grip_rk2             { quality = 1; price = 25; sellPrice = 0.5; };
	class rhs_acc_grip_rk6             { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_grip2             { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_grip2_tan         { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_grip2_wd          { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_grip1             { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_grip3             { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_grip3_tan         { quality = 1; price = 25; sellPrice = 0.5; };
	class rhsusf_acc_harris_swivel	   { quality = 1; price = 25; sellPrice = 0.5; };
	
	//////////////////////////////////////////////////////////////////////////////////
	// Патроны
	//////////////////////////////////////////////////////////////////////////////////
//	class rhs_mag_9x18_8_57N181S                         { quality = 1; price = 30; };//патроны для пистолета
	class rhs_mag_9x19_17                                { quality = 1; price = 30; };//патроны для пистолета
	class rhsusf_mag_17Rnd_9x19_JHP                      { quality = 1; price = 30; };//патроны для пистолета
	class rhsusf_mag_17Rnd_9x19_FMJ                      { quality = 1; price = 30; };//патроны для пистолета
	class rhsusf_mag_15Rnd_9x19_JHP                      { quality = 1; price = 30; };//патроны для пистолета
	class rhsusf_mag_15Rnd_9x19_FMJ                      { quality = 1; price = 30; };//патроны для пистолета
	class rhsusf_mag_7x45acp_MHP                         { quality = 1; price = 30; };//патроны для пистолета
	class rhs_mag_9x19mm_7n21_20                         { quality = 2; price = 50; };//патроны для Пист.пулемёты
	class rhs_mag_9x19mm_7n31_20                         { quality = 2; price = 50; };//патроны для Пист.пулемёты
	class rhs_mag_9x19mm_7n21_44                         { quality = 2; price = 50; };//патроны для Пист.пулемёты
	class rhs_mag_9x19mm_7n31_44                         { quality = 2; price = 50; };//патроны для Пист.пулемёты
//	class rhs_30Rnd_545x39_AK                            { quality = 3; price = 60; };//патроны для автоматов
//	class rhs_30Rnd_545x39_AK_no_tracers                 { quality = 3; price = 60; };//патроны для автоматов
//	class rhs_30Rnd_545x39_7N6_AK                        { quality = 3; price = 60; };//патроны для автоматов
//	class rhs_30Rnd_545x39_7N10_AK                       { quality = 3; price = 60; };//патроны для автоматов
//	class rhs_30Rnd_545x39_7N22_AK                       { quality = 3; price = 60; };//патроны для автоматов
//	class rhs_30Rnd_545x39_AK_green                      { quality = 3; price = 60; };//патроны для автоматов
//	class rhs_30Rnd_545x39_7U1_AK                        { quality = 3; price = 60; };//патроны для автоматов
//	class rhs_45Rnd_545X39_AK                            { quality = 3; price = 60; };//патроны для автоматов
//	class rhs_45Rnd_545X39_7N6_AK                        { quality = 3; price = 60; };//патроны для автоматов
//	class rhs_45Rnd_545X39_7N10_AK                       { quality = 3; price = 60; };//патроны для автоматов
//	class rhs_45Rnd_545X39_7N22_AK                       { quality = 3; price = 60; };//патроны для автоматов
//	class rhs_45Rnd_545X39_AK_Green                      { quality = 3; price = 60; };//патроны для автоматов
//	class rhs_45Rnd_545X39_7U1_AK                        { quality = 3; price = 60; };//патроны для автоматов
	class rhs_5Rnd_338lapua_t5000                        { quality = 5; price = 70; };//патроны для снапы
	class rhs_30Rnd_762x39mm                             { quality = 3; price = 60; };//патроны для автоматов
	class rhs_30Rnd_762x39mm_tracer                      { quality = 3; price = 60; };//патроны для автоматов
	class rhs_30Rnd_762x39mm_89                          { quality = 3; price = 60; };//патроны для автоматов
	class rhs_30Rnd_762x39mm_U                           { quality = 3; price = 60; };//патроны для автоматов
	class rhs_20rnd_9x39mm_SP5                           { quality = 3; price = 60; };//патроны для автоматов
	class rhs_20rnd_9x39mm_SP6                           { quality = 3; price = 60; };//патроны для автоматов
	class rhs_10rnd_9x39mm_SP5                           { quality = 3; price = 60; };//патроны для автоматов
	class rhs_10rnd_9x39mm_SP6                           { quality = 3; price = 60; };//патроны для автоматов
	class rhs_100Rnd_762x54mmR                           { quality = 4; price = 80; };//патроны для пулемёта
	class rhs_100Rnd_762x54mmR_green                     { quality = 4; price = 80; };//патроны для пулемёта
	class rhs_100Rnd_762x54mmR_7N13                      { quality = 4; price = 80; };//патроны для пулемёта
	class rhs_100Rnd_762x54mmR_7N26                      { quality = 4; price = 80; };//патроны для пулемёта
	class rhs_100Rnd_762x54mmR_7BZ3                      { quality = 4; price = 80; };//патроны для пулемёта
	class rhs_10Rnd_762x54mmR_7N1                        { quality = 5; price = 70; };//патроны для снапы
	class rhs_mag_30Rnd_556x45_M855_Stanag               { quality = 3; price = 60; };//патроны для автоматов
	class rhs_mag_30Rnd_556x45_M855_Stanag_Tracer_Red    { quality = 3; price = 60; };//патроны для автоматов
	class rhs_mag_30Rnd_556x45_M855_Stanag_Tracer_Green  { quality = 3; price = 60; };//патроны для автоматов
	class rhs_mag_30Rnd_556x45_M855_Stanag_Tracer_Yellow { quality = 3; price = 60; };//патроны для автоматов
	class rhs_mag_30Rnd_556x45_M855_Stanag_Tracer_Orange { quality = 3; price = 60; };//патроны для автоматов
	class rhs_mag_30Rnd_556x45_M855A1_Stanag             { quality = 3; price = 60; };//патроны для автоматов
	class rhs_mag_30Rnd_556x45_M855A1_Stanag_No_Tracer   { quality = 3; price = 60; };//патроны для автоматов
	class rhs_mag_30Rnd_556x45_M855A1_Stanag_Tracer_Red  { quality = 3; price = 60; };//патроны для автоматов
	class rhs_mag_30Rnd_556x45_M855A1_Stanag_Tracer_Green { quality = 3; price = 60; };//патроны для автоматов
	class rhs_mag_30Rnd_556x45_M855A1_Stanag_Tracer_Yellow { quality = 3; price = 60; };//патроны для автоматов
	class rhs_mag_30Rnd_556x45_M855A1_Stanag_Tracer_Orange { quality = 3; price = 60; };//патроны для автоматов
	class rhs_mag_30Rnd_556x45_Mk318_Stanag              { quality = 3; price = 60; };//патроны для автоматов
//	class rhs_mag_30Rnd_556x45_Mk262_Stanag              { quality = 3; price = 60; };//патроны для автоматов
	class rhs_mag_30Rnd_556x45_M200_Stanag               { quality = 3; price = 60; };//патроны для автоматов
	class rhsusf_mag_10Rnd_STD_50BMG_M33                 { quality = 5; price = 70; };//патроны для снапы
//	class rhsusf_mag_10Rnd_STD_50BMG_mk211               { quality = 5; price = 70; };//патроны для снапы
	class rhsusf_20Rnd_762x51_m993_Mag                   { quality = 5; price = 70; };//патроны для снапы
	class rhsusf_20Rnd_762x51_m62_Mag                    { quality = 5; price = 70; };//патроны для снапы
	class rhsusf_20Rnd_762x51_m118_special_Mag           { quality = 5; price = 70; };//патроны для снапы
	class rhsusf_5Rnd_762x51_m118_special_Mag            { quality = 5; price = 70; };//патроны для снапы
	class rhsusf_5Rnd_762x51_m993_Mag                    { quality = 5; price = 70; };//патроны для снапы
	class rhsusf_5Rnd_762x51_m62_Mag                     { quality = 5; price = 70; };//патроны для снапы
	class rhsusf_50Rnd_762x51                            { quality = 4; price = 80; };//патроны для пулемёта
	class rhsusf_50Rnd_762x51_m61_ap                     { quality = 4; price = 80; };//патроны для пулемёта
	class rhsusf_50Rnd_762x51_m62_tracer                 { quality = 4; price = 80; };//патроны для пулемёта
	class rhsusf_50Rnd_762x51_m80a1epr                   { quality = 4; price = 80; };//патроны для пулемёта
	class rhsusf_50Rnd_762x51_m82_blank                  { quality = 4; price = 80; };//патроны для пулемёта
	class rhsusf_100Rnd_762x51                           { quality = 4; price = 80; };//патроны для пулемёта
	class rhsusf_100Rnd_762x51_m61_ap                    { quality = 4; price = 80; };//патроны для пулемёта
	//class rhsusf_100Rnd_762x51_m62_tracer                { quality = 4; price = 80; };//патроны для пулемёта
	//class rhsusf_100Rnd_762x51_m80a1epr                  { quality = 4; price = 80; };//патроны для пулемёта
	class rhsusf_100Rnd_762x51_m82_blank                 { quality = 4; price = 80; };//патроны для пулемёта
	class rhsusf_50Rnd_762x51_m993                       { quality = 4; price = 80; };//патроны для пулемёта
	class rhsusf_100Rnd_762x51_m993                      { quality = 4; price = 80; };//патроны для пулемёта
	class rhsusf_10Rnd_762x51_m118_special_Mag           { quality = 5; price = 70; };//патроны для снапы
	class rhsusf_10Rnd_762x51_m993_Mag                   { quality = 5; price = 70; };//патроны для снапы
	//class rhsusf_10Rnd_762x51_m62_Mag                    { quality = 5; price = 70; };//патроны для снапы
	class rhsusf_8Rnd_00Buck                             { quality = 1; price = 40; };//патроны для дробовики
	class rhsusf_8Rnd_doomsday_Buck                      { quality = 1; price = 40; };//патроны для дробовики
	class rhsusf_8Rnd_Slug                               { quality = 1; price = 40; };//патроны для дробовики
	class rhsusf_8Rnd_HE                                 { quality = 1; price = 40; };//патроны для дробовики
	class rhsusf_8Rnd_FRAG                               { quality = 1; price = 40; };//патроны для дробовики
	class rhsusf_mag_40Rnd_46x30_FMJ                     { quality = 2; price = 50; };//патроны для Пист.пулемёты
	class rhsusf_mag_40Rnd_46x30_JHP                     { quality = 2; price = 50; };//патроны для Пист.пулемёты
//	class rhsusf_mag_40Rnd_46x30_AP                      { quality = 2; price = 50; };//патроны для Пист.пулемёты
//	class rhsusf_5Rnd_300winmag_xm2010                   { quality = 5; price = 70; };//патроны для снапы
	
	//////////////////////////////////////////////////////////////////
	// Взрывчатка и т.д
	//////////////////////////////////////////////////////////////////
	class rhs_mag_M441_HE                { quality = 1; price = 200; };
	class rhs_mag_M433_HEDP              { quality = 1; price = 200; };
	class rhs_mag_M397_HET               { quality = 1; price = 200; };
	class rhs_mag_m4009                  { quality = 1; price = 200; };
	class rhs_mag_m576                   { quality = 1; price = 200; };
	class rhs_mag_M585_white             { quality = 1; price = 200; };
	class rhs_mag_m661_green             { quality = 1; price = 200; };
	class rhs_mag_m662_red               { quality = 1; price = 200; };
	class rhs_mag_m713_Red               { quality = 1; price = 200; };
	class rhs_mag_m714_White             { quality = 1; price = 200; };
	class rhs_mag_m715_Green             { quality = 1; price = 200; };
	class rhs_mag_m716_yellow            { quality = 1; price = 200; };
	class rhsusf_mag_6Rnd_M441_HE        { quality = 1; price = 200; };
	class rhsusf_mag_6Rnd_M433_HEDP      { quality = 1; price = 200; };
	class rhsusf_mag_6Rnd_M397_HET       { quality = 1; price = 200; };
	class rhsusf_mag_6Rnd_M576_Buckshot  { quality = 1; price = 200; };
	class rhsusf_mag_6Rnd_M781_Practice  { quality = 1; price = 200; };
	class rhsusf_mag_6Rnd_m4009          { quality = 1; price = 200; };
	class rhsusf_mag_6Rnd_M585_white     { quality = 1; price = 200; };
	class rhsusf_mag_6Rnd_m661_green     { quality = 1; price = 200; };
	class rhsusf_mag_6Rnd_m662_red       { quality = 1; price = 200; };
	class rhsusf_mag_6Rnd_M713_red       { quality = 1; price = 200; };
	class rhsusf_mag_6Rnd_M714_white     { quality = 1; price = 200; };
	class rhsusf_mag_6Rnd_M715_green     { quality = 1; price = 200; };
	class rhsusf_mag_6Rnd_M716_yellow    { quality = 1; price = 200; };
	class rhs_mine_pmn2_mag              { quality = 1; price = 200; };
	class rhs_mag_mine_ptm1              { quality = 1; price = 200; };
	class rhs_mag_mine_pfm1              { quality = 1; price = 200; };
	class rhs_mine_tm62m_mag             { quality = 1; price = 200; };
	class rhsusf_m112_mag                { quality = 1; price = 200; };
	class rhsusf_m112x4_mag              { quality = 1; price = 200; };
	class rhsusf_mine_m14_mag            { quality = 1; price = 200; };
	class rhs_mine_M19_mag               { quality = 1; price = 200; };
	
	////////////////////////////////////////////////////////////////////
	// Гранаты и т.д
	////////////////////////////////////////////////////////////////////
	class rhs_mag_m7a3_cs                 { quality = 1; price = 100; };
	class rhs_mag_an_m14_th3              { quality = 1; price = 100; };
	class rhs_mag_zarya2                  { quality = 1; price = 100; };
	class rhs_mag_m18_green               { quality = 1; price = 100; };
	class rhs_mag_m18_yellow              { quality = 1; price = 100; };
	class rhs_mag_m18_red                 { quality = 1; price = 100; };
	class rhs_mag_m18_purple              { quality = 1; price = 100; };
	class rhs_mag_nspd                    { quality = 1; price = 100; };
	class rhs_mag_nspn_yellow             { quality = 1; price = 100; };
	class rhs_mag_nspn_green              { quality = 1; price = 100; };
	class rhs_mag_nspn_red                { quality = 1; price = 100; };
	class rhs_mag_m67                     { quality = 1; price = 100; };
	class rhs_mag_plamyam                 { quality = 1; price = 100; };
	class rhs_mag_rgd5                    { quality = 1; price = 100; };
	class rhs_mag_rgn                     { quality = 1; price = 100; };
	class rhs_mag_rgo                     { quality = 1; price = 100; };
	class rhs_mag_rdg2_white              { quality = 1; price = 100; };
	class rhs_mag_rdg2_black              { quality = 1; price = 100; };
	class rhs_mag_mk3a2                   { quality = 1; price = 100; };
	class rhs_mag_mk84                    { quality = 1; price = 100; };
	class rhs_mag_m69                     { quality = 1; price = 100; };
	class rhs_mag_fakel                   { quality = 1; price = 100; };
	class rhs_mag_fakels                  { quality = 1; price = 100; };
	class rhs_mag_an_m8hc                 { quality = 1; price = 100; };
	
	/////////////////////////////////////////////////////////////////////
	// Гранатометы
	/////////////////////////////////////////////////////////////////////
	class rhs_weap_igla                   { quality = 5; price = 7000; };//пво
	class rhs_weap_rpg7                   { quality = 5; price = 6000; }; 
	class rhs_weap_fgm148                 { quality = 10; price = 7000; };
	class rhs_weap_fim92                  { quality = 10; price = 7000; };//пво
	class rhs_weap_maaws                  { quality = 10; price = 7000; };
	class rhs_weap_smaw                   { quality = 10; price = 7000; };
	class rhs_weap_smaw_green             { quality = 10; price = 7000; };
	
	///////////////////////////////////////////////////////////////
	// Снаряды для гранатометов
	///////////////////////////////////////////////////////////////
	class rhs_mag_9k38_rocket             { quality = 6; price = 800; };//пво
	class rhs_rpg7_PG7V_mag               { quality = 4; price = 700; };
	class rhs_rpg7_PG7VL_mag              { quality = 4; price = 700; };
	class rhs_rpg7_PG7VR_mag              { quality = 4; price = 700; };
	class rhs_rpg7_OG7V_mag               { quality = 4; price = 700; };
	class rhs_rpg7_TBG7V_mag              { quality = 4; price = 700; };
	class rhs_rpg7_type69_airburst_mag    { quality = 4; price = 700; };
	class rhs_fgm148_magazine_AT          { quality = 6; price = 800; };
	class rhs_fim92_mag                   { quality = 6; price = 800; };//пво
	class rhs_mag_maaws_HEAT              { quality = 6; price = 800; };
	class rhs_mag_maaws_HEDP              { quality = 6; price = 800; };
	class rhs_mag_maaws_HE                { quality = 6; price = 800; };
	class rhs_mag_smaw_HEAA               { quality = 6; price = 800; };
	class rhs_mag_smaw_HEDP               { quality = 6; price = 800; };
	class rhs_mag_smaw_SR                 { quality = 6; price = 800; };
	
	/////////////////////////////////////////////////////////////////////
	// Спецтовары
	/////////////////////////////////////////////////////////////////////
	class rhs_weap_m32                    { quality = 1; price = 10000; };