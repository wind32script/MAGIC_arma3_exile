    class RFCars
	{
		name = "Russian Автомобили";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"min_rf_gaz_2330",
			"min_rf_gaz_2330_desert",
			"min_rf_gaz_2330_winter"
		};
	};
	
	class RFTrucks
	{
		name = "Russian Грузовики";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"min_rf_truck_medical",
			"min_rf_truck_medical_desert",
			"min_rf_truck_medical_winter",
			"min_rf_truck_box",
			"min_rf_truck_box_desert",
			"min_rf_truck_box_winter",
			"min_rf_truck_ammo_desert",
			"min_rf_truck_ammo_winter",
			"min_rf_truck_ammo",
			"min_rf_truck_fuel",
			"min_rf_truck_fuel_desert",
			"min_rf_truck_fuel_winter",
			"min_rf_truck_transport",
			"min_rf_truck_transport_desert",
			"min_rf_truck_transport_winter",
			"min_rf_truck_covered",
			"min_rf_truck_covered_desert",
			"min_rf_truck_covered_winter"
		};
	};
	
	class RFArmedCars
	{
		name = "Russian Вооруженный Транспорт";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"min_rf_gaz_2330_HMG",
			"min_rf_gaz_2330_HMG_desert",
			"min_rf_gaz_2330_HMG_winter",
			"min_rf_sa_22",
			"min_rf_sa_22_desert",
			"min_rf_sa_22_winter"
		};
	};
	
	class RFTanks
	{
		name = "Russian Гусеничная техника";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"min_rf_t_15",
			"min_rf_t_15_desert",
			"min_rf_t_15_winter",
			"min_rf_t_14",
			"min_rf_t_14_desert",
			"min_rf_t_14_winter"
		};
	};
	
	class RFChoppers
	{
		name = "Russian Вертолёты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[]=
		{			
			"min_rf_heli_light_unarmed_grey"
		};
	};
	
	class RFArmedChoppers
	{
		name = "Russian Вооруженные Вертолёты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[]=
		{
			"min_rf_heli_light_grey",
			"min_rf_ka_52",
			"min_rf_ka_52_grey"
		};
	};
	
	class RFPlanes
	{
		name = "Russian Вооруженные Самолёты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[]=
		{			
			"min_rf_su_34", 
			"min_rf_su_34_desert"
		};
	};