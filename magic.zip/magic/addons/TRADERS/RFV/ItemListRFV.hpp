	/////////////////////////////////////////////////////////////////////////////////
	// Автомобили
	/////////////////////////////////////////////////////////////////////////////////
	class min_rf_gaz_2330                           { quality = 2; price = 25000; };
	class min_rf_gaz_2330_desert                    { quality = 2; price = 25000; };
	class min_rf_gaz_2330_winter                    { quality = 2; price = 25000; };
	
    /////////////////////////////////////////////////////////////////////////////////
	// Грузовики
	/////////////////////////////////////////////////////////////////////////////////
	class min_rf_truck_medical                      { quality = 1; price = 50000; };
	class min_rf_truck_medical_desert               { quality = 1; price = 50000; };
	class min_rf_truck_medical_winter               { quality = 1; price = 50000; };
	class min_rf_truck_box                          { quality = 1; price = 50000; };
	class min_rf_truck_box_desert                   { quality = 1; price = 50000; };
	class min_rf_truck_box_winter                   { quality = 1; price = 50000; };
	class min_rf_truck_ammo_desert                  { quality = 1; price = 50000; };
	class min_rf_truck_ammo_winter                  { quality = 1; price = 50000; };
	class min_rf_truck_ammo                         { quality = 1; price = 50000; };
	class min_rf_truck_fuel                         { quality = 1; price = 50000; };
	class min_rf_truck_fuel_desert                  { quality = 1; price = 50000; };
	class min_rf_truck_fuel_winter                  { quality = 1; price = 50000; };
	class min_rf_truck_transport                    { quality = 1; price = 50000; };
	class min_rf_truck_transport_desert             { quality = 1; price = 50000; };
	class min_rf_truck_transport_winter             { quality = 1; price = 50000; };
	class min_rf_truck_covered                      { quality = 1; price = 50000; };
	class min_rf_truck_covered_desert               { quality = 1; price = 50000; };
	class min_rf_truck_covered_winter               { quality = 1; price = 50000; };

	/////////////////////////////////////////////////////////////////////////////////
	// Вооруженный Транспорт
	/////////////////////////////////////////////////////////////////////////////////
	class min_rf_gaz_2330_HMG                       { quality = 4; price = 80000; };
	class min_rf_gaz_2330_HMG_desert                { quality = 4; price = 80000; };
	class min_rf_gaz_2330_HMG_winter                { quality = 4; price = 80000; };
	class min_rf_sa_22                              { quality = 8; price = 200000; };
	class min_rf_sa_22_desert                       { quality = 8; price = 200000; };
	class min_rf_sa_22_winter                       { quality = 8; price = 200000; };

	/////////////////////////////////////////////////////////////////////////////////
	// Гусеничная техника
	/////////////////////////////////////////////////////////////////////////////////
	class min_rf_t_15                              { quality = 8; price = 250000; };
	class min_rf_t_15_desert                       { quality = 8; price = 250000; };
	class min_rf_t_15_winter                       { quality = 8; price = 250000; };
	class min_rf_t_14                              { quality = 10; price = 350000; };
	class min_rf_t_14_desert                       { quality = 10; price = 350000; };
	class min_rf_t_14_winter                       { quality = 10; price = 350000; };
	
	/////////////////////////////////////////////////////////////////////////////////
	// Вертолёты
	/////////////////////////////////////////////////////////////////////////////////
	class min_rf_heli_light_unarmed_grey          { quality = 2; price = 60000; };
	
	/////////////////////////////////////////////////////////////////////////////////
	// Вооруженные Вертолёты
	/////////////////////////////////////////////////////////////////////////////////
	class min_rf_heli_light_grey                  { quality = 5; price = 80000; };
	class min_rf_ka_52                            { quality = 9; price = 350000; };
	class min_rf_ka_52_grey                       { quality = 9; price = 350000; };
	
	/////////////////////////////////////////////////////////////////////////////////
	// Вооруженные Самолёты
	/////////////////////////////////////////////////////////////////////////////////
	class min_rf_su_34                            { quality = 10; price = 300000; };
	class min_rf_su_34_desert                     { quality = 10; price = 300000; };