	class Uniforms
	{
		name = "Униформа";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\uniform_ca.paa";
		items[] = 
		{
			//Гражданская Одежда
/*			"U_C_Journalist",
			"U_C_Poloshirt_blue",
			"U_C_Poloshirt_burgundy",
			"U_C_Poloshirt_salmon",
			"U_C_Poloshirt_stripped",
			"U_C_Poloshirt_tricolour",
			"U_C_Poor_1",
			"U_C_Poor_2",
			"U_C_Poor_shorts_1",
			"U_C_Scientist",
			"U_OrestesBody",
			"U_Rangemaster",
			"U_NikosAgedBody",
			"U_NikosBody",
			"U_Competitor",*/
			//Солдатская Форма
			"U_B_CombatUniform_mcam",
			"U_B_CombatUniform_mcam_tshirt",
			"U_B_CombatUniform_mcam_vest",
			"U_B_CombatUniform_mcam_worn",
			"U_B_CTRG_1",
			"U_B_CTRG_2",
			"U_B_CTRG_3",
			"U_I_CombatUniform",
			"U_I_CombatUniform_shortsleeve",
			"U_I_CombatUniform_tshirt",
			"U_I_OfficerUniform",
			"U_O_CombatUniform_ocamo",
			"U_O_CombatUniform_oucamo",
			"U_O_OfficerUniform_ocamo",
			"U_B_SpecopsUniform_sgg",
			"U_O_SpecopsUniform_blk",
			"U_O_SpecopsUniform_ocamo",
			"U_I_G_Story_Protagonist_F",
			"Exile_Uniform_Woodland",
			//Партизанская Форма
			"U_C_HunterBody_grn",
			"U_IG_Guerilla1_1",
			"U_IG_Guerilla2_1",
			"U_IG_Guerilla2_2",
			"U_IG_Guerilla2_3",
			"U_IG_Guerilla3_1",
			"U_BG_Guerilla2_1",
			"U_IG_Guerilla3_2",
			"U_BG_Guerrilla_6_1",
			"U_BG_Guerilla1_1",
			"U_BG_Guerilla2_2",
			"U_BG_Guerilla2_3",
			"U_BG_Guerilla3_1",
			"U_BG_leader",
			"U_IG_leader",
			"U_I_G_resistanceLeader_F",
			//Маскировочные Костюмы
			"U_B_FullGhillie_ard",
			"U_B_FullGhillie_lsh",
			"U_B_FullGhillie_sard",
			"U_B_GhillieSuit",
			"U_I_FullGhillie_ard",
			"U_I_FullGhillie_lsh",
			"U_I_FullGhillie_sard",
			"U_I_GhillieSuit",
			"U_O_FullGhillie_ard",
			"U_O_FullGhillie_lsh",
			"U_O_FullGhillie_sard",
			"U_O_GhillieSuit",
			"U_B_survival_uniform",
			"U_B_HeliPilotCoveralls",
			"U_I_HeliPilotCoveralls",
			"U_B_PilotCoveralls",
			"U_I_pilotCoveralls",
			"U_O_PilotCoveralls",
			//DLC Orange
			"U_C_ConstructionCoverall_Vrana_F",
			"U_C_ConstructionCoverall_Red_F",
			"U_C_ConstructionCoverall_Blue_F",
			"U_C_ConstructionCoverall_Black_F",
			"U_C_Mechanic_01_F",
			"U_C_Paramedic_01_F",
			"U_BG_Guerilla1_2_F",
			"U_C_IDAP_Man_cargo_F",
			"U_C_IDAP_Man_Jeans_F",
			"U_C_IDAP_Man_casual_F",
			"U_C_IDAP_Man_shorts_F",
			"U_C_IDAP_Man_TeeShorts_F",
			"U_C_IDAP_Man_Tee_F",
			//DLC Contact
			"U_I_E_Uniform_01_coveralls_F",
			"U_O_R_Gorka_01_F",
			"U_O_R_Gorka_01_brown_F",
			"U_O_R_Gorka_01_camo_F",
			"U_I_L_Uniform_01_camo_F",
			"U_I_L_Uniform_01_deserter_F",
			"U_B_CombatUniform_mcam_wdl_f",
			"U_B_CombatUniform_tshirt_mcam_wdL_f",
			"U_I_E_Uniform_01_tanktop_F",
			"U_I_E_Uniform_01_officer_F",
			"U_I_E_Uniform_01_shortsleeve_F",
			"U_I_E_Uniform_01_sweater_F",
			"U_I_E_Uniform_01_F",
			"U_O_R_Gorka_01_black_F",
			"U_B_CombatUniform_vest_mcam_wdl_f",
			"U_B_CBRN_Suit_01_MTP_F",
			"U_C_CBRN_Suit_01_White_F",
			"U_B_CBRN_Suit_01_Wdl_F",
			"U_C_CBRN_Suit_01_Blue_F",
			"U_B_CBRN_Suit_01_Tropic_F",
			"U_I_CBRN_Suit_01_AAF_F",
			"U_I_E_CBRN_Suit_01_EAF_F",
			"U_B_Protagonist_VR",
			"U_I_Protagonist_VR",
			"U_O_Protagonist_VR"
		};
	};

	class Vests
	{
		name = "Бронежилеты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\vest_ca.paa";
		items[] = 
		{
			"V_Press_F",
			"V_Rangemaster_belt",
			"V_TacVest_blk",
			"V_TacVest_blk_POLICE",
			"V_TacVest_brn",
			"V_TacVest_camo",
			"V_TacVest_khk",
			"V_TacVest_oli",
			"V_TacVestCamo_khk",
			"V_TacVestIR_blk",
			"V_I_G_resistanceLeader_F",
			"V_BandollierB_blk",
			"V_BandollierB_cbr",
			"V_BandollierB_khk",
			"V_BandollierB_oli",
			"V_BandollierB_rgr",
			"V_Chestrig_blk",
			"V_Chestrig_khk",
			"V_Chestrig_oli",
			"V_Chestrig_rgr",
			"V_HarnessO_brn",
			"V_HarnessO_gry",
			"V_HarnessOGL_brn",
			"V_HarnessOGL_gry",
			"V_HarnessOSpec_brn",
			"V_HarnessOSpec_gry",
			"V_PlateCarrier1_blk",
			"V_PlateCarrier1_rgr",
			"V_PlateCarrier2_rgr",
			"V_PlateCarrier3_rgr",
			"V_PlateCarrierGL_blk",
			"V_PlateCarrierGL_mtp",
			"V_PlateCarrierGL_rgr",
			"V_PlateCarrierH_CTRG",
			"V_PlateCarrierIA1_dgtl",
			"V_PlateCarrierIA2_dgtl",
			"V_PlateCarrierIAGL_dgtl",
			"V_PlateCarrierIAGL_oli",
			"V_PlateCarrierL_CTRG",
			"V_PlateCarrierSpec_blk",
			"V_PlateCarrierSpec_mtp",
			"V_PlateCarrierSpec_rgr",
			//DLC Orange
			"V_EOD_coyote_F",
			"V_EOD_olive_F",
			"V_EOD_blue_F",
			"V_EOD_IDAP_blue_F",
			"V_Pocketed_coyote_F",
			"V_Pocketed_olive_F",
			"V_Pocketed_black_F",
			"V_Plain_crystal_F",
			"V_Safety_yellow_F",
			"V_Safety_orange_F",
			"V_Safety_blue_F",
			"V_Plain_medical_F",
			"V_LegStrapBag_olive_F",
			"V_LegStrapBag_coyote_F",
			"V_LegStrapBag_black_F",
			//DLC Jets
			"V_DeckCrew_white_F",
			"V_DeckCrew_yellow_F",
			"V_DeckCrew_green_F",
			"V_DeckCrew_brown_F",
			"V_DeckCrew_red_F",
			"V_DeckCrew_blue_F",
			"V_DeckCrew_violet_F",
			//DLC Contact
			"V_PlateCarrierGL_wdl",
			"V_SmershVest_01_F",
			"V_SmershVest_01_radio_F",
			"V_CarrierRigKBT_01_heavy_EAF_F",
			"V_CarrierRigKBT_01_heavy_Olive_F",
			"V_CarrierRigKBT_01_light_EAF_F",
			"V_CarrierRigKBT_01_light_Olive_F",
			"V_CarrierRigKBT_01_EAF_F",
			"V_CarrierRigKBT_01_Olive_F",
			"V_PlateCarrier1_wdl",
			"V_PlateCarrier2_wdl",
			"V_PlateCarrierSpec_wdl"
		};
	};

	class Headgear 
	{
		name = "Головные уборы|Шлемы";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\headgear_ca.paa";
		items[] =
		{
			"Exile_Headgear_SantaHat",
			"Exile_Headgear_SafetyHelmet",
			"H_Cap_blk",
			"H_Cap_blk_Raven",
			"H_Cap_blu",
			"H_Cap_brn_SPECOPS",
			"H_Cap_grn",
			"H_Cap_headphones",
			"H_Cap_khaki_specops_UK",
			"H_Cap_oli",
			"H_Cap_press",
			"H_Cap_red",
			"H_Cap_tan",
			"H_Cap_tan_specops_US",
			"H_Watchcap_blk",
			"H_Watchcap_camo",
			"H_Watchcap_khk",
			"H_Watchcap_sgg",
			"H_MilCap_blue",
			"H_MilCap_dgtl",
			"H_MilCap_mcamo",
			"H_MilCap_ocamo",
			"H_MilCap_oucamo",
			"H_MilCap_rucamo",
			"H_Bandanna_camo",
			"H_Bandanna_cbr",
			"H_Bandanna_gry",
			"H_Bandanna_khk",
			"H_Bandanna_khk_hs",
			"H_Bandanna_mcamo",
			"H_Bandanna_sgg",
			"H_Bandanna_surfer",
			"H_Booniehat_dgtl",
			"H_Booniehat_dirty",
			"H_Booniehat_grn",
			"H_Booniehat_indp",
			"H_Booniehat_khk",
			"H_Booniehat_khk_hs",
			"H_Booniehat_mcamo",
			"H_Booniehat_tan",
			"H_Hat_blue",
			"H_Hat_brown",
			"H_Hat_camo",
			"H_Hat_checker",
			"H_Hat_grey",
			"H_Hat_tan",
			"H_StrawHat",
			"H_StrawHat_dark",
			"H_Beret_02",
			"H_Beret_blk",
			"H_Beret_blk_POLICE",
			"H_Beret_brn_SF",
			"H_Beret_Colonel",
			"H_Beret_grn",
			"H_Beret_grn_SF",
			"H_Beret_ocamo",
			"H_Beret_red",
			"H_Shemag_khk",
			"H_Shemag_olive",
			"H_Shemag_olive_hs",
			"H_Shemag_tan",
			"H_ShemagOpen_khk",
			"H_ShemagOpen_tan",
			"H_TurbanO_blk",
			"H_HelmetB",
			"H_HelmetB_black",
			"H_HelmetB_camo",
			"H_HelmetB_desert",
			"H_HelmetB_grass",
			"H_HelmetB_light",
			"H_HelmetB_light_black",
			"H_HelmetB_light_desert",
			"H_HelmetB_light_grass",
			"H_HelmetB_light_sand",
			"H_HelmetB_light_snakeskin",
			"H_HelmetB_paint",
			"H_HelmetB_plain_blk",
			"H_HelmetB_sand",
			"H_HelmetB_snakeskin",
			"H_HelmetCrew_B",
			"H_HelmetCrew_I",
			"H_HelmetCrew_O",
			"H_HelmetIA",
			"H_HelmetIA_camo",
			"H_HelmetIA_net",
			"H_HelmetLeaderO_ocamo",
			"H_HelmetLeaderO_oucamo",
			"H_HelmetO_ocamo",
			"H_HelmetO_oucamo",
			"H_HelmetSpecB",
			"H_HelmetSpecB_blk",
			"H_HelmetSpecB_paint1",
			"H_HelmetSpecB_paint2",
			"H_HelmetSpecO_blk",
			"H_HelmetSpecO_ocamo",
			"H_CrewHelmetHeli_B",
			"H_CrewHelmetHeli_I",
			"H_CrewHelmetHeli_O",
			"H_HelmetCrew_I",
			"H_HelmetCrew_B",
			"H_HelmetCrew_O",
			"H_PilotHelmetHeli_B",
			"H_PilotHelmetHeli_I",
			"H_PilotHelmetHeli_O",
			"H_PilotHelmetFighter_I",
			//New DLC Orange
			"H_WirelessEarpiece_F",
			"H_HeadSet_white_F",
			"H_HeadSet_yellow_F",
			"H_HeadSet_red_F",
			"H_HeadSet_orange_F",
			"H_HeadSet_black_F",
			"H_EarProtectors_white_F",
			"H_EarProtectors_yellow_F",
			"H_EarProtectors_red_F",
			"H_EarProtectors_orange_F",
			"H_EarProtectors_black_F",
			"H_Construction_basic_vrana_F",
			"H_Construction_headset_vrana_F",
			"H_Construction_earprot_vrana_F",
			"H_Construction_basic_white_F",
			"H_Construction_headset_white_F",
			"H_Construction_earprot_white_F",
			"H_Construction_basic_yellow_F",
			"H_Construction_headset_yellow_F",
			"H_Construction_earprot_yellow_F",
			"H_Construction_basic_red_F",
			"H_Construction_headset_red_F",
			"H_Construction_earprot_red_F",
			"H_Construction_basic_orange_F",
			"H_Construction_headset_orange_F",
			"H_Construction_earprot_orange_F",
			"H_Construction_basic_black_F",
			"H_Construction_headset_black_F",
			"H_Construction_earprot_black_F",
			"H_Cap_White_IDAP_F",
			"H_Cap_Orange_IDAP_F",
			"H_Cap_Black_IDAP_F",
			"H_PASGT_basic_white_F",
			"H_PASGT_basic_olive_F",
			"H_PASGT_basic_blue_F",
			"H_HeadBandage_stained_F",
			"H_HeadBandage_bloody_F",
			"H_HeadBandage_clean_F",
			"H_PASGT_basic_blue_press_F",
			"H_PASGT_neckprot_blue_press_F",
			"H_Hat_Safari_olive_F",
			"H_Hat_Safari_sand_F",
			//DLC Tank
			"H_Tank_black_F",
			//DLC Contact
			"H_MilCap_grn",
			"H_MilCap_wdl",
			"H_MilCap_taiga",
			"H_MilCap_eaf",
			"H_Beret_EAF_01_F",
			"H_HelmetB_light_wdl",
			"H_PilotHelmetFighter_I_E",
			"H_Tank_eaf_F",
			"H_HelmetCrew_I_E",
			"H_HelmetSpecB_wdl",
			"H_HelmetHBK_headset_F",
			"H_HelmetHBK_chops_F",
			"H_HelmetHBK_ear_F",
			"H_HelmetHBK_F",
			"H_HelmetAggressor_F",
			"H_HelmetAggressor_cover_F",
			"H_HelmetAggressor_cover_taiga_F",
			"H_PilotHelmetHeli_I_E",
			"H_CrewHelmetHeli_I_E",
			"H_HelmetB_plain_wdl",
			"H_Hat_Tinfoil_F"
		};
	};

    class Glasses 
	{
		name = "Защита лица";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\Goggles_ca.paa";
		items[] =
		{
			"G_Spectacles",
			"G_Spectacles_Tinted",
			"G_Combat",
			"G_Lowprofile",
			"G_Shades_Black",
			"G_Shades_Green",
			"G_Shades_Red",
			"G_Squares",
			"G_Squares_Tinted",
			"G_Sport_BlackWhite",
			"G_Sport_Blackyellow",
			"G_Sport_Greenblack",
			"G_Sport_Checkered",
			"G_Sport_Red",
			"G_Tactical_Black",
			"G_Aviator",
			"G_Lady_Mirror",
			"G_Lady_Dark",
			"G_Lady_Red",
			"G_Lady_Blue",
			"G_Goggles_VR",
			"G_Balaclava_blk",
			"G_Balaclava_oli",
			"G_Balaclava_combat",
			"G_Balaclava_lowprofile",
			"G_Bandanna_blk",
			"G_Bandanna_oli",
			"G_Bandanna_khk",
			"G_Bandanna_tan",
			"G_Bandanna_beast",
			"G_Bandanna_shades",
			"G_Bandanna_sport",
			"G_Bandanna_aviator",
			"G_Shades_Blue",
			"G_Sport_Blackred",
			"G_Tactical_Clear",
			"G_Balaclava_TI_blk_F",
			"G_Balaclava_TI_tna_F",
			"G_Balaclava_TI_G_blk_F",
			"G_Balaclava_TI_G_tna_F",
			"G_Combat_Goggles_tna_F",
			//New DLC Orange
			"G_WirelessEarpiece_F",
			"G_EyeProtectors_F",
			"G_EyeProtectors_Earpiece_F",
			"G_Respirator_white_F",
			"G_Respirator_yellow_F",
			"G_Respirator_blue_F"
		};
	};

	class PointerAttachments 
	{
		name = "Вспомогательное";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"acc_flashlight",
			"acc_pointer_IR"
		};
	};

	class BipodAttachments 
	{
		name = "Сошки";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itembipod_ca.paa";
		items[] = 
		{
			"bipod_01_F_blk",
			"bipod_01_F_mtp",
			"bipod_01_F_snd",
			"bipod_02_F_blk",
			"bipod_02_F_hex",
			"bipod_02_F_tan",
			"bipod_03_F_blk",
			"bipod_03_F_oli",
			//DLC Contact
			"bipod_02_F_lush",
			"bipod_02_F_arid"
		};
	};

	class MuzzleAttachments 
	{
		name = "Глушители";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemmuzzle_ca.paa";
		items[] = 
		{
			"muzzle_snds_338_black",
			"muzzle_snds_338_green",
			"muzzle_snds_338_sand",
			"muzzle_snds_93mmg",
			"muzzle_snds_93mmg_tan",
			"muzzle_snds_acp",
			"muzzle_snds_B",
			"muzzle_snds_H",
			"muzzle_snds_H_MG",
			"muzzle_snds_H_SW",
			"muzzle_snds_L",
			"muzzle_snds_M",
			//DLC Contactc
			"muzzle_snds_B_lush_F",
			"muzzle_snds_B_arid_F"
		};
	};

	class UAVs
	{
		name = "Безпилотники";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\gps_ca.paa";
		items[] = 
		{
			"I_UavTerminal",
			"I_UAV_01_backpack_F",
			//DLC Contact
			"I_E_UAV_06_backpack_F",
			"I_E_UAV_06_medical_backpack_F",
			"I_E_UAV_01_backpack_F"
		};
	};

	class StaticMGs
	{
		name = "Стационарные пулеметы";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"O_HMG_01_support_F",
			"O_HMG_01_weapon_F",
			"B_HMG_01_weapon_F",
			"B_HMG_01_support_F",
			"B_GMG_01_high_weapon_F",
			"B_HMG_01_support_high_F",
			"RHS_M2_Tripod_Bag",
			"RHS_M2_Gun_Bag",
			"RHS_M2_MiniTripod_Bag",
			"RHS_NSV_Gun_Bag",
			"RHS_NSV_Tripod_Bag",
			"RHS_Kord_Gun_Bag",
			"RHS_Kord_Tripod_Bag",
			"RHS_AGS30_Gun_Bag",
			"RHS_AGS30_Tripod_Bag",
			"RHS_Mk19_Gun_Bag",
			"RHS_Mk19_Tripod_Bag",
			"CUP_B_DShkM_Gun_Bag",
			"CUP_B_DShkM_TripodLow_Bag",
			"CUP_B_M2_Gun_Bag",
			"CUP_B_M2_MiniTripod_Bag",
			"CUP_B_DShkM_TripodHigh_Bag"
		};
	};
	
	class StaticMortars
	{
		name = "Стационарные миномёты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"I_Mortar_01_support_F",
			"I_Mortar_01_weapon_F"
			//"RHS_Podnos_Bipod_Bag",
			//"RHS_Podnos_Gun_Bag",
			//"rhs_M252_Gun_Bag",
			//"rhs_M252_Bipod_Bag"
		};
	};
	
	class StaticPVO
	{
		name = "Стационарные пво/пт";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"B_AA_01_weapon_F",
			"B_AT_01_weapon_F",
			"RHS_SPG9_Gun_Bag",
			"RHS_SPG9_Tripod_Bag"
		};
	};

	class OpticAttachments 
	{
		name = "Оптика";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemoptic_ca.paa";
		items[] = 
		{
			"optic_Aco",
			"optic_ACO_grn",
			"optic_ACO_grn_smg",
			"optic_Aco_smg",
			"optic_AMS",
			"optic_AMS_khk",
			"optic_AMS_snd",
			"optic_Arco",
			"optic_DMS",
			"optic_Hamr",
			"optic_Holosight",
			"optic_Holosight_smg",
			"optic_KHS_blk",
			"optic_KHS_hex",
			"optic_KHS_old",
			"optic_KHS_tan",
			"optic_LRPS",
			"optic_MRCO",
			"optic_MRD",
			"optic_Nightstalker",
			"optic_NVS",
			"optic_SOS",
			"optic_tws",
			"optic_tws_mg",
			"optic_Yorris",
			//DLC Contact
			"optic_MRD_black",
			"optic_Arco_lush_F",
			"optic_Arco_arid_F",
			"optic_Arco_AK_lush_F",
			"optic_Arco_AK_arid_F",
			"optic_Arco_AK_blk_F",
			"optic_DMS_weathered_F",
			"optic_DMS_weathered_Kir_F",
			"optic_Holosight_lush_F",
			"optic_Holosight_arid_F",
			"optic_ico_01_f",
			"optic_ico_01_camo_f",
			"optic_ico_01_sand_f",
			"optic_ico_01_black_f"
		};
	};

	class Hardware 
	{
		name = "Строительное";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"Exile_Item_Rope",
			"Exile_Item_DuctTape",
			"Exile_Item_ExtensionCord",
			"Exile_Item_FuelCanisterEmpty",
			"Exile_Item_JunkMetal",
			"Exile_Item_LightBulb",
			"Exile_Item_MetalBoard",
			"Exile_Item_MetalHedgehogKit",
			"Exile_Item_MetalPole",
			"Exile_Item_WaterCanisterDirtyWater",
			"Exile_Item_WaterCanisterEmpty",
			"Exile_Item_SafeKit",
			"Exile_Item_SafeSmallKit",
			"Exile_Item_CamoTentKit",
			"Exile_Item_CodeLock",
			"Exile_Item_Laptop",
			"Exile_Item_MetalWire",
			"Exile_Item_MetalScrews",
			"Exile_Item_Carwheel",
			"Exile_Item_BaseCameraKit",
			"Exile_Item_Cement",
			"Exile_Item_Sand"
		};
	};

	class Food 
	{
		name = "Еда";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"Exile_Item_EMRE",		
			"Exile_Item_GloriousKnakworst",
			"Exile_Item_Surstromming",
			"Exile_Item_SausageGravy",
			"Exile_Item_Catfood",
			"Exile_Item_ChristmasTinner",
			"Exile_Item_BBQSandwich",
			"Exile_Item_MacasCheese",
			"Exile_Item_Dogfood",
			"Exile_Item_BeefParts",
			"Exile_Item_Cheathas",
			"Exile_Item_Noodles",
			"Exile_Item_SeedAstics",
			"Exile_Item_Raisins",
			"Exile_Item_Moobar",
			"Exile_Item_InstantCoffee",
			"Exile_Item_Can_Empty",
			"Exile_Item_SheepSteak_Cooked",
			"Exile_Item_AlsatianSteak_Cooked",
			"Exile_Item_CatSharkFilet_Cooked",
			"Exile_Item_FinSteak_Cooked",
			"Exile_Item_GoatSteak_Cooked",
			"Exile_Item_TurtleFilet_Cooked",
			"Exile_Item_TunaFilet_Cooked",
			"Exile_Item_RabbitSteak_Cooked",
			"Exile_Item_ChickenFilet_Cooked",
			"Exile_Item_RoosterFilet_Cooked",
			"Exile_Item_MulletFilet_Cooked",
			"Exile_Item_SalemaFilet_Cooked",
			"Exile_Item_MackerelFilet_Cooked",
			"Exile_Item_OrnateFilet_Cooked",
			"Exile_Item_SnakeFilet_Cooked",
			"Exile_Item_CatSharkFilet_Raw",
			"Exile_Item_TunaFilet_Raw",
			"Exile_Item_AlsatianSteak_Raw",
			"Exile_Item_TurtleFilet_Raw",
			"Exile_Item_SheepSteak_Raw",
			"Exile_Item_FinSteak_Raw",
			"Exile_Item_GoatSteak_Raw",
			"Exile_Item_ChickenFilet_Raw",
			"Exile_Item_RoosterFilet_Raw",
			"Exile_Item_MackerelFilet_Raw",
			"Exile_Item_MulletFilet_Raw",
			"Exile_Item_OrnateFilet_Raw",
			"Exile_Item_RabbitSteak_Raw",
			"Exile_Item_SalemaFilet_Raw",
			"Exile_Item_SnakeFilet_Raw"
		};
	};
	
	class NonVeganFood
	{
		name = "Не вегетарианская пища";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"Exile_Item_CatSharkFilet_Raw",
			"Exile_Item_TunaFilet_Raw",
			"Exile_Item_AlsatianSteak_Raw",
			"Exile_Item_TurtleFilet_Raw",
			"Exile_Item_SheepSteak_Raw",
			"Exile_Item_FinSteak_Raw",
			"Exile_Item_GoatSteak_Raw",
			"Exile_Item_ChickenFilet_Raw",
			"Exile_Item_RoosterFilet_Raw",
			"Exile_Item_MackerelFilet_Raw",
			"Exile_Item_MulletFilet_Raw",
			"Exile_Item_OrnateFilet_Raw",
			"Exile_Item_RabbitSteak_Raw",
			"Exile_Item_SalemaFilet_Raw",
			"Exile_Item_SnakeFilet_Raw"
		};
	};

	class Drinks 
	{
		name = "Напитки";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"Exile_Item_PlasticBottleCoffee",
			"Exile_Item_PowerDrink",
			"Exile_Item_PlasticBottleFreshWater",
			"Exile_Item_Beer",
			"Exile_Item_EnergyDrink",
			"Exile_Item_ChocolateMilk",
			"Exile_Item_MountainDupe",
			"Exile_Item_PlasticBottleEmpty"
		};
	};

	class Tools
	{
		name = "Инструменты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"Exile_Item_Matches",
			"Exile_Item_CookingPot",
			"Exile_Item_CanOpener",
			"Exile_Melee_Axe",
			"Exile_Melee_SledgeHammer",
			"Exile_Item_Handsaw",
			"Exile_Item_Pliers",
			"Exile_Item_Grinder",
			"Exile_Item_Foolbox",
			"Exile_Item_CordlessScrewdriver",
			"Exile_Item_FireExtinguisher",
			"Exile_Item_Hammer",
			"Exile_Item_OilCanister",
			"Exile_Item_Screwdriver",
			"Exile_Item_Shovel",
			"Exile_Item_Wrench",
			"Exile_Item_SleepingMat",	
			"Exile_Item_ToiletPaper",			
			"Exile_Item_ZipTie",
			"Exile_Item_Knife",
			"Exile_Item_PortableGeneratorKit",
			"Exile_Magazine_Battery",
			//"Exile_Item_MobilePhone",
			
			"Binocular",
			"Laserbatteries",
			"rhs_LaserMag",
			"rhs_LaserFCSMag",
			"Rangefinder",
			"Laserdesignator",
			//"Laserdesignator_02",
			"Laserdesignator_03",
			"NVGoggles",
			"NVGoggles_INDEP",
			"NVGoggles_OPFOR",
			"ItemGPS",
			"ItemMap",
			"ItemCompass",
			"ItemRadio",
			"ItemWatch",
			"Exile_Item_XM8"
		};
	};

	class FirstAid
	{
		name = "Медикаменты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"Exile_Item_InstaDoc",
			"Exile_Item_Bandage",
			"Exile_Item_Vishpirin",
			"Exile_Item_Heatpack",
			"Exile_Item_Defibrillator"
		};
	};

	class Navigation
	{
		name = "Спецтовары";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"B_Parachute",
			"Exile_Headgear_GasMask"		
		};
	};

	class Backpacks
	{
		name = "Рюкзаки";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\backpack_ca.paa";
		items[] = 
		{
			"B_AssaultPack_blk",
			"B_AssaultPack_cbr",
			"B_AssaultPack_dgtl",
			"B_AssaultPack_khk",
			"B_AssaultPack_mcamo",
			"B_AssaultPack_rgr",
			"B_AssaultPack_sgg",
			"B_Bergen_blk",
			"B_Bergen_mcamo",
			"B_Bergen_rgr",
			"B_Bergen_sgg",
			"B_Carryall_cbr",
			"B_Carryall_khk",
			"B_Carryall_mcamo",
			"B_Carryall_ocamo",
			"B_Carryall_oli",
			"B_Carryall_oucamo",
			"B_FieldPack_blk",
			"B_FieldPack_cbr",
			"B_FieldPack_ocamo",
			"B_FieldPack_oucamo",
			"B_HuntingBackpack",
			"B_Kitbag_cbr",
			"B_Kitbag_mcamo",
			"B_Kitbag_sgg",
			"B_OutdoorPack_blk",
			"B_OutdoorPack_blu",
			"B_OutdoorPack_tan",
			"B_TacticalPack_blk",
			"B_TacticalPack_mcamo",
			"B_TacticalPack_ocamo",
			"B_TacticalPack_oli",
			"B_TacticalPack_rgr",
			//New DLC Orange
			"B_Messenger_Coyote_F",
			"B_Messenger_Olive_F",
			"B_Messenger_Gray_F",
			"B_Messenger_Black_F",
			"B_Messenger_IDAP_F",
			"B_LegStrapBag_olive_F",
			"B_LegStrapBag_coyote_F",
			"B_LegStrapBag_black_F"
		};
	};
/*	
	class SNBackpacks
	{
		name = "SN Рюкзаки";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\backpack_ca.paa";
		items[] = 
		{
			"YD_carryall_black",
			"SN_coyote",
			"SN_ghex_F",
			"SN_ocamo",
			"SN_khk",
			"SN_mcamo",
			"SN_oli",
			"SN_oucamo"
		};
	};*/
	
	class EBMBackpacks
	{
		name = "EBM Рюкзаки";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\backpack_ca.paa";
		items[] = 
		{
			//"EBM_Backpack_tool_wdl",
			"EBM_Backpack_dev"
		};
	};

	class Ammunition
	{
		name = "Патроны";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\CargoMag_ca.paa";
		items[] = 
		{
			"100Rnd_65x39_caseless_mag",
			"100Rnd_65x39_caseless_mag_Tracer",
			"10Rnd_127x54_Mag",
			"10Rnd_338_Mag",
			"10Rnd_762x54_Mag",
			"10Rnd_93x64_DMR_05_Mag",
			"11Rnd_45ACP_Mag",
			"130Rnd_338_Mag",
			"150Rnd_762x54_Box",
			"150Rnd_762x54_Box_Tracer",
			"150Rnd_93x64_Mag",
			"16Rnd_9x21_Mag",
			"200Rnd_65x39_cased_Box",
			"200Rnd_65x39_cased_Box_Tracer",
			"20Rnd_556x45_UW_mag",
			"20Rnd_762x51_Mag",
			"30Rnd_45ACP_Mag_SMG_01",
			"30Rnd_45ACP_Mag_SMG_01_tracer_green",
			"30Rnd_45ACP_Mag_SMG_01_Tracer_Red",
			"30Rnd_45ACP_Mag_SMG_01_Tracer_Yellow",
			"30Rnd_556x45_Stanag",
			"30Rnd_556x45_Stanag_Tracer_Green",
			"30Rnd_556x45_Stanag_Tracer_Red",
			"30Rnd_556x45_Stanag_Tracer_Yellow",
			"30Rnd_65x39_caseless_green",
			"30Rnd_65x39_caseless_green_mag_Tracer",
			"30Rnd_65x39_caseless_mag",
			"30Rnd_65x39_caseless_mag_Tracer",
			"30Rnd_9x21_Mag",
			"30Rnd_9x21_Yellow_Mag",
			"30Rnd_9x21_Green_Mag",
			"30Rnd_9x21_Red_Mag",
			"5Rnd_127x108_APDS_Mag",
			"5Rnd_127x108_Mag",
			"6Rnd_45ACP_Cylinder",
			"6Rnd_GreenSignal_F",
			"6Rnd_RedSignal_F",
			"7Rnd_408_Mag",
			"9Rnd_45ACP_Mag",
			"Exile_Magazine_30Rnd_762x39_AK",
			"Exile_Magazine_30Rnd_545x39_AK_Green",
			"Exile_Magazine_30Rnd_545x39_AK_Red",
			"Exile_Magazine_30Rnd_545x39_AK_White",
			"Exile_Magazine_30Rnd_545x39_AK_Yellow",
			"Exile_Magazine_45Rnd_545x39_RPK_Green",
			"Exile_Magazine_75Rnd_545x39_RPK_Green",
			"Exile_Magazine_20Rnd_762x51_DMR",
			"Exile_Magazine_20Rnd_762x51_DMR_Yellow",
			"Exile_Magazine_20Rnd_762x51_DMR_Red",
			"Exile_Magazine_20Rnd_762x51_DMR_Green",
			"Exile_Magazine_10Rnd_303",
			"Exile_Magazine_100Rnd_762x54_PK_Green",
			"Exile_Magazine_7Rnd_45ACP",
			"Exile_Magazine_8Rnd_9x18",
			"Exile_Magazine_30Rnd_545x39_AK",
			"Exile_Magazine_6Rnd_45ACP",
			"Exile_Magazine_5Rnd_22LR",
			"Exile_Magazine_10Rnd_762x54",
			"Exile_Magazine_10Rnd_9x39",
			"Exile_Magazine_20Rnd_9x39",
			"Exile_Magazine_8Rnd_74Pellets",
			"Exile_Magazine_5Rnd_127x108_APDS_Bullet_Cam_Mag",
			"Exile_Magazine_10Rnd_93x64_DMR_05_Bullet_Cam_Mag",
			"Exile_Magazine_10Rnd_127x99_m107_Bullet_Cam_Mag",
			"Exile_Magazine_5Rnd_127x108_KSVK_Bullet_Cam_Mag",
			"Exile_Magazine_5Rnd_127x108_APDS_KSVK_Bullet_Cam_Mag",
			"Exile_Magazine_10Rnd_765x17_SA61",
			"Exile_Magazine_20Rnd_765x17_SA61",
			"Exile_Magazine_10Rnd_127x99_m107",
			"Exile_Magazine_5Rnd_127x108_APDS_KSVK",
			"Exile_Magazine_5Rnd_127x108_KSVK",
			"Exile_Magazine_8Rnd_74Slug",
			"Exile_Magazine_5Rnd_127x108_Bullet_Cam_Mag",
			"Exile_Magazine_7Rnd_408_Bullet_Cam_Mag",
			"Exile_Magazine_10Rnd_338_Bullet_Cam_Mag",
			//DLC Contact
            "30rnd_762x39_AK12_Lush_Mag_F",
			"30rnd_762x39_AK12_Lush_Mag_Tracer_F",
			"75Rnd_762x39_Mag_F",
			"75Rnd_762x39_Mag_Tracer_F",
            "30rnd_762x39_AK12_Arid_Mag_F",
			"30rnd_762x39_AK12_Arid_Mag_Tracer_F",
			"75rnd_762x39_AK12_Mag_F",
			"75rnd_762x39_AK12_Mag_Tracer_F",
            "75rnd_762x39_AK12_Lush_Mag_F",
			"75rnd_762x39_AK12_Lush_Mag_Tracer_F",
			"75rnd_762x39_AK12_Arid_Mag_F",
			"75rnd_762x39_AK12_Arid_Mag_Tracer_F",
            "2Rnd_12Gauge_Pellets",
			"2Rnd_12Gauge_Slug",
			"10Rnd_Mk14_762x51_Mag",
			"30Rnd_65x39_caseless_msbs_mag",
            "30Rnd_65x39_caseless_msbs_mag_Tracer"	
		};
	};

	class Flares 
	{
		name = "Зажигательные";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"Chemlight_blue",
			"Chemlight_green",
			"Chemlight_red",
			"FlareGreen_F",
			"FlareRed_F",
			"FlareWhite_F",
			"FlareYellow_F",
			"UGL_FlareGreen_F",
			"UGL_FlareRed_F",
			"UGL_FlareWhite_F",
			"UGL_FlareYellow_F",
			"3Rnd_UGL_FlareGreen_F",
			"3Rnd_UGL_FlareRed_F",
			"3Rnd_UGL_FlareWhite_F",
			"3Rnd_UGL_FlareYellow_F"
		};
	};

	class Smokes 
	{
		name = "Дымовое";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"SmokeShell",
			"SmokeShellBlue",
			"SmokeShellGreen",
			"SmokeShellOrange",
			"SmokeShellPurple",
			"SmokeShellRed",
			"SmokeShellYellow",
			"1Rnd_Smoke_Grenade_shell",
			"1Rnd_SmokeBlue_Grenade_shell",
			"1Rnd_SmokeGreen_Grenade_shell",
			"1Rnd_SmokeOrange_Grenade_shell",
			"1Rnd_SmokePurple_Grenade_shell",
			"1Rnd_SmokeRed_Grenade_shell",
			"1Rnd_SmokeYellow_Grenade_shell",
			"3Rnd_Smoke_Grenade_shell",
			"3Rnd_SmokeBlue_Grenade_shell",
			"3Rnd_SmokeGreen_Grenade_shell",
			"3Rnd_SmokeOrange_Grenade_shell",
			"3Rnd_SmokePurple_Grenade_shell",
			"3Rnd_SmokeRed_Grenade_shell",
			"3Rnd_SmokeYellow_Grenade_shell"
		};
	};

	class Explosives
	{
		name = "Взрывчатка";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\cargothrow_ca.paa";
		items[] = 
		{
			"HandGrenade",
			"MiniGrenade",
			"B_IR_Grenade",
			"O_IR_Grenade",
			"I_IR_Grenade",
			"1Rnd_HE_Grenade_shell",
			"3Rnd_HE_Grenade_shell",
			"APERSBoundingMine_Range_Mag",
			"APERSMine_Range_Mag",
			"APERSTripMine_Wire_Mag",
			"ClaymoreDirectionalMine_Remote_Mag",
			"DemoCharge_Remote_Mag",
			"IEDLandBig_Remote_Mag",
			"IEDLandSmall_Remote_Mag",
			"IEDUrbanBig_Remote_Mag",
			"IEDUrbanSmall_Remote_Mag",
			"SatchelCharge_Remote_Mag",
			"SLAMDirectionalMine_Wire_Mag"
		};
	};

	class Pistols 
	{
		name = "Пистолеты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\handgun_ca.paa";
		items[] = 
		{
			"hgun_ACPC2_F",
			"hgun_P07_F",
			"hgun_Pistol_heavy_01_F",
			"hgun_Pistol_heavy_02_F",
			"hgun_Pistol_Signal_F",
			"hgun_Rook40_F",
			"hgun_Pistol_heavy_01_green_F",
			"Exile_Weapon_Colt1911",
			"Exile_Weapon_Makarov",
			"Exile_Weapon_Taurus",
			"Exile_Weapon_TaurusGold",
			"Exile_Weapon_SA61"
		};
	};

	class SubMachineGuns 
	{
		name = "Пист.пулемёты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"hgun_PDW2000_F",
			"SMG_01_F",
			"SMG_02_F"
		};
	};

	class LightMachineGuns 
	{
		name = "Пулемёты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"arifle_MX_SW_Black_F",
			"arifle_MX_SW_F",
			"LMG_Mk200_F",
			"LMG_Zafir_F",
			"Exile_Weapon_RPK",
			"Exile_Weapon_PK",
			"Exile_Weapon_PKP",
			"MMG_01_hex_F",
			"MMG_01_tan_F",
			"MMG_02_black_F",
			"MMG_02_camo_F",
			"MMG_02_sand_F",
			//DLC Contact
			"LMG_Mk200_black_F",
			"arifle_RPK12_F",
			"arifle_RPK12_lush_F",
			"arifle_RPK12_arid_F",
		};
	};

	class AssaultRifles
	{
		name = "Автоматы";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"arifle_Katiba_C_F",
			//"arifle_Katiba_F",
			"arifle_Katiba_GL_F",
			"arifle_Mk20_F",
			"arifle_Mk20_GL_F",
			"arifle_Mk20_GL_plain_F",
			"arifle_Mk20_plain_F",
			"arifle_Mk20C_F",
			"arifle_Mk20C_plain_F",
			"arifle_MX_Black_F",
			"arifle_MX_F",
			"arifle_MX_GL_Black_F",
			"arifle_MX_GL_F",
			"arifle_MXC_Black_F",
			"arifle_MXC_F",
			"arifle_SDAR_F",
			"arifle_TRG20_F",
			"arifle_TRG21_F",
			"arifle_TRG21_GL_F",
			"Exile_Weapon_AK107",
			"Exile_Weapon_AK107_GL",
			"Exile_Weapon_AK74",
			"Exile_Weapon_AK74_GL",
			"Exile_Weapon_AK47",
			"Exile_Weapon_AKS_Gold",
			"Exile_Weapon_M4",
			"Exile_Weapon_M16A4",
			"Exile_Weapon_M16A2",
			//DLC Contact
			"arifle_AK12_GL_lush_F",
			"arifle_AK12_GL_arid_F",
			"arifle_AK12_lush_F",
			"arifle_AK12_arid_F",
			"arifle_AK12U_F",
			"arifle_AK12U_lush_F",
			"arifle_AK12U_arid_F",
			"arifle_MSBS65_black_F",
			"arifle_MSBS65_GL_F",
			"arifle_MSBS65_GL_camo_F",
			"arifle_MSBS65_GL_sand_F",
			"arifle_MSBS65_GL_black_F",
			"arifle_MSBS65_Mark_F",
			"arifle_MSBS65_Mark_camo_F",
			"arifle_MSBS65_Mark_sand_F",
			"arifle_MSBS65_Mark_black_F",
			"arifle_MSBS65_UBS_F",
			"arifle_MSBS65_UBS_camo_F",
			"arifle_MSBS65_UBS_sand_F",
			"arifle_MSBS65_UBS_black_F",
			"arifle_MSBS65_F",
			"arifle_MSBS65_camo_F",
			"arifle_MSBS65_sand_F"
		};
	};
	
	class Shotguns
	{
		name = "Дробовики";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"Exile_Weapon_M1014",
			//DLC Contact
			"sgun_HunterShotgun_01_F",
			"sgun_HunterShotgun_01_sawedoff_F"
		};
	};

	class SniperRifles
	{
		name = "Снайперские винтовки";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"arifle_MXM_Black_F",
			"arifle_MXM_F",
			"srifle_DMR_01_F",
			"srifle_DMR_02_camo_F",
			"srifle_DMR_02_F",
			"srifle_DMR_02_sniper_F",
			"srifle_DMR_03_F",
			"srifle_DMR_03_khaki_F",
			"srifle_DMR_03_multicam_F",
			"srifle_DMR_03_tan_F",
			"srifle_DMR_03_woodland_F",
			"srifle_DMR_04_F",
			"srifle_DMR_04_Tan_F",
			"srifle_DMR_05_blk_F",
			"srifle_DMR_05_hex_F",
			"srifle_DMR_05_tan_f",
			"srifle_DMR_06_camo_F",
			"srifle_DMR_06_olive_F",
			"srifle_EBR_F",
			"srifle_GM6_camo_F",
			"srifle_GM6_F",
			"srifle_LRR_camo_F",
			"srifle_LRR_F",
			"Exile_Weapon_CZ550",
			"Exile_Weapon_SVD",
			"Exile_Weapon_SVDCamo",
			"Exile_Weapon_VSSVintorez",
			"Exile_Weapon_DMR",
			"Exile_Weapon_LeeEnfield",
			"Exile_Weapon_m107",
			"Exile_Weapon_ksvk",
			//DLC Contact
			"srifle_DMR_06_hunter_F"
		};
	};

	class Cars
	{
		name = "Автомобили";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			//DLC Contact
			"I_E_Offroad_01_covered_F",
			"B_GEN_Offroad_01_covered_F",
			"B_GEN_Offroad_01_comms_F",
			"C_Offroad_01_covered_F",
			"C_Offroad_01_comms_F",
			"I_E_Offroad_01_comms_F",		
			"Exile_Car_LandRover_Green",
			"Exile_Car_LandRover_Ambulance_Green",
			"Exile_Car_Hatchback_Rusty3",
			"Exile_Car_Hatchback_Green",
			"Exile_Car_Hatchback_BlueCustom",
			"Exile_Car_Hatchback_BeigeCustom",
			"Exile_Car_Hatchback_Yellow",
			"Exile_Car_Hatchback_Grey",
			"Exile_Car_Hatchback_Black",
			"Exile_Car_Hatchback_Sport_Red",
			"Exile_Car_Hatchback_Sport_Blue",
			"Exile_Car_Hatchback_Sport_Orange",
			"Exile_Car_Hatchback_Sport_White",
			"Exile_Car_Hatchback_Sport_Beige",
			"Exile_Car_Hatchback_Sport_Green",
			"Exile_Car_SUV_Red",
			"Exile_Car_SUV_Black",
			"Exile_Car_SUV_Grey",
			"Exile_Car_SUV_Orange",
			"Exile_Car_SUVXL_Black",
			"Exile_Car_Offroad_Rusty1",
			"Exile_Car_Offroad_Rusty2",
			"Exile_Car_Offroad_Rusty3",
			"Exile_Car_Offroad_Repair_Civillian",
			"Exile_Car_BTR40_Green",
			"Exile_Car_HMMWV_MEV_Green",
			"Exile_Car_HMMWV_UNA_Green",
			"Exile_Car_Strider",
			"Exile_Car_Hunter",
			"Exile_Car_Ifrit"
		};
	};
	
	class ArmedCars
	{
		name = "Вооруженная техника";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"Exile_Car_Offroad_Armed_Guerilla01",
			"Exile_Car_Offroad_Armed_Guerilla12",
			"Exile_Car_BRDM2_HQ",
			"Exile_Car_HMMWV_M2_Green",
			"Exile_Car_HMMWV_M2_Desert",
			"I_MRAP_03_hmg_F",
			"I_MRAP_03_gmg_F",
			"B_MRAP_01_hmg_F",
			"B_MRAP_01_gmg_F",
			"O_MRAP_02_hmg_F",
			"O_MRAP_02_gmg_F",
            "B_APC_Wheeled_01_cannon_F",
		    "O_APC_Wheeled_02_rcws_F",
			"O_APC_Wheeled_02_rcws_v2_F",
		    "I_APC_Wheeled_03_cannon_F",
			"B_AFV_Wheeled_01_cannon_F",
			"B_T_AFV_Wheeled_01_cannon_F",
			"B_AFV_Wheeled_01_up_cannon_F",
			"B_T_AFV_Wheeled_01_up_cannon_F"
		};
	};

	class Trucks
	{
		name = "Грузовики";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"Exile_Car_Van_Black",
			"Exile_Car_Van_Guerilla01",
			"Exile_Car_Van_Box_Black",
			"Exile_Car_Van_Fuel_Black",
			"Exile_Car_Van_Fuel_White",
			"Exile_Car_Van_Fuel_Red",
			"Exile_Car_Van_Fuel_Guerilla03",
			"Exile_Car_Van_Fuel_Guerilla02",
			"Exile_Car_Van_Fuel_Guerilla01",
			"Exile_Car_Ural_Open_Worker",
			"Exile_Car_Ural_Open_Military",
			"Exile_Car_Ural_Covered_Worker",
			"Exile_Car_Ural_Covered_Military",
			"Exile_Car_V3S_Covered",
			"Exile_Car_Zamak",
			"Exile_Car_Tempest",
			"Exile_Car_HEMMT",
			"O_Truck_02_medical_F",
			"O_Truck_03_repair_F",
			"B_Truck_01_fuel_F",
			"O_Truck_03_fuel_F",
			"O_Truck_02_fuel_F",
			"B_Truck_01_box_F",
			"B_Truck_01_ammo_F",
			"B_Truck_01_Repair_F",
			"O_Truck_02_box_F",
			"O_Truck_02_Ammo_F",
			"B_Truck_01_mover_F",
			"O_Truck_03_ammo_F",
			"O_Truck_03_device_F",
            //DLC Contact
			"B_Truck_01_cargo_F",
			"B_T_Truck_01_cargo_F",
			"B_Truck_01_flatbed_F",
			"B_T_Truck_01_flatbed_F"
		};
	};

	class Choppers
	{
		name = "Вертолёты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"Exile_Chopper_Hummingbird_Green",
			"Exile_Chopper_Hummingbird_Civillian_Wasp",
			"Exile_Chopper_Taru_Black",
			"Exile_Chopper_Taru_Covered_Black",
			"O_Heli_Transport_04_repair_F",
			"O_Heli_Transport_04_fuel_F",
			"Exile_Chopper_Taru_Transport_Black",
			"Exile_Chopper_Orca_BlackCustom",
			"Exile_Chopper_Mohawk_FIA",
			"I_Heli_Transport_02_F",
			"C_IDAP_Heli_Transport_02_F",
			"Exile_Chopper_Huron_Black",
            "Exile_Chopper_Hellcat_Green"
		};
	};
	
	class ArmedChoppers
	{
		name = "Вооруженные Вертолёты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"B_Heli_Transport_01_F",
			"B_Heli_Transport_01_camo_F",
			"B_CTRG_Heli_Transport_01_sand_F",
			"B_CTRG_Heli_Transport_01_tropic_F",
			"B_Heli_Light_01_dynamicLoadout_F",
			"B_Heli_Light_01_armed_F",
			"B_Heli_Attack_01_F",
			"B_Heli_Attack_01_dynamicLoadout_F",
			"B_Heli_Transport_03_F",
			"B_Heli_Transport_03_black_F",
			"O_Heli_Attack_02_black_F",
			"O_Heli_Attack_02_F",
			"O_Heli_Attack_02_dynamicLoadout_F",
			"O_Heli_Light_02_F",
			"O_Heli_Light_02_v2_F",
			"I_Heli_light_03_F"
		};
	};

	class Boats
	{
		name = "Лодки";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"Exile_Boat_RubberDuck_Blue",
			"Exile_Boat_RubberDuck_Black",
			"Exile_Boat_MotorBoat_Orange",
			"Exile_Boat_MotorBoat_White",
			"Exile_Boat_SDV_CSAT",
			"Exile_Boat_SDV_Digital",
			"Exile_Boat_SDV_Grey",
			"B_Boat_Transport_01_F",
			"I_Boat_Transport_01_F",
		    "B_Boat_Armed_01_minigun_F",
			"I_Boat_Armed_01_minigun_F",
			"O_Boat_Armed_01_hmg_F",
			"Exile_Boat_WaterScooter",
			"Exile_Boat_RHIB"
		};
	};
	
	class ArmedPlanes
	{
		name = "Вооруженные Самолёты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";

		items[] = 
		{
			"I_Plane_Fighter_03_dynamicLoadout_F",
			"O_Plane_CAS_02_dynamicLoadout_F",
			"B_Plane_CAS_01_dynamicLoadout_F",
			"B_Plane_Fighter_01_F",
			"B_Plane_Fighter_01_Stealth_F",
			"O_Plane_Fighter_02_F",
			"O_Plane_Fighter_02_Stealth_F",
			"O_Plane_CAS_02_F",
			"I_Plane_Fighter_03_AA_F",
			"B_Plane_CAS_01_F"
		};
	};
	
	class Tank
	{
		name = "Гусеничная техника";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemoptic_ca.paa";
		items[] = 
		{	
		    "B_APC_Tracked_01_CRV_F",
			"B_T_APC_Tracked_01_CRV_F",
	     	"B_APC_Tracked_01_rcws_F",
			"B_T_APC_Tracked_01_rcws_F",
		    "I_APC_tracked_03_cannon_F",
		    "B_MBT_01_cannon_F",
			"B_T_MBT_01_cannon_F",
		    "B_MBT_01_TUSK_F",
			"B_T_MBT_01_TUSK_F",
		    "I_MBT_03_cannon_F",
		    "O_MBT_02_cannon_F",
			"O_T_MBT_02_cannon_ghex_F",
		    "O_APC_Tracked_02_cannon_F",
			"O_T_APC_Tracked_02_cannon_ghex_F",
		    "B_APC_Tracked_01_AA_F",
			"B_T_APC_Tracked_01_AA_F",
		    "O_APC_Tracked_02_AA_F",
            "I_LT_01_scout_F",
			"I_LT_01_cannon_F",
			"I_LT_01_AT_F",
			"I_LT_01_AA_F",
			"O_MBT_04_cannon_F",
			"O_T_MBT_04_cannon_F",
			"O_MBT_04_command_F",
			"O_T_MBT_04_command_F"
		};
	};
	
	class Artillery
	{
		name = "Артиллерия";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemoptic_ca.paa";
		items[] = 
		{	
		    "rhsusf_m109_usarmy",
		    "rhsusf_m109d_usarmy",
		    "rhs_2s3_tv",
            //"RHS_BM21_MSV_01",
		    "RHS_BM21_VDV_01",
		    //"RHS_BM21_VMF_01",
            //"RHS_BM21_VV_01",
			//"rhsusf_M142_usarmy_WD",
			//"rhsusf_M142_usarmy_D",
			//"rhsusf_M142_usmc_WD",
			"CUP_B_M270_HE_USMC",
			//"CUP_B_M270_DPICM_USMC",
			//"CUP_B_M270_HE_USA",
			//"CUP_B_M270_DPICM_USA",
			//"CUP_I_M270_HE_AAF",
			//"CUP_I_M270_DPICM_AAF",
			"CUP_O_BM21_RU",
			//"CUP_B_BM21_CDF",
			//"CUP_O_BM21_CHDKZ",
			//"CUP_O_BM21_TKA",
			//"CUP_O_BM21_SLA",
			"min_rf_2b26",
			//"min_rf_2b26_desert",
			//"min_rf_2b26_winter",
			"O_MBT_02_arty_F",
			"O_T_MBT_02_arty_ghex_F",
			"B_MBT_01_arty_F",
			"B_T_MBT_01_arty_F",
	        "I_Truck_02_MRL_F",
            "B_MBT_01_mlrs_F",
		    "B_T_MBT_01_mlrs_F"
		};
	};

	class Diving
	{
		name = "Дайвинг";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"G_B_Diving",
			"G_O_Diving",
			"G_I_Diving",
			"V_RebreatherB",
			"V_RebreatherIA",
			"V_RebreatherIR",
			"U_I_Wetsuit",
			"U_O_Wetsuit",
			"U_B_Wetsuit"
/*			"B_SCBA_01_F",
			"B_CombinationUnitRespirator_01_F",
			"G_RegulatorMask_F",
			"G_AirPurifyingRespirator_02_olive_F",
			"G_AirPurifyingRespirator_02_sand_F",
			"G_AirPurifyingRespirator_02_black_F",
			"G_AirPurifyingRespirator_01_F"*/
		};
	};