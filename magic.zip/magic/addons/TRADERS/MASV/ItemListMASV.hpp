    ///////////////////////////////////////////////////////////////////////////////
	// Автомобили
	//////////////////////////////////////////////////////////////////////////////
	class I_mas_cars_UAZ_Unarmed  				  { quality = 1; price = 15000; };
	class B_mas_cars_LR_Unarmed 				  { quality = 2; price = 30000; };
	class I_mas_cars_LR_soft_Unarmed 			  { quality = 2; price = 30000; };
	class B_mas_HMMWV_UNA 						  { quality = 2; price = 35000; };
	class B_mas_cars_Hilux_Unarmed 				  { quality = 2; price = 35000; };

	///////////////////////////////////////////////////////////////////////////////
	// Вооруженная техника
	//////////////////////////////////////////////////////////////////////////////
	class I_mas_cars_UAZ_M2 					  { quality = 3; price = 33000; };
	class I_mas_cars_UAZ_MG 					  { quality = 3; price = 34000; };
	class I_mas_cars_UAZ_AGS30 					  { quality = 3; price = 35000; };
	class I_mas_cars_UAZ_SPG9 					  { quality = 3; price = 35500; };
	class B_mas_cars_Hilux_M2 					  { quality = 3; price = 36000; };
	class B_mas_cars_Hilux_MG 					  { quality = 3; price = 37000; };
	class B_mas_cars_Hilux_AGS30 				  { quality = 3; price = 38000; };
	class B_mas_cars_Hilux_SPG9 				  { quality = 3; price = 38500; };
	class B_mas_cars_LR_M2	        			  { quality = 3; price = 39000; };
	class B_mas_cars_LR_Mk19	        		  { quality = 3; price = 39500; };
	class B_mas_cars_LR_SPG9					  { quality = 3; price = 40000; };
	class B_mas_cars_LR_Stinger					  { quality = 3; price = 41000; };
    class B_mas_cars_LR_TOW						  { quality = 3; price = 42000; };
    class I_mas_cars_LR_soft_M2					  { quality = 3; price = 39000; };
    class I_mas_cars_LR_soft_Mk19				  { quality = 3; price = 39500; };
    class I_mas_cars_LR_soft_SPG9				  { quality = 3; price = 40000; };
    class I_mas_cars_LR_soft_Stinger			  { quality = 3; price = 41000; };
	class I_mas_cars_LR_soft_TOW 				  { quality = 3; price = 42000; };
	class B_mas_HMMWV_M2 						  { quality = 3; price = 39000; };
	class B_mas_HMMWV_M134 						  { quality = 3; price = 39400; };
	class B_mas_HMMWV_SOV_M134 					  { quality = 3; price = 39400; };
	class B_mas_HMMWV_MK19						  { quality = 3; price = 39500; };
	class B_mas_HMMWV_SOV						  { quality = 3; price = 39500; };
	class B_mas_HMMWV_Stinger					  { quality = 3; price = 41000; };
    class B_mas_HMMWV_TOW						  { quality = 3; price = 42000; };
	class I_mas_BRDM2							  { quality = 4; price = 80000; };
    class O_mas_BRDM2							  { quality = 4; price = 80000; };
	class I_mas_BTR60 							  { quality = 4; price = 90000; };
	class O_mas_BTR60 						      { quality = 4; price = 90000; };
	class I_mas_cars_Ural_ZU23                    { quality = 4; price = 60000; };

	///////////////////////////////////////////////////////////////////////////////
	// Грузовики
	///////////////////////////////////////////////////////////////////////////////
	class I_mas_cars_Ural	                		{ quality = 1; price = 50000; };
	class I_mas_cars_Ural_open 						{ quality = 1; price = 50000; };
	class I_mas_cars_Ural_ammo 						{ quality = 4; price = 50000; };
	class I_mas_cars_Ural_fuel 						{ quality = 4; price = 50000; };
	class I_mas_cars_Ural_repair 					{ quality = 4; price = 50000; };

	///////////////////////////////////////////////////////////////////////////////
	// Гусеничная техника
	///////////////////////////////////////////////////////////////////////////////
	class I_mas_BMP2_Ambul_01	                    { quality = 2; price = 50000; };
	class I_mas_BMP2_HQ_AAF_01 						{ quality = 2; price = 60000; };
	class I_mas_BMP1_AAF_01 						{ quality = 4; price = 85000; };
	class I_mas_BMP1P_AAF_01 						{ quality = 4; price = 95000; };
	class I_mas_BMP2_AAF_01 						{ quality = 4; price = 100000; };
	class I_mas_ZSU_AAF_01 							{ quality = 4; price = 110000; };
	class I_mas_T34_AAF_01 							{ quality = 6; price = 150000; };
	class I_mas_T55_AAF_01 							{ quality = 7; price = 200000; };
	class O_mas_T55_OPF_01 							{ quality = 7; price = 200000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Вертолёты
	///////////////////////////////////////////////////////////////////////////////
	class B_mas_UH1Y_UNA_F	                		{ quality = 2; price = 60000; };
	class B_mas_UH60M_MEV 							{ quality = 2; price = 60000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Вооруженные Вертолёты
	///////////////////////////////////////////////////////////////////////////////
	class B_mas_UH60M_SF	                		{ quality = 3; price = 70000; };
	class B_mas_UH60M 								{ quality = 3; price = 71000; };
	class B_mas_UH1Y_F 								{ quality = 4; price = 80000; };
	class B_mas_CH_47F                              { quality = 3; price = 70000; };
	class I_mas_MI8 								{ quality = 3; price = 70000; };
	class I_mas_MI8MTV 								{ quality = 5; price = 100000; };
	class I_mas_MI24V 								{ quality = 6; price = 250000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Вооруженные Самолёты
	///////////////////////////////////////////////////////////////////////////////
	class mas_F_35C	                				{ quality = 10; price = 250000; };
	class mas_F_35C_S 								{ quality = 10; price = 250000; };
	class mas_F_35C_cas 							{ quality = 10; price = 250000; };
	class mas_F_35C_cap 							{ quality = 10; price = 250000; };