	class MASCars
	{
		name = "MAS Автомобили";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"I_mas_cars_UAZ_Unarmed",
			"B_mas_cars_LR_Unarmed",
			"I_mas_cars_LR_soft_Unarmed",
			"B_mas_HMMWV_UNA",
			"B_mas_cars_Hilux_Unarmed"
		};
	};

	class MASArmed
	{
		name = "MAS Вооруженная техника";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"I_mas_cars_UAZ_M2",
			"I_mas_cars_UAZ_MG",
			"I_mas_cars_UAZ_AGS30",
			"I_mas_cars_UAZ_SPG9",
			"B_mas_cars_Hilux_M2",
			"B_mas_cars_Hilux_MG",
			"B_mas_cars_Hilux_AGS30",
			"B_mas_cars_Hilux_SPG9",
			"B_mas_cars_LR_M2",
			"B_mas_cars_LR_Mk19",
			"B_mas_cars_LR_SPG9",
			"B_mas_cars_LR_Stinger",
			"B_mas_cars_LR_TOW",
			"I_mas_cars_LR_soft_M2",
			"I_mas_cars_LR_soft_Mk19",
			"I_mas_cars_LR_soft_SPG9",
			"I_mas_cars_LR_soft_Stinger",
			"I_mas_cars_LR_soft_TOW",
			"B_mas_HMMWV_M2",
			"B_mas_HMMWV_M134",
			"B_mas_HMMWV_SOV_M134",
			"B_mas_HMMWV_MK19",
			"B_mas_HMMWV_SOV",
			"B_mas_HMMWV_Stinger",
			"B_mas_HMMWV_TOW",
			"I_mas_cars_Ural_ZU23",
			"I_mas_BRDM2",
			"O_mas_BRDM2",
			"I_mas_BTR60",
			"O_mas_BTR60"
		};
	};

	class MASTrucks
	{
		name = "MAS Грузовики";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"I_mas_cars_Ural",
			"I_mas_cars_Ural_open",
			"I_mas_cars_Ural_ammo",
			"I_mas_cars_Ural_fuel",
			"I_mas_cars_Ural_repair"
		};
	};

	class MASTanks
	{
		name = "MAS Гусеничная техника";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"I_mas_BMP2_Ambul_01",
			"I_mas_BMP2_HQ_AAF_01",
			"I_mas_BMP1_AAF_01",
			"I_mas_BMP1P_AAF_01",
			"I_mas_BMP2_AAF_01",
			"I_mas_ZSU_AAF_01",
			"I_mas_T34_AAF_01",
			"I_mas_T55_AAF_01",
			"O_mas_T55_OPF_01"
		};
	};

	class MASChoppers
	{
		name = "MAS Вертолёты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[]=
		{
			"B_mas_UH1Y_UNA_F",
			"B_mas_UH60M_MEV"
		};
	};
	
	class MASArmedChoppers
	{
		name = "MAS Вооруженные Вертолёты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[]=
		{
			"B_mas_UH60M_SF",
			"B_mas_UH60M",
			"B_mas_UH1Y_F",
			"B_mas_CH_47F",
			"I_mas_MI8",
			"I_mas_MI8MTV",
			"I_mas_MI24V"
		};
	};

	class MASPlanes
	{
		name = "MAS Вооруженные Самолёты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[]=
		{
			"mas_F_35C",
			"mas_F_35C_S",
			"mas_F_35C_cas",
			"mas_F_35C_cap"
		};
	};
