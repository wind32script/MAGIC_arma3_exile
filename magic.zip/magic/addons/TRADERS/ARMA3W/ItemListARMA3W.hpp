    ///////////////////////////////////////////////////////////////////////////////
	// Гранатометы
	///////////////////////////////////////////////////////////////////////////////	
	class launch_NLAW_F  							{ quality = 5; price = 7000; };
	class launch_RPG32_F   							{ quality = 5; price = 7000; };
	class launch_B_Titan_F  						{ quality = 10; price = 8000; };
	class launch_I_Titan_F  						{ quality = 10; price = 8000; };
	class launch_O_Titan_F 							{ quality = 10; price = 8000; };
	class launch_Titan_F  							{ quality = 10; price = 8000; };
	class launch_B_Titan_short_F  					{ quality = 10; price = 8000; };
	class launch_I_Titan_short_F  					{ quality = 10; price = 8000; };
	class launch_O_Titan_short_F  					{ quality = 10; price = 8000; };
	class launch_Titan_short_F 						{ quality = 10; price = 8000; };
	//DLC Tank
	class launch_O_Vorona_green_F                   { quality = 10; price = 15000; };
	class launch_O_Vorona_brown_F                   { quality = 10; price = 15000; };
	class launch_MRAWS_green_rail_F                 { quality = 10; price = 15000; };
	class launch_MRAWS_olive_rail_F                 { quality = 10; price = 15000; };
	class launch_MRAWS_sand_rail_F                  { quality = 10; price = 15000; };
	class launch_MRAWS_green_F                      { quality = 10; price = 15000; };
	class launch_MRAWS_olive_F                      { quality = 10; price = 15000; };
	class launch_MRAWS_sand_F                       { quality = 10; price = 15000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Снаряды для гранатометов
	///////////////////////////////////////////////////////////////////////////////
	class NLAW_F									{ quality = 4; price = 800; };
	class Titan_AT									{ quality = 6; price = 800; };
	class Titan_AP									{ quality = 6; price = 800; };
	class Titan_AA									{ quality = 6; price = 800; };
	class RPG32_F									{ quality = 4; price = 700; };
	class RPG32_HE_F                                { quality = 4; price = 700; };
	//DLC Tank
	class Vorona_HEAT                               { quality = 6; price = 1500; };
	class Vorona_HE                                 { quality = 6; price = 1500; };
	class MRAWS_HEAT_F                              { quality = 6; price = 1500; };
	class MRAWS_HE_F                                { quality = 6; price = 1500; };