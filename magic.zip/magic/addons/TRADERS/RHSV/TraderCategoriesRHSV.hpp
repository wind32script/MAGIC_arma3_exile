    class RHSCars
	{
		name = "RHS Автомобили";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"rhs_uaz_open_vdv",
			"rhs_uaz_vdv",
			"rhs_tigr_vdv",
			"rhs_tigr_3camo_vdv",
			"rhs_tigr_m_vdv",
			"rhs_tigr_m_3camo_vdv",
//			"rhsusf_mrzr4_d",
			"rhsusf_rg33_usmc_d",
			"rhsusf_rg33_usmc_wd",
			"rhsusf_m998_w_2dr",
			"rhsusf_m998_w_4dr",
			"rhsusf_m1025_w",
			"rhsusf_M1220_usarmy_d",
			"rhsusf_M1220_usarmy_wd",
			"rhsusf_M1230a1_usarmy_d",
			"rhsusf_M1230a1_usarmy_wd",
			"rhsusf_M1232_usarmy_d",
			"rhsusf_M1232_usarmy_wd",
			"rhsusf_CGRCAT1A2_usmc_d",
			"rhsusf_CGRCAT1A2_usmc_wd"
			//GREF
			//"rhsgref_BRDM2UM"
		};
	};
	
	class RHSArmedCars
	{
		name = "RHS Вооруженная техника";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"rhs_tigr_sts_vdv",
			"rhs_tigr_sts_3camo_vdv",
			"rhsusf_CGRCAT1A2_M2_usmc_d",
			"rhsusf_CGRCAT1A2_M2_usmc_wd",
			"rhsusf_CGRCAT1A2_Mk19_usmc_d",
			"rhsusf_CGRCAT1A2_Mk19_usmc_wd",
//			"rhs_gaz66_zu23_vdv",
			"RHS_Ural_Zu23_VDV_01",
			"rhs_btr60_vmf",
			"rhs_btr60_vdv",
			"rhs_btr60_vv",
			"rhs_btr60_msv",
			"rhs_btr70_vmf",
			"rhs_btr70_vdv",
			"rhs_btr70_vv",
			"rhs_btr70_msv",
			"rhs_btr80_msv",
			"rhs_btr80_vdv",
			"rhs_btr80_vv",
			"rhs_btr80_vmf",
			"rhs_btr80a_msv",
			"rhs_btr80a_vdv",
			"rhs_btr80a_vv",
			"rhs_btr80a_vmf",
			"rhsusf_m1025_w_m2",
			"rhsusf_m1025_d_s_m2",
			"rhsusf_m1025_w_mk19",
			"rhsusf_m1025_d_s_Mk19",
			"rhsusf_rg33_m2_usmc_d",
			"rhsusf_rg33_m2_usmc_wd",
			"rhsusf_M1220_M153_M2_usarmy_d",
			"rhsusf_M1220_M153_M2_usarmy_wd",
			"rhsusf_M1220_M2_usarmy_d",
			"rhsusf_M1220_M2_usarmy_wd",
			"rhsusf_M1230_M2_usarmy_d",
			"rhsusf_M1230_M2_usarmy_wd",
			"rhsusf_M1230_MK19_usarmy_d",
			"rhsusf_M1230_MK19_usarmy_wd",
			"rhsusf_M1232_M2_usarmy_d",
			"rhsusf_M1232_M2_usarmy_wd",
			"rhsusf_M1232_MK19_usarmy_d",
			"rhsusf_M1232_MK19_usarmy_wd",
			"rhsusf_M1237_M2_usarmy_d",
			"rhsusf_M1237_M2_usarmy_wd",
			"rhsusf_M1237_MK19_usarmy_d",
			"rhsusf_M1237_MK19_usarmy_wd",
			"rhsusf_M1117_D",
			"rhsusf_M1117_W",
			"rhsusf_M1117_O",
			"rhsusf_M1078A1P2_B_M2_WD_fmtv_usarmy",
			"rhsusf_M1078A1P2_B_M2_D_flatbed_fmtv_usarmy",
			"rhsusf_M1078A1R_SOV_M2_D_fmtv_socom",
			"rhsusf_M1083A1P2_B_M2_WD_fmtv_usarmy",
			"rhsusf_M1083A1P2_B_M2_D_flatbed_fmtv_usarmy",
			"rhsusf_M1084A1P2_B_M2_WD_fmtv_usarmy",
			"rhsusf_M1084A1P2_B_M2_D_fmtv_usarmy",
			"rhsusf_M1084A1R_SOV_M2_D_fmtv_socom",
			"rhsusf_M977A4_REPAIR_BKIT_M2_usarmy_wd",
			"rhsusf_M977A4_REPAIR_BKIT_M2_usarmy_d",
			"rhsusf_M977A4_BKIT_M2_usarmy_wd",
			"rhsusf_M977A4_BKIT_M2_usarmy_d",
			"rhsusf_M977A4_AMMO_BKIT_M2_usarmy_wd",
			"rhsusf_M977A4_AMMO_BKIT_M2_usarmy_d"
		};
	};
	
	class RHSTrucks
	{
		name = "RHS Грузовики";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"RHS_Ural_Open_VDV_01",
			"RHS_Ural_VDV_01",
			"RHS_Ural_Repair_VDV_01",
			"RHS_Ural_Fuel_VDV_01",
			"rhs_typhoon_vdv",
			"rhs_gaz66_r142_vdv",
			"rhs_gaz66_ap2_vdv",
			"rhs_gaz66_vdv",
			"rhs_gaz66_ammo_vdv",
			"rhs_gaz66_repair_vdv",
			"rhs_kamaz5350_vdv",
			"rhsusf_M1078A1P2_WD_fmtv_usarmy",
			"rhsusf_M1078A1P2_D_flatbed_fmtv_usarmy",
			"rhsusf_M1078A1P2_B_WD_fmtv_usarmy",			
			"rhsusf_M1078A1P2_B_D_flatbed_fmtv_usarmy",
			"rhsusf_M1078A1P2_B_WD_CP_fmtv_usarmy",
			"rhsusf_M1078A1P2_B_D_CP_fmtv_usarmy",
			"rhsusf_M1083A1P2_WD_fmtv_usarmy",
			"rhsusf_M1083A1P2_D_flatbed_fmtv_usarmy",
			"rhsusf_M1083A1P2_B_WD_fmtv_usarmy",
			"rhsusf_M1083A1P2_B_D_flatbed_fmtv_usarmy",
			"rhsusf_M1084A1P2_WD_fmtv_usarmy",
			"rhsusf_M1084A1P2_D_fmtv_usarmy",
			"rhsusf_M1084A1P2_B_WD_fmtv_usarmy",
			"rhsusf_M1084A1P2_B_D_fmtv_usarmy",
			"rhsusf_M1085A1P2_B_WD_Medical_fmtv_usarmy",
			"rhsusf_M1085A1P2_B_D_Medical_fmtv_usarmy",
			"rhsusf_M977A4_usarmy_wd",
			"rhsusf_M977A4_usarmy_d",
			"rhsusf_M977A4_BKIT_usarmy_wd",
			"rhsusf_M977A4_BKIT_usarmy_d",
			"rhsusf_M977A4_REPAIR_BKIT_M2_usarmy_wd",
			"rhsusf_M977A4_REPAIR_BKIT_M2_usarmy_d",
			"rhsusf_M977A4_REPAIR_BKIT_usarmy_wd",
			"rhsusf_M977A4_REPAIR_BKIT_usarmy_d",
			"rhsusf_M977A4_REPAIR_usarmy_wd",
			"rhsusf_M977A4_REPAIR_usarmy_d",
			"rhsusf_M977A4_AMMO_BKIT_usarmy_wd",
			"rhsusf_M977A4_AMMO_BKIT_usarmy_d",
			"rhsusf_M977A4_AMMO_usarmy_wd",
			"rhsusf_M977A4_AMMO_usarmy_d",
			"rhsusf_M978A4_usarmy_wd",
			"rhsusf_M978A4_usarmy_d",
			"rhsusf_M978A4_BKIT_usarmy_wd",
			"rhsusf_M978A4_BKIT_usarmy_d"
		};
	};
	
	class RHSTanks
	{
		name = "RHS Гусеничная техника";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{	
			"rhs_pts_vmf",
			"rhsusf_m113_usarmy_medical",
			"rhsusf_m113d_usarmy_medical",
			"rhs_bmd1",
			"rhs_bmd1k",
			"rhs_bmd1p",
			"rhs_bmd1pk",
			"rhs_bmd1r",
			"rhs_bmd2",
			"rhs_bmd2k",
			"rhs_bmd2m",
			"rhs_bmd4_vdv",
			"rhs_bmd4m_vdv",
			"rhs_bmd4ma_vdv",
			"rhs_bmp1_vdv",
			"rhs_bmp1d_vdv",
			"rhs_bmp1k_vdv",
			"rhs_bmp1p_vdv",
			"rhs_bmp2e_vdv",
			"rhs_bmp2_vdv",
			"rhs_bmp2d_vdv",
			"rhs_bmp2k_vdv",
			"rhs_bmp3_msv",
			"rhs_bmp3m_msv",
			"rhs_bmp3mera_msv",
			"rhs_bmp3_late_msv",
			"rhs_brm1k_vdv",
			"rhs_Ob_681_2",
			"rhs_sprut_vdv",
			"rhs_zsu234_aa",
			"rhsusf_m113_usarmy_M2_90",
			"rhsusf_m113_usarmy_MK19_90",
			"rhsusf_m113_usarmy_supply",
			"rhsusf_m113d_usarmy_supply",
			"rhsusf_m113_usarmy",
			"rhsusf_m113d_usarmy",
			"rhsusf_m113_usarmy_M240",
			"rhsusf_m113d_usarmy_M240",
			"rhsusf_m113_usarmy_MK19",
			"rhsusf_m113d_usarmy_MK19",
			"RHS_M2A2",
			"RHS_M6_wd",
			"RHS_M2A2_BUSKI",
			"RHS_M2A2_BUSKI_WD",
			"RHS_M2A3",
			"RHS_M2A3_wd",
			"RHS_M2A3_BUSKI",
			"RHS_M2A3_BUSKI_wd",
			"RHS_M2A3_BUSKIII",
			"RHS_M2A3_BUSKIII_wd",
			"rhs_t72ba_tv",
			"rhs_t72bb_tv",
			"rhs_t72bc_tv",
			"rhs_t72bd_tv",
			"rhs_t80",
			"rhs_t80a",
			"rhs_t80b",
			"rhs_t80bk",
			"rhs_t80bv",
			"rhs_t80bvk",
			"rhs_t80u",
			"rhs_t80u45m",
			"rhs_t80ue1",
			"rhs_t80um",
			"rhs_t80uk",
			"rhs_t90_tv",
			"rhs_t90a_tv",
			"rhsusf_m1a1fep_d",
			"rhsusf_m1a1fep_wd",
			"rhsusf_m1a1fep_od",
			"rhsusf_m1a1hc_wd",
			"rhsusf_m1a1aimwd_usarmy",
			"rhsusf_m1a1aimd_usarmy",
			"rhsusf_m1a1aim_tuski_wd",
			"rhsusf_m1a1aim_tuski_d",
			"rhsusf_m1a2sep1d_usarmy",
			"rhsusf_m1a2sep1wd_usarmy",
			"rhsusf_m1a2sep1tuskid_usarmy",
			"rhsusf_m1a2sep1tuskiwd_usarmy",
			"rhsusf_m1a2sep1tuskiiwd_usarmy",
			"rhsusf_m1a2sep1tuskiid_usarmy"
		};
	};
	
	class RHSChoppers
	{
		name = "RHS Вертолёты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[]=
		{			
			"rhs_ka60_grey",
			"RHS_Mi8AMT_vvs",
			"RHS_Mi8AMT_vvsc",
			"RHS_Mi8AMT_vdv",
			"RHS_Mi8amt_civilian",
			"RHS_MELB_H6M",
			"RHS_UH60M_MEV",
			"RHS_UH60M_MEV2_d",
			"RHS_UH60M2_d",
			"RHS_UH60M_ESSS2_d",
			"rhsusf_CH53E_USMC",
			"rhsusf_CH53E_USMC_D"
			//GREF
			//"rhs_uh1h_hidf_unarmed"
		};
	};
	
	class RHSArmedChoppers
	{
		name = "RHS Вооруженные Вертолёты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[]=
		{			
			"RHS_Mi8mt_vdv",
			"RHS_Mi8mt_Cargo_vdv",
			"RHS_Mi8MTV3_vdv",
			"RHS_Mi8mtv3_Cargo_vdv",
			"RHS_Mi8AMTSh_vvs", 
			"RHS_Mi8AMTSh_vvsc",
			"RHS_Mi24Vt_vvs",
			"RHS_Mi24Vt_vvsc",
			"RHS_Mi24P_vvs",
			"RHS_Mi24P_vvsc",
			"RHS_Mi24P_vdv",
			"RHS_Mi24V_vvs",
			"RHS_Mi24V_vvsc",
			"RHS_Mi24V_vdv",
			"rhs_mi28n_vvs", 
			"rhs_mi28n_vvsc",
			"RHS_Ka52_vvsc",
			"RHS_Ka52_vvs",
			"RHS_UH60M",
			"RHS_UH60M_d",
			"RHS_UH1Y_d",
			"RHS_UH1Y_UNARMED_d",
			"RHS_AH64D",
			"RHS_AH64D_wd",
			"RHS_AH64DGrey",
			"RHS_AH1Z",
			"RHS_AH1Z_wd"
			//GREF
			//"rhs_uh1h_hidf",
			//"rhs_uh1h_hidf_gunship",
			//"rhsgref_mi24g_CAS",
			//"rhsgref_b_mi24g_CAS"
		};
	};
	
	class RHSPlanes
	{
		name = "RHS Вооруженные Самолёты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[]=
		{			
			"RHS_Su25SM_vvs", 
			"RHS_Su25SM_vvsc",
			"RHS_T50_vvs_generic",
			"RHS_T50_vvs_generic_ext",
			"RHS_T50_vvs_051",
			"RHS_T50_vvs_052",
			"RHS_T50_vvs_053",
			"RHS_T50_vvs_054",
			"RHS_T50_vvs_blueonblue",
			"rhsusf_f22",
			"RHS_A10"
			//GREF
			//"rhs_l159_CDF",
			//"rhs_l159_cdf_b_CDF",
			//"rhs_l39_cdf",
			//"rhs_l39_cdf_b_cdf"
		};
	};
	
	class RHSBoats
	{
		name = "RHS Лодки";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"rhsusf_mkvsoc"
			//GREF
			//"rhsgref_hidf_canoe",
			//"rhsgref_civ_canoe"
		};
	};