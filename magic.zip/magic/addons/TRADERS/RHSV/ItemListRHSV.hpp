	/////////////////////////////////////////////////////////////////////////////////
	// Автомобили
	/////////////////////////////////////////////////////////////////////////////////
	class rhs_uaz_open_vdv                           { quality = 1; price = 25000; };
	class rhs_uaz_vdv                                { quality = 1; price = 25000; };
	class rhs_tigr_vdv                               { quality = 2; price = 30000; };
	class rhs_tigr_3camo_vdv                         { quality = 2; price = 30000; };
	class rhs_tigr_m_vdv                             { quality = 2; price = 30000; };
	class rhs_tigr_m_3camo_vdv                       { quality = 2; price = 30000; };
//	class rhsusf_mrzr4_d                             { quality = 1; price = 1000; };//usa
	class rhsusf_rg33_usmc_d                         { quality = 3; price = 60000; };              
	class rhsusf_rg33_usmc_wd                        { quality = 3; price = 60000; };
	class rhsusf_m998_w_2dr                          { quality = 2; price = 30000; };
	class rhsusf_m998_w_4dr                          { quality = 2; price = 30000; };
	class rhsusf_m1025_w                             { quality = 2; price = 15000; };
	class rhsusf_M1220_usarmy_d                      { quality = 2; price = 40000; };
	class rhsusf_M1220_usarmy_wd                     { quality = 2; price = 40000; };
	class rhsusf_M1230a1_usarmy_d                    { quality = 2; price = 40000; };
	class rhsusf_M1230a1_usarmy_wd                   { quality = 2; price = 40000; };
	class rhsusf_M1232_usarmy_d                      { quality = 2; price = 40000; };
	class rhsusf_M1232_usarmy_wd                     { quality = 2; price = 40000; };
	class rhsusf_CGRCAT1A2_usmc_d                    { quality = 2; price = 45000; };
	class rhsusf_CGRCAT1A2_usmc_wd                   { quality = 2; price = 45000; };
	//GREF
	//class rhsgref_BRDM2UM                            { quality = 2; price = 80000; };
	
	/////////////////////////////////////////////////////////////////////////////////
	// Вооруженный Транспорт
	/////////////////////////////////////////////////////////////////////////////////
	class rhs_tigr_sts_vdv                           { quality = 2; price = 55000; };
	class rhs_tigr_sts_3camo_vdv                     { quality = 2; price = 55000; };
	class rhsusf_CGRCAT1A2_M2_usmc_d                 { quality = 2; price = 65000; };
	class rhsusf_CGRCAT1A2_M2_usmc_wd                { quality = 2; price = 65000; };
	class rhsusf_CGRCAT1A2_Mk19_usmc_d               { quality = 2; price = 75000; };
	class rhsusf_CGRCAT1A2_Mk19_usmc_wd              { quality = 2; price = 75000; };
	
//	class rhs_gaz66_zu23_vdv                         { quality = 2; price = 75000; };
	class RHS_Ural_Zu23_VDV_01                       { quality = 5; price = 90000; };
	
	class rhs_btr60_vmf                              { quality = 5; price = 100000; };
	class rhs_btr60_vdv                              { quality = 5; price = 110000; };
	class rhs_btr60_vv                               { quality = 5; price = 110000; };
	class rhs_btr60_msv                              { quality = 5; price = 110000; };
	class rhs_btr70_vmf                              { quality = 6; price = 120000; };
	class rhs_btr70_vdv                              { quality = 6; price = 120000; };
	class rhs_btr70_vv                               { quality = 6; price = 120000; };
	class rhs_btr70_msv                              { quality = 6; price = 120000; };
	class rhs_btr80_msv                              { quality = 8; price = 125000; };
	class rhs_btr80_vdv                              { quality = 8; price = 125000; };
	class rhs_btr80_vv                               { quality = 8; price = 125000; };
	class rhs_btr80_vmf                              { quality = 8; price = 125000; };
	class rhs_btr80a_msv                             { quality = 8; price = 130000; };
	class rhs_btr80a_vdv                             { quality = 8; price = 130000; };
	class rhs_btr80a_vv                              { quality = 8; price = 130000; };
	class rhs_btr80a_vmf                             { quality = 8; price = 130000; };
	
	class rhsusf_m1025_w_m2                          { quality = 4; price = 70000; };//usa пулемет
	class rhsusf_m1025_d_s_m2                        { quality = 4; price = 70000; };//usa пулемет
	class rhsusf_m1025_w_mk19                        { quality = 5; price = 80000; };//usa гранатамет
	class rhsusf_m1025_d_s_Mk19                      { quality = 5; price = 80000; };//usa гранатамет
	class rhsusf_rg33_m2_usmc_d                      { quality = 4; price = 70000; };//usa пулемет
	class rhsusf_rg33_m2_usmc_wd                     { quality = 4; price = 70000; };//usa пулемет
	class rhsusf_M1220_M153_M2_usarmy_d              { quality = 4; price = 70000; };//usa пулемет
	class rhsusf_M1220_M153_M2_usarmy_wd             { quality = 4; price = 70000; };//usa пулемет
	class rhsusf_M1220_M2_usarmy_d                   { quality = 4; price = 70000; };//usa пулемет
	class rhsusf_M1220_M2_usarmy_wd                  { quality = 4; price = 70000; };//usa пулемет
	class rhsusf_M1220_MK19_usarmy_d                 { quality = 5; price = 80000; };//usa гранатамет
	class rhsusf_M1220_MK19_usarmy_wd                { quality = 5; price = 80000; };//usa гранатамет
	class rhsusf_M1230_M2_usarmy_d                   { quality = 4; price = 70000; };//usa пулемет
	class rhsusf_M1230_M2_usarmy_wd                  { quality = 4; price = 70000; };//usa пулемет
	class rhsusf_M1230_MK19_usarmy_d                 { quality = 5; price = 80000; };//usa гранатамет
	class rhsusf_M1230_MK19_usarmy_wd                { quality = 5; price = 80000; };//usa гранатамет
	class rhsusf_M1232_M2_usarmy_d                   { quality = 4; price = 70000; };//usa пулемет
	class rhsusf_M1232_M2_usarmy_wd                  { quality = 4; price = 70000; };//usa пулемет
	class rhsusf_M1232_MK19_usarmy_d                 { quality = 5; price = 80000; };//usa гранатамет
	class rhsusf_M1232_MK19_usarmy_wd                { quality = 5; price = 80000; };//usa гранатамет
	class rhsusf_M1237_M2_usarmy_d                   { quality = 4; price = 70000; };//usa пулемет
	class rhsusf_M1237_M2_usarmy_wd                  { quality = 4; price = 70000; };//usa пулемет
	class rhsusf_M1237_MK19_usarmy_d                 { quality = 5; price = 80000; };//usa гранатамет
	class rhsusf_M1237_MK19_usarmy_wd                { quality = 5; price = 80000; };//usa гранатамет
	class rhsusf_M1117_D                             { quality = 6; price = 150000; };
	class rhsusf_M1117_W                             { quality = 6; price = 150000; };
	class rhsusf_M1117_O                             { quality = 6; price = 150000; };
	class rhsusf_M1078A1P2_B_M2_WD_fmtv_usarmy       { quality = 4; price = 70000; };//usa пулемет
	class rhsusf_M1078A1P2_B_M2_D_flatbed_fmtv_usarmy   { quality = 4; price = 70000; };//usa пулемет
	class rhsusf_M1078A1R_SOV_M2_D_fmtv_socom        { quality = 4; price = 70000; };//usa пулемет
	class rhsusf_M1083A1P2_B_M2_WD_fmtv_usarmy       { quality = 4; price = 70000; };//usa пулемет
	class rhsusf_M1083A1P2_B_M2_D_flatbed_fmtv_usarmy   { quality = 4; price = 70000; };//usa пулемет
	class rhsusf_M1084A1P2_B_M2_WD_fmtv_usarmy       { quality = 4; price = 70000; };//usa пулемет
	class rhsusf_M1084A1P2_B_M2_D_fmtv_usarmy        { quality = 4; price = 70000; };//usa пулемет
	class rhsusf_M1084A1R_SOV_M2_D_fmtv_socom        { quality = 4; price = 70000; };//usa пулемет
	class rhsusf_M977A4_BKIT_M2_usarmy_wd            { quality = 4; price = 70000; };//usa пулемет
	class rhsusf_M977A4_BKIT_M2_usarmy_d             { quality = 4; price = 70000; };//usa пулемет
	class rhsusf_M977A4_AMMO_BKIT_M2_usarmy_wd       { quality = 4; price = 70000; };//usa пулемет
	class rhsusf_M977A4_AMMO_BKIT_M2_usarmy_d        { quality = 4; price = 70000; };//usa пулемет
	
	///////////////////////////////////////////////////////////////////////////////
	// Грузовики
	///////////////////////////////////////////////////////////////////////////////
	class RHS_Ural_Open_VDV_01                      { quality = 1; price = 50000; };
	class RHS_Ural_VDV_01                           { quality = 1; price = 50000; };
	class RHS_Ural_Repair_VDV_01                    { quality = 1; price = 50000; };
	class RHS_Ural_Fuel_VDV_01                      { quality = 1; price = 50000; };
	class rhs_typhoon_vdv                           { quality = 1; price = 50000; };
	class rhs_gaz66_r142_vdv                        { quality = 1; price = 50000; };
	class rhs_gaz66_ap2_vdv                         { quality = 1; price = 50000; };
	class rhs_gaz66_vdv                             { quality = 1; price = 50000; };
	class rhs_gaz66_ammo_vdv                        { quality = 1; price = 50000; };
	class rhs_gaz66_repair_vdv                      { quality = 1; price = 50000; };
	class rhs_kamaz5350_vdv                         { quality = 1; price = 50000; };
	//usa
	class rhsusf_M1078A1P2_WD_fmtv_usarmy           { quality = 1; price = 50000; };                                 
	class rhsusf_M1078A1P2_D_flatbed_fmtv_usarmy    { quality = 1; price = 50000; };
	class rhsusf_M1078A1P2_B_WD_fmtv_usarmy         { quality = 1; price = 50000; };
	class rhsusf_M1078A1P2_B_D_flatbed_fmtv_usarmy  { quality = 1; price = 50000; };
	class rhsusf_M1078A1P2_B_WD_CP_fmtv_usarmy      { quality = 1; price = 50000; };
	class rhsusf_M1078A1P2_B_D_CP_fmtv_usarmy       { quality = 1; price = 50000; };
	class rhsusf_M1083A1P2_WD_fmtv_usarmy           { quality = 1; price = 50000; };
	class rhsusf_M1083A1P2_D_flatbed_fmtv_usarmy    { quality = 1; price = 50000; };
	class rhsusf_M1083A1P2_B_WD_fmtv_usarmy         { quality = 1; price = 50000; };
	class rhsusf_M1083A1P2_B_D_flatbed_fmtv_usarmy  { quality = 1; price = 50000; };
	class rhsusf_M1084A1P2_WD_fmtv_usarmy           { quality = 1; price = 50000; };
	class rhsusf_M1084A1P2_D_fmtv_usarmy            { quality = 1; price = 50000; };
	class rhsusf_M1084A1P2_B_WD_fmtv_usarmy         { quality = 1; price = 50000; };
	class rhsusf_M1084A1P2_B_D_fmtv_usarmy          { quality = 1; price = 50000; };
	class rhsusf_M1085A1P2_B_WD_Medical_fmtv_usarmy { quality = 1; price = 50000; };
	class rhsusf_M1085A1P2_B_D_Medical_fmtv_usarmy  { quality = 1; price = 50000; };
	class rhsusf_M977A4_usarmy_wd                   { quality = 1; price = 50000; };
	class rhsusf_M977A4_usarmy_d                    { quality = 1; price = 50000; };
	class rhsusf_M977A4_BKIT_usarmy_wd              { quality = 1; price = 50000; };
	class rhsusf_M977A4_BKIT_usarmy_d               { quality = 1; price = 50000; };
	class rhsusf_M977A4_REPAIR_BKIT_M2_usarmy_wd    { quality = 1; price = 50000; };
	class rhsusf_M977A4_REPAIR_BKIT_M2_usarmy_d     { quality = 1; price = 50000; };
	class rhsusf_M977A4_REPAIR_BKIT_usarmy_wd       { quality = 1; price = 50000; };
	class rhsusf_M977A4_REPAIR_BKIT_usarmy_d        { quality = 1; price = 50000; };
	class rhsusf_M977A4_REPAIR_usarmy_wd            { quality = 1; price = 50000; };
	class rhsusf_M977A4_REPAIR_usarmy_d             { quality = 1; price = 50000; };
	class rhsusf_M977A4_AMMO_BKIT_usarmy_wd         { quality = 1; price = 50000; };
	class rhsusf_M977A4_AMMO_BKIT_usarmy_d          { quality = 1; price = 50000; };
	class rhsusf_M977A4_AMMO_usarmy_wd              { quality = 1; price = 50000; };
	class rhsusf_M977A4_AMMO_usarmy_d               { quality = 1; price = 50000; };
	class rhsusf_M978A4_usarmy_wd                   { quality = 1; price = 50000; };
	class rhsusf_M978A4_usarmy_d                    { quality = 1; price = 50000; };
	class rhsusf_M978A4_BKIT_usarmy_wd              { quality = 1; price = 50000; };
	class rhsusf_M978A4_BKIT_usarmy_d               { quality = 1; price = 50000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Гусеничная техника
	///////////////////////////////////////////////////////////////////////////////
	class rhs_pts_vmf                               { quality = 2; price = 70000; };//не воруженые
	class rhsusf_m113_usarmy_medical                { quality = 2; price = 70000; };//не воруженые
	class rhsusf_m113d_usarmy_medical               { quality = 2; price = 70000; };//не воруженые
	class rhs_bmd1                                  { quality = 4; price = 80000; };
	class rhs_bmd1k                                 { quality = 4; price = 80000; };
	class rhs_bmd1p                                 { quality = 4; price = 80000; };
	class rhs_bmd1pk                                { quality = 4; price = 80000; };
	class rhs_bmd1r                                 { quality = 4; price = 90000; };
	class rhs_bmd2                                  { quality = 4; price = 100000; };
	class rhs_bmd2k                                 { quality = 4; price = 100000; };
	class rhs_bmd2m                                 { quality = 4; price = 100000; };
	class rhs_bmd4_vdv                              { quality = 5; price = 110000; };
	class rhs_bmd4m_vdv                             { quality = 5; price = 110000; };
	class rhs_bmd4ma_vdv                            { quality = 5; price = 110000; };
	class rhs_bmp1_vdv                              { quality = 4; price = 90000; };
	class rhs_bmp1d_vdv                             { quality = 4; price = 90000; };
	class rhs_bmp1k_vdv                             { quality = 4; price = 90000; };
	class rhs_bmp1p_vdv                             { quality = 4; price = 90000; };
	class rhs_bmp2e_vdv                             { quality = 4; price = 100000; };
	class rhs_bmp2_vdv                              { quality = 4; price = 100000; };
	class rhs_bmp2d_vdv                             { quality = 4; price = 100000; };
	class rhs_bmp2k_vdv                             { quality = 4; price = 100000; };
	class rhs_bmp3_msv                              { quality = 5; price = 110000; };
	class rhs_bmp3m_msv                             { quality = 5; price = 110000; };
	class rhs_bmp3mera_msv                          { quality = 5; price = 110000; };
	class rhs_bmp3_late_msv                         { quality = 5; price = 110000; };
	class rhs_brm1k_vdv                             { quality = 4; price = 90000; };
	class rhs_Ob_681_2                              { quality = 4; price = 95000; };
	class rhs_sprut_vdv                             { quality = 6; price = 95000; };
	class rhs_zsu234_aa                             { quality = 6; price = 90000; };
	class rhsusf_m113_usarmy_M2_90                  { quality = 4; price = 92000; };//usa пулемет
	class rhsusf_m113_usarmy_MK19_90                { quality = 5; price = 96000; };//usa гранатамет
	class rhsusf_m113_usarmy_supply                 { quality = 4; price = 92000; };
	class rhsusf_m113d_usarmy_supply                { quality = 4; price = 92000; };
	class rhsusf_m113_usarmy                        { quality = 4; price = 92000; };
	class rhsusf_m113d_usarmy                       { quality = 4; price = 92000; };
	class rhsusf_m113_usarmy_M240                   { quality = 4; price = 90000; };
	class rhsusf_m113d_usarmy_M240                  { quality = 4; price = 90000; };
	class rhsusf_m113_usarmy_MK19                   { quality = 5; price = 96000; };
	class rhsusf_m113d_usarmy_MK19                  { quality = 5; price = 96000; };
	class RHS_M2A2                                  { quality = 6; price = 120000; };
	class RHS_M6_wd                                 { quality = 6; price = 120000; };
	class RHS_M2A2_BUSKI                            { quality = 6; price = 120000; };
	class RHS_M2A2_BUSKI_WD                         { quality = 6; price = 120000; };
	class RHS_M2A3                                  { quality = 6; price = 120000; };
	class RHS_M2A3_wd                               { quality = 6; price = 120000; };
	class RHS_M2A3_BUSKI                            { quality = 6; price = 120000; };
	class RHS_M2A3_BUSKI_wd                         { quality = 6; price = 120000; };
	class RHS_M2A3_BUSKIII                          { quality = 6; price = 120000; };
	class RHS_M2A3_BUSKIII_wd                       { quality = 6; price = 120000; };
	
	class rhs_t72ba_tv                              { quality = 9; price = 300000; };
	class rhs_t72bb_tv                              { quality = 9; price = 300000; };
	class rhs_t72bc_tv                              { quality = 9; price = 300000; };
	class rhs_t72bd_tv                              { quality = 9; price = 300000; };
	class rhs_t80                                   { quality = 10; price = 350000; };
	class rhs_t80a                                  { quality = 10; price = 350000; };
	class rhs_t80b                                  { quality = 10; price = 350000; };
	class rhs_t80bk                                 { quality = 10; price = 350000; };
	class rhs_t80bv                                 { quality = 10; price = 350000; };
	class rhs_t80bvk                                { quality = 10; price = 350000; };
	class rhs_t80u                                  { quality = 10; price = 350000; };
	class rhs_t80u45m                               { quality = 10; price = 350000; };
	class rhs_t80ue1                                { quality = 10; price = 350000; };
	class rhs_t80um                                 { quality = 10; price = 350000; };
	class rhs_t80uk                                 { quality = 10; price = 350000; };
	class rhs_t90_tv                                { quality = 10; price = 350000; };
	class rhs_t90a_tv                               { quality = 10; price = 350000; };
	class rhsusf_m1a1fep_d                          { quality = 10; price = 350000; };
	class rhsusf_m1a1fep_wd                         { quality = 10; price = 350000; };
	class rhsusf_m1a1fep_od                         { quality = 10; price = 350000; };
	class rhsusf_m1a1hc_wd                          { quality = 10; price = 350000; }; 
	class rhsusf_m1a1aimwd_usarmy                   { quality = 10; price = 350000; };
	class rhsusf_m1a1aimd_usarmy                    { quality = 10; price = 350000; };
	class rhsusf_m1a1aim_tuski_wd                   { quality = 10; price = 350000; };
	class rhsusf_m1a1aim_tuski_d                    { quality = 10; price = 350000; };
	class rhsusf_m1a2sep1d_usarmy                   { quality = 10; price = 350000; };
	class rhsusf_m1a2sep1wd_usarmy                  { quality = 10; price = 350000; };
	class rhsusf_m1a2sep1tuskid_usarmy              { quality = 10; price = 350000; };
	class rhsusf_m1a2sep1tuskiwd_usarmy             { quality = 10; price = 350000; };
	class rhsusf_m1a2sep1tuskiiwd_usarmy            { quality = 10; price = 350000; };
	class rhsusf_m1a2sep1tuskiid_usarmy             { quality = 10; price = 350000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Вертолёты
	///////////////////////////////////////////////////////////////////////////////
	class rhs_ka60_grey                             { quality = 1; price = 50000; };
	class RHS_Mi8AMT_vvs                            { quality = 2; price = 60000; };
	class RHS_Mi8AMT_vvsc                           { quality = 2; price = 60000; };
	class RHS_Mi8AMT_vdv                            { quality = 2; price = 60000; };
	class RHS_Mi8amt_civilian                       { quality = 2; price = 60000; };
	class RHS_MELB_H6M                              { quality = 2; price = 30000; };
	class RHS_UH60M_MEV                             { quality = 2; price = 60000; };
	class RHS_UH60M_MEV2_d                          { quality = 2; price = 60000; };
	class RHS_UH60M2_d                              { quality = 2; price = 60000; };
	class RHS_UH60M_ESSS2_d                         { quality = 2; price = 60000; };
	class rhsusf_CH53E_USMC                         { quality = 4; price = 70000; };
	class rhsusf_CH53E_USMC_D                       { quality = 4; price = 70000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Вооруженные Вертолёты
	///////////////////////////////////////////////////////////////////////////////
	class RHS_Mi8mt_vdv                             { quality = 4; price = 80000; };
	class RHS_Mi8mt_Cargo_vdv                       { quality = 4; price = 80000; };
	class RHS_Mi8MTV3_vdv                           { quality = 4; price = 85000; };
	class RHS_Mi8mtv3_Cargo_vdv                     { quality = 4; price = 85000; };
	class RHS_Mi8AMTSh_vvs                          { quality = 7; price = 150000; };
	class RHS_Mi8AMTSh_vvsc                         { quality = 7; price = 150000; };
	class RHS_Mi24Vt_vvs                            { quality = 7; price = 200000; };
	class RHS_Mi24Vt_vvsc                           { quality = 7; price = 200000; };
	class RHS_Mi24P_vvs                             { quality = 7; price = 200000; };
	class RHS_Mi24P_vvsc                            { quality = 7; price = 200000; };
	class RHS_Mi24P_vdv                             { quality = 7; price = 200000; };
	class RHS_Mi24V_vvs                             { quality = 7; price = 200000; };
	class RHS_Mi24V_vvsc                            { quality = 7; price = 200000; };
	class RHS_Mi24V_vdv                             { quality = 7; price = 200000; };
	class rhs_mi28n_vvs                             { quality = 8; price = 210000; };
	class rhs_mi28n_vvsc                            { quality = 8; price = 210000; };
	class RHS_Ka52_vvsc                             { quality = 8; price = 220000; };
	class RHS_Ka52_vvs                              { quality = 8; price = 220000; };
	class RHS_UH60M                                 { quality = 4; price = 85000; };//usa
	class RHS_UH60M_d                               { quality = 4; price = 85000; };
	class RHS_UH1Y_d                                { quality = 5; price = 120000; };
	class RHS_UH1Y_UNARMED_d                        { quality = 5; price = 120000; };
	class RHS_AH64D                                 { quality = 9; price = 350000; };
	class RHS_AH64D_wd                              { quality = 9; price = 350000; };
	class RHS_AH64DGrey                             { quality = 9; price = 350000; };
	class RHS_AH1Z                                  { quality = 9; price = 345000; };
	class RHS_AH1Z_wd                               { quality = 9; price = 345000; };
	
	//GREF
	//class rhs_uh1h_hidf                             { quality = 3; price = 100000; };
	//class rhs_uh1h_hidf_gunship                     { quality = 6; price = 250000; };
	//class rhsgref_mi24g_CAS                         { quality = 6; price = 350000; };
	//class rhsgref_b_mi24g_CAS                       { quality = 6; price = 350000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Вооруженные Самолёты
	///////////////////////////////////////////////////////////////////////////////
	class RHS_Su25SM_vvs                            { quality = 10; price = 300000; };
	class RHS_Su25SM_vvsc                           { quality = 10; price = 300000; };
	class RHS_T50_vvs_generic                       { quality = 10; price = 300000; };
	class RHS_T50_vvs_generic_ext                   { quality = 10; price = 300000; };
	class RHS_T50_vvs_051                           { quality = 10; price = 300000; };
	class RHS_T50_vvs_052                           { quality = 10; price = 300000; };
	class RHS_T50_vvs_053                           { quality = 10; price = 300000; };
	class RHS_T50_vvs_054                           { quality = 10; price = 300000; };
	class RHS_T50_vvs_blueonblue                    { quality = 10; price = 300000; };
	class rhsusf_f22                                { quality = 10; price = 300000; };//usa
	class RHS_A10                                   { quality = 10; price = 300000; };//usa
	
	//GREF
	//class rhs_l159_CDF                              { quality = 9; price = 500000; };
	//class rhs_l159_cdf_b_CDF                        { quality = 9; price = 500000; };
	//class rhs_l39_cdf                               { quality = 9; price = 500000; };
	//class rhs_l39_cdf_b_cdf                         { quality = 9; price = 500000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Лодки
	///////////////////////////////////////////////////////////////////////////////
	class rhsusf_mkvsoc                    { quality = 4; price = 70000; };
	
	//GREF
	//class rhsgref_hidf_canoe               { quality = 1; price = 5000; };
	//class rhsgref_civ_canoe                { quality = 1; price = 5000; };