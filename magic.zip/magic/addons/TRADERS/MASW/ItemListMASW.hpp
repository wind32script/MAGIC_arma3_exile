    ///////////////////////////////////////////////////////////////////////////////
	// Защита лица
	///////////////////////////////////////////////////////////////////////////////
	class G_mas_wpn_bala 						{ quality = 1; price = 10; };
	class G_mas_wpn_bala_gog 					{ quality = 1; price = 10; };
	class G_mas_wpn_bala_gog_b 					{ quality = 1; price = 10; };
	class G_mas_wpn_bala_gog_t 					{ quality = 1; price = 10; };
	class G_mas_wpn_bala_mask 					{ quality = 1; price = 10; };
	class G_mas_wpn_bala_mask_b 				{ quality = 1; price = 10; };
	class G_mas_wpn_bala_mask_t 				{ quality = 1; price = 10; };
	class G_mas_wpn_bala_b 					    { quality = 1; price = 10; };
	class G_mas_wpn_bala_t 						{ quality = 1; price = 10; };
	class G_mas_wpn_gasmask					    { quality = 5; price = 300; };
	class G_mas_wpn_gasmask_comp 				{ quality = 5; price = 300; };
	class G_mas_wpn_shemag 						{ quality = 1; price = 10; };
	class G_mas_wpn_shemag_gog 					{ quality = 1; price = 10; };
	class G_mas_wpn_shemag_mask 				{ quality = 1; price = 10; };
	class G_mas_wpn_gog 					    { quality = 1; price = 10; };
	class G_mas_wpn_gog_d 						{ quality = 1; price = 10; };
	class G_mas_wpn_gog_m 					    { quality = 1; price = 10; };
	class G_mas_wpn_gog_gd 						{ quality = 1; price = 10; };
	class G_mas_wpn_mask_b					    { quality = 1; price = 10; };
	class G_mas_wpn_mask 					    { quality = 1; price = 10; };
	class G_mas_wpn_wrap_b 						{ quality = 1; price = 10; };
	class G_mas_wpn_wrap_f 						{ quality = 1; price = 10; };
	class G_mas_wpn_wrap_gog_b 					{ quality = 1; price = 10; };
	class G_mas_wpn_wrap_gog_f					{ quality = 1; price = 10; };
	class G_mas_wpn_wrap_gog_g 					{ quality = 1; price = 10; };
	class G_mas_wpn_wrap_gog 					{ quality = 1; price = 10; };
	class G_mas_wpn_wrap_gog_c 					{ quality = 1; price = 10; };
	class G_mas_wpn_wrap_gog_t					{ quality = 1; price = 10; };
	class G_mas_wpn_wrap_mask_b 				{ quality = 1; price = 10; };
	class G_mas_wpn_wrap_mask_f 				{ quality = 1; price = 10; };
	class G_mas_wpn_wrap_mask_g 				{ quality = 1; price = 10; };
	class G_mas_wpn_wrap_mask 					{ quality = 1; price = 10; };
	class G_mas_wpn_wrap_mask_c 				{ quality = 1; price = 10; };
	class G_mas_wpn_wrap_mask_t 				{ quality = 1; price = 10; };
	class G_mas_wpn_wrap 					    { quality = 1; price = 10; };
	class G_mas_wpn_wrap_c 					    { quality = 1; price = 10; };
	class G_mas_wpn_wrap_t					    { quality = 1; price = 10; };

	///////////////////////////////////////////////////////////////////////////////
	// Рюкзаки
	///////////////////////////////////////////////////////////////////////////////
	class B_mas_m_Bergen_acr_w						{ quality = 3; price = 500; };
	class B_mas_m_Bergen_acr_g						{ quality = 3; price = 500; };
	class B_mas_m_Bergen_acr						{ quality = 3; price = 500; };
	class B_mas_m_Bergen_acr_c						{ quality = 3; price = 500; };
	
    ///////////////////////////////////////////////////////////////////////////////
	// Вспомогательное
	///////////////////////////////////////////////////////////////////////////////
	class acc_mas_pointer_IR_b						{ quality = 2; price = 200; };
	class acc_mas_pointer_IR_top_b					{ quality = 2; price = 200; };
	class acc_mas_pointer_IR						{ quality = 3; price = 200; };
	class acc_mas_pointer_IR_top                    { quality = 3; price = 200; };
	class acc_mas_pointer_IR2c                      { quality = 3; price = 200; };
	class acc_mas_pointer_IR2c_top                  { quality = 3; price = 200; };
	class acc_mas_pointer_IR2                       { quality = 3; price = 200; };
	class acc_mas_pointer_IR2_top                   { quality = 3; price = 200; };
	class acc_mas_flash_gun                         { quality = 1; price = 80; };
	class acc_mas_pointer_gun_IR                    { quality = 1; price = 80; };

	///////////////////////////////////////////////////////////////////////////////////
	// Глушители
	///////////////////////////////////////////////////////////////////////////////////
	class muzzle_mas_snds_AK			   { quality = 1; price = 75; sellPrice = 5; };
	class muzzle_mas_snds_M				   { quality = 1; price = 75; sellPrice = 5; };
	class muzzle_mas_snds_Mc			   { quality = 1; price = 75; sellPrice = 5; };
	class muzzle_mas_snds_SM			   { quality = 1; price = 75; sellPrice = 5; };
	class muzzle_mas_snds_SMc			   { quality = 1; price = 75; sellPrice = 5; };
	class muzzle_mas_snds_asval			   { quality = 1; price = 75; sellPrice = 5; };
	class muzzle_mas_snds_KSVK			   { quality = 1; price = 75; sellPrice = 5; };
	class muzzle_mas_snds_SV			   { quality = 1; price = 75; sellPrice = 5; };
	class muzzle_mas_snds_SVc			   { quality = 1; price = 75; sellPrice = 5; };
	class muzzle_mas_snds_MP7			   { quality = 1; price = 75; sellPrice = 5; };
	class muzzle_mas_snds_L				   { quality = 1; price = 75; sellPrice = 5; };
	class muzzle_mas_snds_LM			   { quality = 1; price = 75; sellPrice = 5; };
	class muzzle_mas_snds_C				   { quality = 1; price = 75; sellPrice = 5; };
	class muzzle_mas_snds_SVD			   { quality = 1; price = 75; sellPrice = 5; };

	///////////////////////////////////////////////////////////////////////////////
	// Оптика
	///////////////////////////////////////////////////////////////////////////////
	class optic_mas_ACO_grn_camo					 { quality = 1; price = 60; };
	class optic_mas_acog						     { quality = 2; price = 200; };
	//class optic_mas_acog_rd						 { quality = 2; price = 200; };
	//class optic_mas_acog_c						 { quality = 2; price = 200; };
	class optic_mas_acog_eo						     { quality = 2; price = 200; };
	//class optic_mas_acog_rd_c						 { quality = 2; price = 200; };
	//class optic_mas_acog_eo_c						 { quality = 2; price = 200; };
	class optic_mas_aim						         { quality = 1; price = 100; };
	class optic_mas_Arco_blk						 { quality = 2; price = 200; };
	class optic_mas_term						     { quality = 3; price = 300; };
	class optic_mas_DMS						         { quality = 3; price = 400; };
	class optic_mas_LRPS							 { quality = 3; price = 400; };
	class optic_mas_MRCO_camo						 { quality = 2; price = 200; };
	class optic_mas_Hamr_camo						 { quality = 2; price = 200; };
	class optic_mas_zeiss							 { quality = 3; price = 400; };
	class optic_mas_goshawk						     { quality = 4; price = 600; };
	class optic_mas_kobra							 { quality = 1; price = 60; };
	class optic_mas_PSO_kv							 { quality = 4; price = 500; };
	class optic_mas_nspu					         { quality = 4; price = 550; };
	class optic_mas_PSO						         { quality = 1; price = 200; };
	class optic_mas_MRD						         { quality = 1; price = 60; };

	///////////////////////////////////////////////////////////////////////////////
	// Пистолеты
	///////////////////////////////////////////////////////////////////////////////
	class hgun_mas_acp_F 							{ quality = 2; price = 500; };
	class hgun_mas_bhp_F 							{ quality = 2; price = 500; };
	class hgun_mas_glock_F 							{ quality = 2; price = 500; };
	class hgun_mas_glocksf_F 						{ quality = 2; price = 500; };
	class hgun_mas_m23_F 							{ quality = 2; price = 500; };
	class hgun_mas_usp_F 							{ quality = 2; price = 500; };
	class hgun_mas_m9_F 							{ quality = 2; price = 500; };
	class hgun_mas_mak_F 							{ quality = 1; price = 300; };
	class hgun_mas_grach_F 							{ quality = 2; price = 500; };
	class hgun_mas_p226_F 							{ quality = 2; price = 500; };

	///////////////////////////////////////////////////////////////////////////////
	// Пист.пулемёты,дробовики
	///////////////////////////////////////////////////////////////////////////////
	class arifle_mas_aa12 							{ quality = 1; price = 1050; };
	class arifle_mas_m1014 						    { quality = 1; price = 1050; };
	class arifle_mas_bizon 							{ quality = 2; price = 2000; };
	class arifle_mas_mp5 							{ quality = 2; price = 3000; };
	class arifle_mas_mp5_d 							{ quality = 2; price = 3000; };
	class arifle_mas_mp5_v 							{ quality = 2; price = 3000; };
	class arifle_mas_mp5sd 							{ quality = 2; price = 3000; };
	class arifle_mas_mp5sd_ds 						{ quality = 2; price = 3000; };
	class hgun_mas_mp7_F 							{ quality = 2; price = 1500; };
	class hgun_mas_uzi_F 						    { quality = 2; price = 1000; };
	class hgun_mas_mp7p_F 							{ quality = 2; price = 1000; };
	class hgun_mas_sa61_F 							{ quality = 2; price = 1000; };

	///////////////////////////////////////////////////////////////////////////////
	// Пулемёты
	///////////////////////////////////////////////////////////////////////////////
	class LMG_mas_m240_F							{ quality = 5; price = 10000; };
	class LMG_mas_M249a_F							{ quality = 5; price = 10000; };
	class LMG_mas_M249_F							{ quality = 5; price = 10000; };
	class LMG_mas_M249_F_d							{ quality = 5; price = 10000; };
	class LMG_mas_m60_F							    { quality = 5; price = 10000; };
	class LMG_mas_mg3_F							    { quality = 5; price = 10000; };
	class LMG_mas_mk48_F							{ quality = 5; price = 10000; };
	class LMG_mas_mk48_F_d							{ quality = 3; price = 500; };
	class LMG_mas_mk48_F_v							{ quality = 3; price = 500; };
	class LMG_mas_pkm_F							    { quality = 3; price = 500; };
	class LMG_mas_pech_F							{ quality = 3; price = 500; };
	class LMG_mas_Mk200_F							{ quality = 3; price = 450; };

	///////////////////////////////////////////////////////////////////////////////
	// Автоматы
	///////////////////////////////////////////////////////////////////////////////
	class arifle_mas_m70                            { quality = 2; price = 5000; };
	class arifle_mas_m70_gl                         { quality = 2; price = 5500; };
	class arifle_mas_asval                          { quality = 2; price = 5000; };
	class arifle_mas_asval_ds                       { quality = 2; price = 5000; };
	class arifle_mas_ak12_sf						{ quality = 3; price = 5000; };
	class arifle_mas_ak12_sf_gl						{ quality = 3; price = 6000; };
	class arifle_mas_ak_74m						    { quality = 3; price = 5000; };
	class arifle_mas_ak_74m_gl_c				    { quality = 3; price = 6000; };
	class arifle_mas_ak_74m_sf						{ quality = 3; price = 5000; };
	class arifle_mas_ak_74m_sf_gl_c					{ quality = 3; price = 6000; };
	class arifle_mas_ak_74m_train					{ quality = 3; price = 5000; };
	class arifle_mas_arx_l						    { quality = 4; price = 6500; };
	class arifle_mas_arx_l_gl					    { quality = 4; price = 7000; };
	class arifle_mas_arx							{ quality = 4; price = 6500; };
	class arifle_mas_arx_gl					        { quality = 4; price = 7000; };
	class arifle_mas_fal						    { quality = 4; price = 6500; };
	class arifle_mas_fal_m203					    { quality = 4; price = 7000; };
	class arifle_mas_g36c						    { quality = 4; price = 6500; };
	class arifle_mas_g3					            { quality = 4; price = 6500; };
	class arifle_mas_g3_m203					    { quality = 4; price = 7000; };
	class arifle_mas_hk416							{ quality = 4; price = 6500; };
	class arifle_mas_hk416_gl						{ quality = 4; price = 7000; };
	class arifle_mas_hk416_gl_d						{ quality = 4; price = 7000; };
	class arifle_mas_hk416_gl_v						{ quality = 4; price = 6500; };
	class arifle_mas_hk416c_d						{ quality = 4; price = 6500; };
	class srifle_mas_hk417							{ quality = 4; price = 6500; };
	class arifle_mas_hk417c						    { quality = 4; price = 6500; };
	class arifle_mas_hk417c_d						{ quality = 4; price = 6500; };
	class arifle_mas_hk417_m203c					{ quality = 4; price = 7000; };
	class arifle_mas_hk417_m203c_d					{ quality = 4; price = 7000; };
	class srifle_mas_hk417_d						{ quality = 4; price = 6500; };
	class srifle_mas_hk417_v						{ quality = 4; price = 6500; };
	class arifle_mas_l119						    { quality = 4; price = 6500; };
	class arifle_mas_l119c_d						{ quality = 4; price = 6500; };
	class arifle_mas_l119_m203_d					{ quality = 4; price = 7000; };
	class srifle_mas_ebr							{ quality = 4; price = 6500; };
	class arifle_mas_m16a2							{ quality = 4; price = 6500; };
	class arifle_mas_m16a2_gl						{ quality = 4; price = 7500; };
	class arifle_mas_m27							{ quality = 4; price = 6500; };
	class arifle_mas_m27_d						    { quality = 4; price = 6500; };
	class arifle_mas_m27m						    { quality = 4; price = 6500; };
	class arifle_mas_m4vlt							{ quality = 4; price = 6500; };
	class arifle_mas_m4						        { quality = 4; price = 6500; };
	class arifle_mas_m4_gl						    { quality = 4; price = 7500; };
	class arifle_mas_mk17					        { quality = 4; price = 6500; };
	class arifle_mas_mk17_gl						{ quality = 4; price = 7500; };
	class srifle_mas_sr25						    { quality = 4; price = 6500; };
	class srifle_mas_sr25_d						    { quality = 4; price = 6500; };
	class srifle_mas_sr25_v					        { quality = 4; price = 6500; };

	///////////////////////////////////////////////////////////////////////////////
	// Снайперские винтовки
	///////////////////////////////////////////////////////////////////////////////
	class srifle_mas_m91                        { quality = 3; price = 7000; };
	class srifle_mas_vss                        { quality = 3; price = 8000; };
	class srifle_mas_svd                        { quality = 3; price = 8000; };
	class arifle_mas_lee                        { quality = 3; price = 8000; };
	class srifle_mas_ksvk 						{ quality = 5; price = 17000; };
	class srifle_mas_ksvk_c					    { quality = 5; price = 17000; };
	class srifle_mas_lrr						{ quality = 4; price = 16000; };
	class srifle_mas_m107					    { quality = 5; price = 17000; };
	class srifle_mas_m107_d						{ quality = 5; price = 17000; };
	class srifle_mas_m107_v					    { quality = 5; price = 17000; };
	class srifle_mas_m109                       { quality = 6; price = 17000; };
	class srifle_mas_m110						{ quality = 4; price = 16000; };
	class srifle_mas_m24						{ quality = 4; price = 16000; };
	class srifle_mas_m24_d						{ quality = 4; price = 16000; };
	class srifle_mas_m24_v						{ quality = 4; price = 16000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Патроны
	///////////////////////////////////////////////////////////////////////////////
	class 20Rnd_mas_12Gauge_Slug                       { quality = 1; price = 55; };
	class 20Rnd_mas_12Gauge_Pellets                    { quality = 1; price = 55; };
	class 20Rnd_mas_12Gauge_Demo                       { quality = 1; price = 55; };
	class 30Rnd_mas_545x39_mag                         { quality = 2; price = 80; };
	class 30Rnd_mas_545x39bk_mag                       { quality = 2; price = 80; };
	class 30Rnd_mas_545x39sd_mag                       { quality = 2; price = 80; };
	class 30Rnd_mas_545x39_T_mag                       { quality = 2; price = 80; };
	class 30Rnd_mas_556x45_Stanag                      { quality = 3; price = 80; };
	class 30Rnd_mas_556x45sd_Stanag                    { quality = 3; price = 80; };
	class 30Rnd_mas_556x45_T_Stanag                    { quality = 3; price = 80; };
	class 30Rnd_mas_9x39_mag                           { quality = 1; price = 70; };
	class 30Rnd_mas_9x39sd_mag                         { quality = 1; price = 70; };
	class 20Rnd_mas_9x39_mag                           { quality = 1; price = 90; };
	class 20Rnd_mas_9x39sd_mag                         { quality = 1; price = 90; };
	class 7Rnd_mas_12Gauge_Slug                        { quality = 1; price = 55; };
	class 7Rnd_mas_12Gauge_Pellets                     { quality = 1; price = 55; };
	class 64Rnd_mas_9x18_mag                           { quality = 2; price = 60; };
	class 64Rnd_mas_9x18sd_mag                         { quality = 2; price = 60; };
	class 20Rnd_mas_762x51_Stanag                      { quality = 3; price = 80; };
	class 20Rnd_mas_762x51sd_Stanag                    { quality = 3; price = 80; };
	class 20Rnd_mas_762x51_T_Stanag                    { quality = 3; price = 80; };
	class 5Rnd_mas_127x108_mag                         { quality = 6; price = 155; };//ksvk Снайперские
	class 5Rnd_mas_127x108_T_mag                       { quality = 6; price = 155; };//ksvk Снайперские
	class 5Rnd_mas_127x108_dem_mag                     { quality = 6; price = 200; };//ksvk Снайперские
	class 5Rnd_mas_762x51_Stanag                       { quality = 3; price = 90; };//Снайперские
	class 5Rnd_mas_762x51_T_Stanag                     { quality = 3; price = 90; };//Снайперские
	class 10Rnd_mas_338_Stanag                         { quality = 3; price = 90; };//Снайперские
	class 10Rnd_mas_338sd_Stanag                       { quality = 3; price = 90; };//Снайперские
	class 10Rnd_mas_338_T_Stanag                       { quality = 3; price = 90; };//Снайперские
	class 5Rnd_mas_127x99_Stanag                       { quality = 6; price = 155; };//m107 Снайперские
	class 5Rnd_mas_127x99_T_Stanag                     { quality = 6; price = 200; };//m107 Снайперские
	class 5Rnd_mas_127x99_dem_Stanag                   { quality = 6; price = 200; };//m107 Снайперские
	class 100Rnd_mas_762x51_Stanag                     { quality = 3; price = 150; };//Пулемёты
	class 100Rnd_mas_762x51_T_Stanag                   { quality = 3; price = 150; };//Пулемёты
	class 200Rnd_mas_556x45_Stanag                     { quality = 3; price = 200; };//Пулемёты
	class 200Rnd_mas_556x45_T_Stanag                   { quality = 3; price = 200; };//Пулемёты
	class 150Rnd_mas_556x45_Stanag                     { quality = 3; price = 160; };
	class 150Rnd_mas_556x45_T_Stanag                   { quality = 3; price = 160; };
	class 30Rnd_mas_9x21_Stanag                        { quality = 2; price = 80; };//Пист.пулемёты
	class 30Rnd_mas_9x21sd_Stanag                      { quality = 2; price = 80; };//Пист.пулемёты
	class 40Rnd_mas_46x30_Mag                          { quality = 2; price = 80; };//Пист.пулемёты
	class 40Rnd_mas_46x30sd_Mag                        { quality = 2; price = 80; };//Пист.пулемёты
	class 100Rnd_mas_762x54_mag                        { quality = 3; price = 150; };//Пулемёты
	class 100Rnd_mas_762x54_T_mag                      { quality = 3; price = 150; };//Пулемёты
	class 10Rnd_mas_762x54sd_mag                       { quality = 3; price = 90; };//Снайперские
	class 10Rnd_mas_762x54_mag                         { quality = 3; price = 90; };//Снайперские
	class 10Rnd_mas_762x54_T_mag                       { quality = 3; price = 90; };//Снайперские
	class 5Rnd_mas_25x59_Stanag                        { quality = 6; price = 200; };//m109 Снайперские
	class 30Rnd_mas_762x39_mag                         { quality = 2; price = 80; };
	class 30Rnd_mas_762x39sd_mag                       { quality = 2; price = 80; };
	class 30Rnd_mas_762x39_T_mag                       { quality = 2; price = 80; };
	class 12Rnd_mas_45acp_Mag                          { quality = 1; price = 35; };//пистолеты
	class 10Rnd_mas_45acp_Mag                          { quality = 1; price = 35; };//пистолеты
	class 8Rnd_mas_45acp_Mag                           { quality = 1; price = 35; };//пистолеты
	class 12Rnd_mas_45acpsd_Mag                        { quality = 1; price = 35; };//пистолеты
	class 15Rnd_mas_9x21_Mag                           { quality = 1; price = 35; };//пистолеты
	class 17Rnd_mas_9x21_Mag                           { quality = 1; price = 35; };//пистолеты
	class 13Rnd_mas_9x21_Mag                           { quality = 1; price = 35; };//пистолеты
	class 15Rnd_mas_9x21sd_Mag                         { quality = 1; price = 35; };//пистолеты
	class 8Rnd_mas_9x18_Mag                            { quality = 1; price = 35; };//пистолеты
	class 8Rnd_mas_9x18sd_Mag                          { quality = 1; price = 35; };//пистолеты
	class 25Rnd_mas_9x19_Mag                           { quality = 1; price = 35; };//пистолеты
	class 20Rnd_mas_765x17_Mag                         { quality = 1; price = 35; };//пистолеты

	///////////////////////////////////////////////////////////////////////////////
	// Гранатометы
	///////////////////////////////////////////////////////////////////////////////
	class mas_launch_RPG7_F 						{ quality = 8; price = 7000; };
	class mas_launch_Strela_F 						{ quality = 9; price = 8000; };
	class mas_launch_Stinger_F 						{ quality = 9; price = 8000; };
	class mas_launch_Metis_F 						{ quality = 9; price = 8000; };
	class mas_launch_TitanS_F 						{ quality = 9; price = 8000; };
	class mas_launch_M136_F 						{ quality = 8; price = 7000; };
	class mas_launch_maaws_F 						{ quality = 9; price = 8000; };
	class mas_launch_LAW_F 						    { quality = 8; price = 7000; };
	class mas_launch_NLAW_F 						{ quality = 9; price = 8000; };
	class mas_launch_pzf60_F 						{ quality = 8; price = 7000; };
	class mas_launch_RPG18_F 						{ quality = 8; price = 7000; };
	class mas_launch_smaw_F 						{ quality = 9; price = 8000; };

	///////////////////////////////////////////////////////////////////////////////
	// Снаряды для гранатометов
	///////////////////////////////////////////////////////////////////////////////
	class mas_PG7V									{ quality = 4; price = 1000; };
	class mas_OG7								    { quality = 4; price = 1000; };
	class mas_PG7L									{ quality = 4; price = 1000; };
	class mas_PG7VR								    { quality = 4; price = 1000; };
	class mas_TBG7V								    { quality = 4; price = 1000; };
	class mas_Strela								{ quality = 5; price = 2000; };
	class mas_Stinger								{ quality = 5; price = 2000; };
	class mas_Metis									{ quality = 5; price = 2000; };
	class mas_Metis_HE								{ quality = 5; price = 2000; };
	class mas_TitanS								{ quality = 5; price = 2000; };
	class mas_TitanS_HE								{ quality = 5; price = 2000; };
	class mas_M136								    { quality = 4; price = 1000; };
	class mas_M136_HE							    { quality = 4; price = 1000; };
	class mas_MAAWS_HE								{ quality = 5; price = 2000; };
	class mas_MAAWS									{ quality = 5; price = 2000; };
	class mas_LAW									{ quality = 4; price = 1000; };
	class mas_NLAW									{ quality = 5; price = 2000; };
	class mas_NLAW_HE								{ quality = 5; price = 2000; };
	class mas_pzf60									{ quality = 4; price = 1000; };
	class mas_PG18								    { quality = 4; price = 1000; };
	class mas_SMAW									{ quality = 5; price = 2000; };
	class mas_SMAW_HE								{ quality = 5; price = 2000; };
	class mas_SMAW_NE								{ quality = 5; price = 2000; };