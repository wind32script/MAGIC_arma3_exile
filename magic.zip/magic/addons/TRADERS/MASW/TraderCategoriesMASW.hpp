	class MASGlasses
	{
		name = "MAS Защита лица";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\headgear_ca.paa";
		items[] =
		{
			"G_mas_wpn_bala",
			"G_mas_wpn_bala_gog",
			"G_mas_wpn_bala_gog_b",
			"G_mas_wpn_bala_gog_t",
			"G_mas_wpn_bala_mask",
			"G_mas_wpn_bala_mask_b",
			"G_mas_wpn_bala_mask_t",
			"G_mas_wpn_bala_b",
			"G_mas_wpn_bala_t",
			"G_mas_wpn_gasmask",
			"G_mas_wpn_gasmask_comp",
			"G_mas_wpn_shemag",
			"G_mas_wpn_shemag_gog",
			"G_mas_wpn_shemag_mask",
			"G_mas_wpn_gog",
			"G_mas_wpn_gog_d",
			"G_mas_wpn_gog_m",
			"G_mas_wpn_gog_gd",
			"G_mas_wpn_mask_b",
			"G_mas_wpn_mask",
			"G_mas_wpn_wrap_b",
			"G_mas_wpn_wrap_f",
			"G_mas_wpn_wrap_gog_b",
			"G_mas_wpn_wrap_gog_f",
			"G_mas_wpn_wrap_gog_g",
			"G_mas_wpn_wrap_gog",
			"G_mas_wpn_wrap_gog_c",
			"G_mas_wpn_wrap_gog_t",
			"G_mas_wpn_wrap_mask_b",
			"G_mas_wpn_wrap_mask_f",
			"G_mas_wpn_wrap_mask_g",
			"G_mas_wpn_wrap_mask",
			"G_mas_wpn_wrap_mask_c",
			"G_mas_wpn_wrap_mask_t",
			"G_mas_wpn_wrap",
			"G_mas_wpn_wrap_c",
			"G_mas_wpn_wrap_t"
		};
	};
	
	class MASBackpacks
	{
		name = "MAS Рюкзаки";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\backpack_ca.paa";
		items[] =
		{
			"B_mas_m_Bergen_acr_w",
			"B_mas_m_Bergen_acr_g",
			"B_mas_m_Bergen_acr",
			"B_mas_m_Bergen_acr_c"
		};
	};

	class MASPointerAttachments
	{
		name = "MAS Вспомогательное";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"acc_mas_pointer_IR_b",
			"acc_mas_pointer_IR_top_b",
			"acc_mas_pointer_IR",
			"acc_mas_pointer_IR_top",
			"acc_mas_pointer_IR2c",
			"acc_mas_pointer_IR2c_top",
			"acc_mas_pointer_IR2",
			"acc_mas_pointer_IR2_top",
			"acc_mas_flash_gun",
			"acc_mas_pointer_gun_IR"
		};
	};

	class MASMuzzleAttachments
	{
		name = "MAS Глушители";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemmuzzle_ca.paa";
		items[] =
		{
			"muzzle_mas_snds_AK",
			"muzzle_mas_snds_M",
			"muzzle_mas_snds_Mc",
			"muzzle_mas_snds_SM",
			"muzzle_mas_snds_SMc",
			"muzzle_mas_snds_asval",
			"muzzle_mas_snds_KSVK",
			"muzzle_mas_snds_SV",
			"muzzle_mas_snds_SVc",
			"muzzle_mas_snds_MP7",
			"muzzle_mas_snds_L",
			"muzzle_mas_snds_LM",
			"muzzle_mas_snds_C",
			"muzzle_mas_snds_SVD"
		};
	};

	class MASOpticAttachments
	{
		name = "MAS Оптика";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemoptic_ca.paa";
		items[] =
		{
			"optic_mas_ACO_grn_camo",
			"optic_mas_acog",
			//"optic_mas_acog_rd",
			//"optic_mas_acog_c",
			"optic_mas_acog_eo",
			//"optic_mas_acog_rd_c",
			//"optic_mas_acog_eo_c",
			"optic_mas_aim",
			"optic_mas_Arco_blk",
			"optic_mas_term",
			"optic_mas_DMS",
			"optic_mas_LRPS",
			"optic_mas_MRCO_camo",
			"optic_mas_Hamr_camo",
			"optic_mas_zeiss",
			"optic_mas_goshawk",
			"optic_mas_kobra",
			"optic_mas_PSO_kv",
			"optic_mas_nspu",
			"optic_mas_PSO",
			"optic_mas_MRD"
		};
	};
	
	class MASPistols
	{
		name = "MAS Пистолеты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\handgun_ca.paa";
		items[] =
		{
			"hgun_mas_acp_F",
			"hgun_mas_bhp_F",
			"hgun_mas_glock_F",
			"hgun_mas_glocksf_F",
			"hgun_mas_m23_F",
			"hgun_mas_usp_F",
			"hgun_mas_m9_F",
			"hgun_mas_mak_F",
			"hgun_mas_grach_F",
			"hgun_mas_p226_F"
		};
	};

	class MASSubMachineGuns
	{
		name = "MAS Пист.пулемёты,дробовики";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"arifle_mas_aa12",
			"arifle_mas_m1014",
			"arifle_mas_bizon",
			"arifle_mas_mp5",
			"arifle_mas_mp5_d",
			"arifle_mas_mp5_v",
			"arifle_mas_mp5sd",
			"arifle_mas_mp5sd_ds",
			"hgun_mas_mp7_F",
			"hgun_mas_uzi_F",
			"hgun_mas_mp7p_F",
			"hgun_mas_sa61_F"
		};
	};

	class MASLightMachineGuns
	{
		name = "MAS Пулемёты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"LMG_mas_m240_F",
			"LMG_mas_M249a_F",
			"LMG_mas_M249_F",
			"LMG_mas_M249_F_d",
			"LMG_mas_m60_F",
			"LMG_mas_mg3_F",
			"LMG_mas_mk48_F",
			"LMG_mas_mk48_F_d",
			"LMG_mas_mk48_F_v",
			"LMG_mas_pkm_F",
			"LMG_mas_pech_F",
			"LMG_mas_Mk200_F"
		};
	};

	class MASAssaultRifles
	{
		name = "MAS Автоматы";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"arifle_mas_m70",
			"arifle_mas_m70_gl",
			"arifle_mas_asval",
			"arifle_mas_asval_ds",
			"arifle_mas_ak12_sf",
			"arifle_mas_ak12_sf_gl",
			"arifle_mas_ak_74m",
			"arifle_mas_ak_74m_gl_c",
			"arifle_mas_ak_74m_sf",
			"arifle_mas_ak_74m_sf_gl_c",
			"arifle_mas_ak_74m_train",
			"arifle_mas_arx_l",
			"arifle_mas_arx_l_gl",
			"arifle_mas_arx",
			"arifle_mas_arx_gl",
			"arifle_mas_fal",
			"arifle_mas_fal_m203",
			"arifle_mas_g36c",
			"arifle_mas_g3",
			"arifle_mas_g3_m203",
			"arifle_mas_hk416",
			"arifle_mas_hk416_gl",
			"arifle_mas_hk416_gl_d",
			"arifle_mas_hk416_gl_v",
			"arifle_mas_hk416c_d",
			"srifle_mas_hk417",
			"arifle_mas_hk417c",
			"arifle_mas_hk417c_d",
			"arifle_mas_hk417_m203c",
			"arifle_mas_hk417_m203c_d",
			"srifle_mas_hk417_d",
			"srifle_mas_hk417_v",
			"arifle_mas_l119",
			"arifle_mas_l119c_d",
			"arifle_mas_l119_m203_d",
			"srifle_mas_ebr",
			"arifle_mas_m16a2",
			"arifle_mas_m16a2_gl",
			"arifle_mas_m27",
			"arifle_mas_m27_d",
			"arifle_mas_m27m",
			"arifle_mas_m4vlt",
			"arifle_mas_m4",
			"arifle_mas_m4_gl",
			"arifle_mas_mk17",
			"arifle_mas_mk17_gl",
			"srifle_mas_sr25",
			"srifle_mas_sr25_d",
			"srifle_mas_sr25_v"
		};
	};

	class MASSniperRifles
	{
		name = "MAS Снайперские винтовки";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"srifle_mas_m91",
			"srifle_mas_vss",
			"srifle_mas_svd",
			"arifle_mas_lee",
			"srifle_mas_ksvk",
			"srifle_mas_ksvk_c",
			"srifle_mas_lrr",
			"srifle_mas_m107",
			"srifle_mas_m107_d",
			"srifle_mas_m107_v",
			"srifle_mas_m109",
			"srifle_mas_m110",
			"srifle_mas_m24",
			"srifle_mas_m24_d",
			"srifle_mas_m24_v"
		};
	};

	class MASAmmunition
	{
		name = "MAS Патроны";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"20Rnd_mas_12Gauge_Slug",
			"20Rnd_mas_12Gauge_Pellets",
			"20Rnd_mas_12Gauge_Demo",
			"30Rnd_mas_545x39_mag",
			"30Rnd_mas_545x39bk_mag",
			"30Rnd_mas_545x39sd_mag",
			"30Rnd_mas_545x39_T_mag",
			"30Rnd_mas_556x45_Stanag",
			"30Rnd_mas_556x45sd_Stanag",
			"30Rnd_mas_556x45_T_Stanag",
			"30Rnd_mas_9x39_mag",
			"30Rnd_mas_9x39sd_mag",
			"20Rnd_mas_9x39_mag",
			"20Rnd_mas_9x39sd_mag",
			"7Rnd_mas_12Gauge_Slug",
			"7Rnd_mas_12Gauge_Pellets",
			"64Rnd_mas_9x18_mag",
			"64Rnd_mas_9x18sd_mag",
			"20Rnd_mas_762x51_Stanag",
			"20Rnd_mas_762x51sd_Stanag",
			"20Rnd_mas_762x51_T_Stanag",
			"5Rnd_mas_127x108_mag",
			"5Rnd_mas_127x108_T_mag",
			"5Rnd_mas_127x108_dem_mag",
			"5Rnd_mas_762x51_Stanag",
			"5Rnd_mas_762x51_T_Stanag",
			"10Rnd_mas_338_Stanag",
			"10Rnd_mas_338sd_Stanag",
			"10Rnd_mas_338_T_Stanag",
			"5Rnd_mas_127x99_Stanag",
			"5Rnd_mas_127x99_T_Stanag",
			"5Rnd_mas_127x99_dem_Stanag",
			"100Rnd_mas_762x51_Stanag",
			"100Rnd_mas_762x51_T_Stanag",
			"200Rnd_mas_556x45_Stanag",
			"200Rnd_mas_556x45_T_Stanag",
			"150Rnd_mas_556x45_Stanag",
			"150Rnd_mas_556x45_T_Stanag",
			"30Rnd_mas_9x21_Stanag",
			"30Rnd_mas_9x21sd_Stanag",
			"40Rnd_mas_46x30_Mag",
			"40Rnd_mas_46x30sd_Mag",
			"100Rnd_mas_762x54_mag",
			"100Rnd_mas_762x54_T_mag",
			"10Rnd_mas_762x54sd_mag",
			"10Rnd_mas_762x54_mag",
			"10Rnd_mas_762x54_T_mag",
			"5Rnd_mas_25x59_Stanag",
			"30Rnd_mas_762x39_mag",
			"30Rnd_mas_762x39sd_mag",
			"30Rnd_mas_762x39_T_mag",
			"12Rnd_mas_45acp_Mag",
			"10Rnd_mas_45acp_Mag",
			"8Rnd_mas_45acp_Mag",
			"12Rnd_mas_45acpsd_Mag",
			"15Rnd_mas_9x21_Mag",
			"17Rnd_mas_9x21_Mag",
			"13Rnd_mas_9x21_Mag",
			"15Rnd_mas_9x21sd_Mag",
			"8Rnd_mas_9x18_Mag",
			"8Rnd_mas_9x18sd_Mag",
			"25Rnd_mas_9x19_Mag",
			"20Rnd_mas_765x17_Mag"
		};
	};

	class MASLaunchers
	{
		name = "MAS Гранатометы";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"mas_launch_RPG7_F",
			"mas_launch_Strela_F",
			"mas_launch_Stinger_F",
			"mas_launch_Metis_F",
			"mas_launch_TitanS_F",
			"mas_launch_M136_F",
			"mas_launch_maaws_F",
			"mas_launch_LAW_F",
			"mas_launch_NLAW_F",
			"mas_launch_pzf60_F",
			"mas_launch_RPG18_F",
			"mas_launch_smaw_F"
		};
	};

	class MASLauncherAmmo
	{
		name = "MAS Снаряды для гранатометов";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"mas_PG7V",
			"mas_OG7",
			"mas_PG7L",
			"mas_PG7VR",
			"mas_TBG7V",
			"mas_Strela",
			"mas_Stinger",
			"mas_Metis",
			"mas_Metis_HE",
			"mas_TitanS",
			"mas_TitanS_HE",
			"mas_M136",
			"mas_M136_HE",
			"mas_MAAWS_HE",
			"mas_MAAWS",
			"mas_LAW",
			"mas_NLAW",
			"mas_NLAW_HE",
			"mas_pzf60",
			"mas_PG18",
			"mas_SMAW",
			"mas_SMAW_HE",
			"mas_SMAW_NE"
		};
	};