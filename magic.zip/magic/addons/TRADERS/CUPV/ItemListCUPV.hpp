    ///////////////////////////////////////////////////////////////////////////////
	//CUP Автомобили
	///////////////////////////////////////////////////////////////////////////////
	//class CUP_LADA_LM_CIV                         { quality = 1; price = 13000; };
	//class CUP_C_Volha_Gray_TKCIV                  { quality = 1; price = 13000; };
	//class CUP_C_Golf4_black_Civ	                { quality = 1; price = 14000; };
	//class CUP_C_Golf4_camo_Civ	                { quality = 1; price = 14000; };
	//class CUP_C_Skoda_White_CIV                   { quality = 1; price = 14000; };
	class CUP_C_S1203_CIV                           { quality = 1; price = 15000; };
	class CUP_C_S1203_Ambulance_CIV                 { quality = 1; price = 15000; };
	class CUP_C_S1203_Militia_CIV                   { quality = 1; price = 15000; };
	class CUP_C_Octavia_CIV                         { quality = 1; price = 15000; };
	class CUP_C_Datsun	                            { quality = 1; price = 15500; };
	class CUP_O_UAZ_Unarmed_RU                      { quality = 1; price = 16000; };
	class CUP_O_UAZ_AMB_RU                          { quality = 1; price = 16000; };
	class CUP_O_UAZ_Open_RU                         { quality = 1; price = 16000; };
	class CUP_O_GAZ_Vodnik_MedEvac_RU	            { quality = 2; price = 25000; };
	class CUP_B_HMMWV_Unarmed_USMC	                { quality = 2; price = 20000; };
	class CUP_B_HMMWV_Ambulance_USMC	            { quality = 2; price = 20000; };
	class CUP_B_HMMWV_Transport_NATO_T	            { quality = 2; price = 20000; };
	class CUP_B_HMMWV_Terminal_NATO_T	            { quality = 2; price = 20000; };
	class CUP_B_LR_Ambulance_CZ_W	                { quality = 2; price = 20000; };
	class CUP_C_LR_Transport_CTK	                { quality = 2; price = 20000; };
	class CUP_B_LR_Transport_GB_W	                { quality = 2; price = 20000; };
	class CUP_B_M1151_DSRT_USMC	                    { quality = 2; price = 30000; };
	class CUP_B_M1152_DSRT_USMC	                    { quality = 2; price = 30000; };
	class CUP_C_SUV_CIV	                            { quality = 2; price = 30000; };
	//class CUP_B_M1133_MEV_Desert                  { quality = 2; price = 65000; };
	class CUP_I_BTR40_TKG                           { quality = 2; price = 45000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Грузовики
	///////////////////////////////////////////////////////////////////////////////
	//class CUP_C_Ikarus_Chernarus	                { quality = 1; price = 15000; };
	class CUP_B_MTVR_USMC                           { quality = 1; price = 50000; };
	class CUP_B_MTVR_Ammo_USMC	                    { quality = 1; price = 50000; };
	class CUP_B_MTVR_Refuel_USMC                    { quality = 1; price = 50000; };
	class CUP_B_MTVR_Repair_USMC                    { quality = 1; price = 50000; };
	class CUP_O_V3S_Open_TKA                        { quality = 1; price = 50000; };
	class CUP_O_V3S_Covered_TKA	                    { quality = 1; price = 50000; };
	class CUP_O_V3S_Refuel_TKA                      { quality = 1; price = 50000; };
	class CUP_O_V3S_Repair_TKA	                    { quality = 1; price = 50000; };
	class CUP_B_T810_Unarmed_CZ_WDL                 { quality = 1; price = 50000; };
	class CUP_B_T810_Reammo_CZ_WDL                  { quality = 1; price = 50000; };
	class CUP_B_T810_Refuel_CZ_WDL                  { quality = 1; price = 50000; };
	class CUP_B_T810_Repair_CZ_WDL                  { quality = 1; price = 50000; };
	class CUP_B_T810_Armed_CZ_WDL	                { quality = 1; price = 50000; };
	class CUP_O_Ural_RU                             { quality = 1; price = 50000; };
	class CUP_O_Ural_Reammo_RU                      { quality = 1; price = 50000; };
	class CUP_C_Ural_Open_Civ_01                    { quality = 1; price = 50000; };
	class CUP_O_Ural_Empty_RU	                    { quality = 1; price = 50000; };
	class CUP_O_Ural_Open_RU                        { quality = 1; price = 50000; };
	class CUP_O_Ural_Refuel_RU                      { quality = 1; price = 50000; };
	class CUP_O_Ural_Repair_RU	                    { quality = 1; price = 50000; };
	class CUP_O_Ural_ZU23_RU                        { quality = 5; price = 75000; };
	
	///////////////////////////////////////////////////////////////////////////////
	//CUP Вооруженная техника
	///////////////////////////////////////////////////////////////////////////////
	class CUP_O_UAZ_MG_RU                           { quality = 4; price = 50000; };
	class CUP_O_UAZ_AGS30_RU                        { quality = 4; price = 50000; };
	class CUP_O_UAZ_METIS_RU                        { quality = 4; price = 55000; };
	class CUP_I_Datsun_PK_TK                        { quality = 4; price = 60000; };
	class CUP_I_SUV_Armored_ION	                    { quality = 4; price = 65000; };
	class CUP_B_HMMWV_Crows_M2_NATO_T	            { quality = 5; price = 70000; };
	class CUP_B_HMMWV_Crows_MK19_NATO_T	            { quality = 5; price = 75000; };
	class CUP_B_HMMWV_M2_GPK_NATO_T	                { quality = 5; price = 70000; };
	class CUP_B_HMMWV_DSHKM_GPK_ACR	                { quality = 5; price = 70500; };
	class CUP_B_HMMWV_AGS_GPK_ACR                   { quality = 5; price = 75000; };
	class CUP_B_HMMWV_M1114_USMC	                { quality = 5; price = 70000; };
	class CUP_B_HMMWV_M2_NATO_T	                    { quality = 5; price = 70000; };
	class CUP_B_HMMWV_MK19_USMC	                    { quality = 5; price = 75000; };
	class CUP_B_HMMWV_SOV_M2_NATO_T	                { quality = 5; price = 70000; };
	class CUP_B_HMMWV_SOV_NATO_T	                { quality = 5; price = 75000; };
	class CUP_B_HMMWV_TOW_USMC	                    { quality = 5; price = 80000; };
	class CUP_B_HMMWV_Avenger_USMC	                { quality = 5; price = 90000; };
	class CUP_B_M1151_M2_USA	                    { quality = 5; price = 70000; };
	class CUP_B_M1151_Deploy_USA	                { quality = 5; price = 70000; };
	class CUP_B_M1151_Mk19_USA	                    { quality = 5; price = 75000; };
	class CUP_B_M1165_GMV_USA	                    { quality = 5; price = 72000; };
	class CUP_B_M1167_USA	                        { quality = 5; price = 80000; };
	class CUP_O_GAZ_Vodnik_PK_RU	                { quality = 5; price = 75000; };
	class CUP_O_GAZ_Vodnik_AGS_RU                   { quality = 5; price = 90000; };
	class CUP_O_GAZ_Vodnik_BPPU_RU                  { quality = 5; price = 95000; };
	class CUP_B_Dingo_CZ_Wdl                        { quality = 5; price = 90000; };
	class CUP_B_Dingo_GL_CZ_Wdl	                    { quality = 5; price = 90000; };
	class CUP_B_BAF_Coyote_L2A1_W                   { quality = 5; price = 90000; };
	class CUP_B_BAF_Coyote_L2A1_D                   { quality = 5; price = 90000; };
	class CUP_B_BAF_Coyote_GMG_W                    { quality = 5; price = 90000; };
	class CUP_B_BAF_Coyote_GMG_D		            { quality = 5; price = 90000; };
	class CUP_B_Jackal2_L2A1_GB_D			        { quality = 5; price = 90000; };
	class CUP_B_Jackal2_L2A1_GB_W	                { quality = 5; price = 90000; };
	class CUP_B_Jackal2_GMG_GB_W	                { quality = 5; price = 90000; };
	class CUP_B_Jackal2_GMG_GB_D	                { quality = 5; price = 90000; };
	class CUP_B_LR_MG_CZ_W	                        { quality = 5; price = 90000; };
	class CUP_B_LR_Special_CZ_W	                    { quality = 5; price = 90000; };
	class CUP_O_LR_SPG9_TKA	                        { quality = 5; price = 95000; };
	class CUP_B_LR_Special_M2_GB_W	                { quality = 5; price = 90000; };
	class CUP_B_LR_Special_GMG_GB_W	                { quality = 5; price = 90000; };
	class CUP_B_Mastiff_LMG_GB_D	                { quality = 5; price = 80000; };
	class CUP_B_Mastiff_HMG_GB_D                    { quality = 5; price = 85000; };
	class CUP_B_Mastiff_GMG_GB_D	                { quality = 5; price = 90000; };
	class CUP_B_RG31_M2_USMC                        { quality = 5; price = 90000; };
	class CUP_B_RG31_M2_GC_USMC	                    { quality = 5; price = 90000; };
	class CUP_B_RG31E_M2_USMC                       { quality = 5; price = 90000; };
	class CUP_B_RG31_Mk19_USMC	                    { quality = 5; price = 90000; };
	class CUP_B_Ridgback_LMG_GB_D	                { quality = 5; price = 80000; };
	class CUP_B_Ridgback_HMG_GB_D				    { quality = 5; price = 85000; };
	class CUP_B_Ridgback_GMG_GB_D	                { quality = 5; price = 90000; };
	class CUP_B_Wolfhound_LMG_GB_D                  { quality = 5; price = 80000; };
	class CUP_B_Wolfhound_HMG_GB_D                  { quality = 5; price = 85000; };
	class CUP_B_Wolfhound_GMG_GB_D                  { quality = 5; price = 90000; };
	class CUP_I_BTR40_MG_TKG                        { quality = 5; price = 95000; };
	class CUP_O_BRDM2_HQ_RUS                        { quality = 5; price = 95000; };
	class CUP_O_BRDM2_RUS                           { quality = 5; price = 96000; };
	class CUP_O_BRDM2_ATGM_RUS                      { quality = 5; price = 96000; };
	class CUP_O_BTR90_HQ_RU                         { quality = 5; price = 96000; };
	class CUP_O_BTR60_RU                            { quality = 5; price = 96000; };
	class CUP_O_BTR60_Green_RU                      { quality = 5; price = 96000; };
	class CUP_O_BTR60_Winter_RU                     { quality = 5; price = 96000; };
	class CUP_O_BTR90_RU                            { quality = 6; price = 100000; };
	class CUP_B_LAV25_HQ_USMC                       { quality = 5; price = 98000; };
	class CUP_B_LAV25_USMC	                        { quality = 6; price = 105000; };
	class CUP_B_LAV25M240_USMC		                { quality = 6; price = 150000; };
	class CUP_B_M1126_ICV_M2_Desert		            { quality = 5; price = 98000; };
	class CUP_B_M1130_CV_M2_Desert	                { quality = 5; price = 98000; };
	class CUP_B_M1126_ICV_MK19_Desert	            { quality = 6; price = 120000; };
	class CUP_B_M1128_MGS_Desert	                { quality = 6; price = 130000; };
	class CUP_B_M1135_ATGMV_Desert                  { quality = 6; price = 150000; };
//	class CUP_B_M1129_MC_MK19_Desert                { quality = 7; price = 20000; };
	
	///////////////////////////////////////////////////////////////////////////////
	//CUP Гусеничная техника
	///////////////////////////////////////////////////////////////////////////////
	class CUP_O_MTLB_pk_TKA                        { quality = 5; price = 90000; };
	class CUP_O_MTLB_pk_TK_MILITIA                 { quality = 5; price = 90000; };
	class CUP_O_MTLB_pk_ChDKZ                      { quality = 5; price = 90000; };
	class CUP_O_MTLB_pk_SLA                        { quality = 5; price = 90000; };
	class CUP_O_MTLB_pk_Green_RU                   { quality = 5; price = 90000; };
	class CUP_O_MTLB_pk_WDL_RU                     { quality = 5; price = 90000; };
	class CUP_O_MTLB_pk_Winter_RU                  { quality = 5; price = 90000; };
	class CUP_B_MTLB_pk_CDF                        { quality = 5; price = 90000; };
	class CUP_B_MTLB_pk_Winter_CDF                 { quality = 5; price = 90000; };
	class CUP_B_MTLB_pk_FIA                        { quality = 5; price = 90000; };
	class CUP_I_MTLB_pk_SYNDIKAT                   { quality = 5; price = 90000; };
	class CUP_I_MTLB_pk_UN                         { quality = 5; price = 90000; };
	class CUP_I_MTLB_pk_NAPA                       { quality = 5; price = 90000; };
	class CUP_O_BMP2_AMB_RU                        { quality = 5; price = 90000; };
    class CUP_O_BMP_HQ_RU                          { quality = 6; price = 100000; };
    class CUP_O_BMP1_TKA	                       { quality = 6; price = 100000; };
    class CUP_O_BMP1P_TKA	                       { quality = 6; price = 110000; };
    class CUP_O_BMP2_RU	                           { quality = 6; price = 110000; };
    class CUP_O_BMP2_ZU_TKA 	                   { quality = 6; price = 115000; };
    class CUP_O_BMP3_RU	                           { quality = 6; price = 125000; };
    class CUP_O_ZSU23_Afghan_TK	                   { quality = 6; price = 120000; };
    class CUP_O_ZSU23_TK	                       { quality = 6; price = 120000; };
    class CUP_O_2S6_RU	                           { quality = 6; price = 140000; };
    class CUP_O_2S6M_RU		                       { quality = 6; price = 140000; };
	class CUP_B_AAV_Unarmed_USMC                   { quality = 5; price = 145000; };
    class CUP_I_AAV_RACS                           { quality = 6; price = 150000; };
    class CUP_B_FV432_Bulldog_GB_D                 { quality = 6; price = 115000; };
    class CUP_B_FV432_Bulldog_GB_D_RWS	           { quality = 6; price = 125000; };
	class CUP_B_FV510_GB_D_SLAT                    { quality = 6; price = 145000; };
    class CUP_B_M113_Med_USA                       { quality = 5; price = 145000; };
    class CUP_B_M113_USA	                       { quality = 6; price = 115000; };
	class CUP_B_M163_USA                           { quality = 6; price = 165000; };
	class CUP_B_M2Bradley_USA_D                    { quality = 6; price = 185000; };
	class CUP_B_M2A3Bradley_NATO_T                 { quality = 6; price = 195000; };
	class CUP_B_M7Bradley_USA_D                    { quality = 6; price = 175000; };
	class CUP_B_MCV80_GB_W_SLAT                    { quality = 6; price = 180000; };
	class CUP_O_T34_TKA                            { quality = 6; price = 150000; };
	
	class CUP_O_T55_TK                             { quality = 10; price = 350000; };
	class CUP_O_T72_RU                             { quality = 10; price = 350000; };
	class CUP_B_T72_CZ                             { quality = 10; price = 350000; };
	class CUP_O_T90_RU                             { quality = 10; price = 350000; };
	class CUP_B_Leopard2A6_GER                     { quality = 10; price = 350000; };
	class CUP_B_M1A1_Woodland_US_Army              { quality = 10; price = 350000; };
	class CUP_B_M1A2_TUSK_MG_US_Army               { quality = 10; price = 350000; };
    class CUP_B_M60A3_USMC                         { quality = 10; price = 350000; };
	class CUP_I_M60A3_RACS                         { quality = 10; price = 350000; };
	
	///////////////////////////////////////////////////////////////////////////////
	//CUP Вертолёты
	///////////////////////////////////////////////////////////////////////////////
	class CUP_C_Mi17_Civilian_RU	              { quality = 2; price = 55000; };
	class CUP_O_Mi8_medevac_RU                    { quality = 2; price = 55000; };
	class CUP_O_Mi8_VIV_RU                        { quality = 2; price = 55000; };
	class CUP_B_MH6J_USA	                      { quality = 2; price = 27000; };
	class CUP_B_MH6M_USA                          { quality = 2; price = 27000; };
	class CUP_B_AW159_Unarmed_GB	              { quality = 2; price = 60000; };
	class CUP_I_Wildcat_Unarmed_Green_AAF         { quality = 2; price = 60000; };
	class CUP_B_Merlin_HC3_GB	                  { quality = 2; price = 60000; };
	class CUP_B_Merlin_HC3_VIV_GB                 { quality = 2; price = 60000; };
	class CUP_B_Merlin_HC3A_GB                    { quality = 2; price = 60000; };
	class CUP_B_SA330_Puma_HC1_BAF	              { quality = 2; price = 60000; };
	class CUP_B_SA330_Puma_HC2_BAF	              { quality = 2; price = 60000; };
	class CUP_B_UH1Y_MEV_USMC                     { quality = 2; price = 60000; };
	class CUP_B_UH1Y_UNA_USMC	                  { quality = 2; price = 60000; };
	class CUP_B_UH60M_Unarmed_US                  { quality = 2; price = 60000; };
	class CUP_B_CH53E_USMC                        { quality = 3; price = 70000; };
	class CUP_B_CH53E_GER	                      { quality = 3; price = 70000; };
	class CUP_B_CH53E_VIV_USMC	                  { quality = 3; price = 70000; };
	class CUP_B_CH53E_VIV_GER	                  { quality = 3; price = 70000; };
	
	///////////////////////////////////////////////////////////////////////////////
	//CUP Вооруженные Вертолёты
	///////////////////////////////////////////////////////////////////////////////
	class CUP_O_Mi8_CHDKZ                         { quality = 4; price = 150000; };
	class CUP_O_Mi8_RU                            { quality = 6; price = 180000; };
	class CUP_B_Mi24_D_MEV_Dynamic_CDF            { quality = 7; price = 190000; };
	class CUP_O_Mi24_P_Dynamic_RU                 { quality = 7; price = 190000; };
	class CUP_O_Mi24_V_Dynamic_RU                 { quality = 7; price = 190000; };
	class CUP_O_Ka60_Grey_RU                      { quality = 7; price = 200000; };
	class CUP_B_Mi171Sh_ACR                       { quality = 7; price = 200000; };
	class CUP_I_Mi24_Mk3_AAF                      { quality = 8; price = 320000; };
	class CUP_O_Ka50_DL_RU                        { quality = 9; price = 350000; };
	class CUP_O_Ka50_SLA                          { quality = 9; price = 350000; };
	class CUP_O_Ka50_RU                           { quality = 9; price = 350000; };
    class CUP_O_Ka52_RU                           { quality = 9; price = 360000; };
	class CUP_B_AH6J_USA                          { quality = 9; price = 210000; };
	class CUP_I_AH6J_RACS                         { quality = 9; price = 210000; };
	class CUP_B_AH6M_USA                          { quality = 9; price = 210000; };
	class CUP_B_CH47F_USA                         { quality = 3; price = 90000; };
	class CUP_B_CH47F_VIV_USA                     { quality = 3; price = 90000; };
	class CUP_O_UH1H_TKA                          { quality = 3; price = 80000; };
	class CUP_B_UH60M_US                          { quality = 3; price = 80000; };
	class CUP_B_UH1Y_Gunship_Dynamic_USMC         { quality = 6; price = 160000; };
	class CUP_B_MH60L_DAP_4x_USN                  { quality = 6; price = 150000; };
	class CUP_B_AH64D_DL_USA                      { quality = 9; price = 350000; };
	class CUP_B_AH1Z_Dynamic_USMC                 { quality = 9; price = 345000; };
	
	///////////////////////////////////////////////////////////////////////////////
	//CUP Самолёты
	///////////////////////////////////////////////////////////////////////////////
	class CUP_B_MV22_USMC                         { quality = 3; price = 85000; };
	class CUP_B_MV22_VIV_USMC                     { quality = 3; price = 85000; };
	
	///////////////////////////////////////////////////////////////////////////////
	//CUP Вооруженные Самолёты
	///////////////////////////////////////////////////////////////////////////////
//	class CUP_B_MV22_USMC_RAMPGUN                 { quality = 3; price = 95000; };
//	class CUP_O_Su25_Dyn_RU                       { quality = 10; price = 100000; };
	class CUP_O_SU34_RU                           { quality = 10; price = 400000; };
//	class CUP_B_GR9_DYN_GB                        { quality = 10; price = 100000; };
//	class CUP_B_F35B_USMC                         { quality = 10; price = 100000; };
//	class CUP_B_AV8B_CAP_USMC                     { quality = 10; price = 100000; };
//	class CUP_I_AV8B_CAP_AAF                      { quality = 10; price = 100000; };
//	class CUP_B_AV8B_MK82_USMC                    { quality = 10; price = 100000; };
//	class CUP_I_AV8B_MK82_AAF                     { quality = 10; price = 100000; };
//	class CUP_B_AV8B_GBU12_USMC                   { quality = 10; price = 100000; };
//	class CUP_I_AV8B_GBU12_AAF                    { quality = 10; price = 100000; };
//	class CUP_B_AV8B_AGM_USMC                     { quality = 10; price = 100000; };
//	class CUP_I_AV8B_AGM_AAF                      { quality = 10; price = 100000; };
	class CUP_B_A10_DYN_USA                       { quality = 10; price = 400000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Лодки
	///////////////////////////////////////////////////////////////////////////////
	class CUP_O_PBX_RU                            { quality = 1; price = 25000; };
	class CUP_O_PBX_SLA                           { quality = 1; price = 25000; };
	class CUP_C_PBX_CIV                           { quality = 1; price = 25000; };
	class CUP_I_LCVP_RACS                         { quality = 3; price = 50000; };
	class CUP_I_LCVP_VIV_RACS                     { quality = 3; price = 50000; };
	class CUP_O_LCVP_SLA                          { quality = 3; price = 50000; };
	class CUP_O_LCVP_VIV_SLA                      { quality = 3; price = 50000; };
	class CUP_B_RHIB_USMC                         { quality = 4; price = 60000; };
	class CUP_I_RHIB_RACS                         { quality = 4; price = 60000; };
	class CUP_B_RHIB2Turret_USMC                  { quality = 4; price = 60000; };
	class CUP_I_RHIB2Turret_RACS                  { quality = 4; price = 60000; };