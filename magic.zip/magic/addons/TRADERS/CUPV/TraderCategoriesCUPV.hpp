    class CUPUnarmed
	{
		name = "CUP Автомобили";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			//"CUP_LADA_LM_CIV",
			//"CUP_C_Volha_Gray_TKCIV",
			//"CUP_C_Golf4_black_Civ",
			//"CUP_C_Golf4_camo_Civ",
			//"CUP_C_Skoda_White_CIV",
			"CUP_C_S1203_CIV",
			"CUP_C_S1203_Ambulance_CIV",
			"CUP_C_S1203_Militia_CIV",
			"CUP_C_Octavia_CIV",
			"CUP_C_Datsun",
			"CUP_O_UAZ_Unarmed_RU",
			"CUP_O_UAZ_AMB_RU",
			"CUP_O_UAZ_Open_RU",
			"CUP_O_GAZ_Vodnik_MedEvac_RU",
			"CUP_B_HMMWV_Unarmed_USMC",
			"CUP_B_HMMWV_Ambulance_USMC",
			"CUP_B_HMMWV_Transport_NATO_T",
			"CUP_B_HMMWV_Terminal_NATO_T",
			"CUP_B_LR_Ambulance_CZ_W",
			"CUP_C_LR_Transport_CTK",
			"CUP_B_LR_Transport_GB_W",
			"CUP_B_M1151_DSRT_USMC",
			"CUP_B_M1152_DSRT_USMC",
			"CUP_C_SUV_CIV",
			//"CUP_B_M1133_MEV_Desert",
			"CUP_I_BTR40_TKG"
		};
	};
	
    class CUPTrucks
	{
		name = "CUP Грузовики";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{	
		   //"CUP_C_Ikarus_Chernarus",
			"CUP_B_MTVR_USMC",
			"CUP_B_MTVR_Ammo_USMC",
			"CUP_B_MTVR_Refuel_USMC",
			"CUP_B_MTVR_Repair_USMC",
			"CUP_O_V3S_Open_TKA",
			"CUP_O_V3S_Covered_TKA",
			"CUP_O_V3S_Refuel_TKA",
			"CUP_O_V3S_Repair_TKA",
			"CUP_B_T810_Unarmed_CZ_WDL",
			"CUP_B_T810_Reammo_CZ_WDL",
			"CUP_B_T810_Refuel_CZ_WDL",
			"CUP_B_T810_Repair_CZ_WDL",
			"CUP_B_T810_Armed_CZ_WDL",
			"CUP_O_Ural_RU",
			"CUP_O_Ural_Reammo_RU",
			"CUP_C_Ural_Open_Civ_01",
			"CUP_O_Ural_Empty_RU",
			"CUP_O_Ural_Open_RU",
			"CUP_O_Ural_Refuel_RU",
			"CUP_O_Ural_Repair_RU",
			"CUP_O_Ural_ZU23_RU"
		};
	};
	
	class CUPArmed
	{
		name = "CUP Вооруженная техника";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"CUP_O_UAZ_MG_RU",
			"CUP_O_UAZ_AGS30_RU",
			"CUP_O_UAZ_METIS_RU",
			"CUP_I_Datsun_PK_TK",
			"CUP_I_SUV_Armored_ION",
			"CUP_B_HMMWV_Crows_M2_NATO_T",
			"CUP_B_HMMWV_Crows_MK19_NATO_T",
			"CUP_B_HMMWV_M2_GPK_NATO_T",
			"CUP_B_HMMWV_DSHKM_GPK_ACR",
			"CUP_B_HMMWV_AGS_GPK_ACR",
			"CUP_B_HMMWV_M1114_USMC",
			"CUP_B_HMMWV_M2_NATO_T",
			"CUP_B_HMMWV_MK19_USMC",
			"CUP_B_HMMWV_SOV_M2_NATO_T",
			"CUP_B_HMMWV_SOV_NATO_T",
			"CUP_B_HMMWV_TOW_USMC",
			"CUP_B_HMMWV_Avenger_USMC",
			"CUP_B_M1151_M2_USA",
			"CUP_B_M1151_Deploy_USA",
			"CUP_B_M1151_Mk19_USA",
			"CUP_B_M1165_GMV_USA",
			"CUP_B_M1167_USA",
			"CUP_O_GAZ_Vodnik_PK_RU",
			"CUP_O_GAZ_Vodnik_AGS_RU",
			"CUP_O_GAZ_Vodnik_BPPU_RU",
			"CUP_B_Dingo_CZ_Wdl",
			"CUP_B_Dingo_GL_CZ_Wdl",
			"CUP_B_BAF_Coyote_L2A1_W",
			"CUP_B_BAF_Coyote_L2A1_D",
			"CUP_B_BAF_Coyote_GMG_W",
			"CUP_B_BAF_Coyote_GMG_D",
			"CUP_B_Jackal2_L2A1_GB_D",
			"CUP_B_Jackal2_L2A1_GB_W",
			"CUP_B_Jackal2_GMG_GB_W",
			"CUP_B_Jackal2_GMG_GB_D",
			"CUP_B_LR_MG_CZ_W",
			"CUP_B_LR_Special_CZ_W",
			"CUP_O_LR_SPG9_TKA",
			"CUP_B_LR_Special_M2_GB_W",
			"CUP_B_LR_Special_GMG_GB_W",
			"CUP_B_Mastiff_LMG_GB_D",
			"CUP_B_Mastiff_HMG_GB_D",
			"CUP_B_Mastiff_GMG_GB_D",
			"CUP_B_RG31_M2_USMC",
			"CUP_B_RG31_M2_GC_USMC",
			"CUP_B_RG31E_M2_USMC",
			"CUP_B_RG31_Mk19_USMC",
			"CUP_B_Ridgback_LMG_GB_D",
			"CUP_B_Ridgback_HMG_GB_D",
			"CUP_B_Ridgback_GMG_GB_D",
			"CUP_B_Wolfhound_LMG_GB_D",
			"CUP_B_Wolfhound_HMG_GB_D",
			"CUP_B_Wolfhound_GMG_GB_D",
			"CUP_I_BTR40_MG_TKG",
			"CUP_O_BRDM2_HQ_RUS",
			"CUP_O_BRDM2_RUS",
			"CUP_O_BRDM2_ATGM_RUS",
			"CUP_O_BTR90_HQ_RU",
			"CUP_O_BTR60_RU",
			"CUP_O_BTR60_Green_RU",
			"CUP_O_BTR60_Winter_RU",
			"CUP_O_BTR90_RU",
			"CUP_B_LAV25_HQ_USMC",
			"CUP_B_LAV25_USMC",
			"CUP_B_LAV25M240_USMC",
			"CUP_B_M1126_ICV_M2_Desert",
			"CUP_B_M1130_CV_M2_Desert",
			"CUP_B_M1126_ICV_MK19_Desert",
			"CUP_B_M1128_MGS_Desert",
			"CUP_B_M1135_ATGMV_Desert"
//			"CUP_B_M1129_MC_MK19_Desert",
		};
	};
	
	class CUPTanks
	{
		name = "CUP Гусеничная техника";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"CUP_O_MTLB_pk_TKA",
			"CUP_O_MTLB_pk_TK_MILITIA",
			"CUP_O_MTLB_pk_ChDKZ",
			"CUP_O_MTLB_pk_SLA",
			"CUP_O_MTLB_pk_Green_RU",
			"CUP_O_MTLB_pk_WDL_RU",
			"CUP_O_MTLB_pk_Winter_RU",
			"CUP_B_MTLB_pk_CDF",
			"CUP_B_MTLB_pk_Winter_CDF",
			"CUP_B_MTLB_pk_FIA",
			"CUP_I_MTLB_pk_SYNDIKAT",
			"CUP_I_MTLB_pk_UN",
			"CUP_I_MTLB_pk_NAPA",
			"CUP_O_BMP2_AMB_RU",
			"CUP_O_BMP_HQ_RU",
			"CUP_O_BMP1_TKA",
			"CUP_O_BMP1P_TKA",
			"CUP_O_BMP2_RU",
			"CUP_O_BMP2_ZU_TKA",
			"CUP_O_BMP3_RU",
			"CUP_O_ZSU23_Afghan_TK",
			"CUP_O_ZSU23_TK",
			"CUP_O_2S6_RU",
			"CUP_O_2S6M_RU",
			"CUP_B_AAV_Unarmed_USMC",
			"CUP_I_AAV_RACS",
			"CUP_B_FV432_Bulldog_GB_D",
			"CUP_B_FV432_Bulldog_GB_D_RWS",
			"CUP_B_FV510_GB_D_SLAT",
			"CUP_B_M113_Med_USA",
			"CUP_B_M113_USA",
			"CUP_B_M163_USA",
			"CUP_B_M2Bradley_USA_D",
			"CUP_B_M2A3Bradley_NATO_T",
			"CUP_B_M7Bradley_USA_D",
			"CUP_B_MCV80_GB_W_SLAT",
			"CUP_O_T34_TKA",
			"CUP_O_T55_TK",
			"CUP_O_T72_RU",
			"CUP_B_T72_CZ",
			"CUP_O_T90_RU",
			"CUP_B_Leopard2A6_GER",
			"CUP_B_M1A1_Woodland_US_Army",
			"CUP_B_M1A2_TUSK_MG_US_Army",
			"CUP_B_M60A3_USMC",
			"CUP_I_M60A3_RACS"
		};
	};

	class CUPChoppers
	{
		name = "CUP Вертолёты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"CUP_C_Mi17_Civilian_RU",
			"CUP_O_Mi8_medevac_RU",
			"CUP_O_Mi8_VIV_RU",
			"CUP_B_MH6J_USA",
			"CUP_B_MH6M_USA",
			"CUP_B_AW159_Unarmed_GB",
			"CUP_I_Wildcat_Unarmed_Green_AAF",
			"CUP_B_Merlin_HC3_GB",
			"CUP_B_Merlin_HC3_VIV_GB",
			"CUP_B_Merlin_HC3A_GB",
			"CUP_B_SA330_Puma_HC1_BAF",
			"CUP_B_SA330_Puma_HC2_BAF",
			"CUP_B_UH1Y_MEV_USMC",
			"CUP_B_UH1Y_UNA_USMC",
			"CUP_B_UH60M_Unarmed_US",
			"CUP_B_CH53E_USMC",
			"CUP_B_CH53E_GER",
			"CUP_B_CH53E_VIV_USMC",
			"CUP_B_CH53E_VIV_GER"
		};
	};
	
	class CUPArmedChoppers
	{
		name = "CUP Вооруженные Вертолёты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"CUP_O_Mi8_CHDKZ",
			"CUP_O_Mi8_RU",
			"CUP_B_Mi24_D_MEV_Dynamic_CDF",
			"CUP_O_Mi24_P_Dynamic_RU",
			"CUP_O_Mi24_V_Dynamic_RU",
			"CUP_O_Ka60_Grey_RU",
			"CUP_B_Mi171Sh_ACR",
			"CUP_I_Mi24_Mk3_AAF",
			"CUP_O_Ka50_DL_RU",
			"CUP_O_Ka50_SLA",
			"CUP_O_Ka50_RU",
			"CUP_O_Ka52_RU",
			"CUP_B_AH6J_USA",
			"CUP_I_AH6J_RACS",
			"CUP_B_AH6M_USA",
			"CUP_B_CH47F_USA",
			"CUP_B_CH47F_VIV_USA",
			"CUP_O_UH1H_TKA",
			"CUP_B_UH60M_US",
			"CUP_B_UH1Y_Gunship_Dynamic_USMC",
			"CUP_B_MH60L_DAP_4x_USN",
			"CUP_B_AH64D_DL_USA",
			"CUP_B_AH1Z_Dynamic_USMC"
		};
	};
	
	class CUPPlanes
	{
		name = "CUP Самолёты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"CUP_B_MV22_USMC",
			"CUP_B_MV22_VIV_USMC"
		};
	};
	
	class CUPArmedPlanes
	{
		name = "CUP Вооруженные Самолёты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			//"CUP_B_MV22_USMC_RAMPGUN",
			//"CUP_O_Su25_Dyn_RU",
			"CUP_O_SU34_RU",
			//"CUP_B_GR9_DYN_GB",
			//"CUP_B_F35B_USMC",
			//"CUP_B_AV8B_CAP_USMC",
			//"CUP_I_AV8B_CAP_AAF",
			//"CUP_B_AV8B_MK82_USMC",
			//"CUP_I_AV8B_MK82_AAF",
			//"CUP_B_AV8B_GBU12_USMC",
			//"CUP_I_AV8B_GBU12_AAF",
			//"CUP_B_AV8B_AGM_USMC",
			//"CUP_I_AV8B_AGM_AAF",
			"CUP_B_A10_DYN_USA"
		};
	};
	
	class CUPBoats
	{
		name = "CUP Лодки";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"CUP_O_PBX_RU",
			"CUP_O_PBX_SLA",
			"CUP_C_PBX_CIV",
			//"CUP_B_MK10_GB",
			"CUP_I_LCVP_RACS",
			"CUP_I_LCVP_VIV_RACS",
			"CUP_O_LCVP_SLA",
			"CUP_O_LCVP_VIV_SLA",
			"CUP_B_RHIB_USMC",
			"CUP_I_RHIB_RACS",
			"CUP_B_RHIB2Turret_USMC",
			"CUP_I_RHIB2Turret_RACS"
			//"CUP_B_Frigate_ANZAC",
			//"CUP_I_Frigate_AAF",
			//"CUP_I_Frigate_RACS"
		};
	};