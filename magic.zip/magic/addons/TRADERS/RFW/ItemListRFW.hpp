	///////////////////////////////////////////////////////////////////////
	// Униформа
	///////////////////////////////////////////////////////////////////////
	class min_rf_emr_ghillie                      { quality = 4; price = 60; };
	class min_rf_emr_desert_ghillie               { quality = 4; price = 60; };
	class min_rf_winter_suit_hood_lite            { quality = 4; price = 60; };
	class min_rf_winter_suit_hood                 { quality = 4; price = 60; };
	class min_rf_winter_suit                      { quality = 4; price = 60; };
	class min_rf_winter_suit_officer              { quality = 4; price = 60; };
	class min_rf_helipilot_desert_overall         { quality = 4; price = 60; };
	class min_rf_helipilot_overall                { quality = 4; price = 60; };
	class min_rf_pilot_desert_overall             { quality = 4; price = 60; };
	class min_rf_pilot_overall                    { quality = 4; price = 60; };
	class min_rf_hex_officer                      { quality = 4; price = 60; };
	class min_rf_hex                              { quality = 4; price = 60; };
	class min_rf_hex_lite                         { quality = 4; price = 60; };
	class min_rf_green_hex_officer                { quality = 4; price = 60; };
	class min_rf_green_hex                        { quality = 4; price = 60; };
	class min_rf_green_hex_lite                   { quality = 4; price = 60; };
	class min_rf_izlom_officer                    { quality = 4; price = 60; };
	class min_rf_izlom                            { quality = 4; price = 60; };
	class min_rf_izlom_lite                       { quality = 4; price = 60; };
	class min_rf_flora_desert_officer             { quality = 4; price = 60; };
	class min_rf_flora_desert                     { quality = 4; price = 60; };
	class min_rf_flora_desert_lite                { quality = 4; price = 60; };
	class min_rf_surpat_officer                   { quality = 4; price = 60; };
	class min_rf_surpat                           { quality = 4; price = 60; };
	class min_rf_surpat_lite                      { quality = 4; price = 60; };
	class min_rf_urban_officer                    { quality = 4; price = 60; };
	class min_rf_urban                            { quality = 4; price = 60; };
	class min_rf_urban_lite                       { quality = 4; price = 60; };
	class min_rf_flora_officer                    { quality = 4; price = 60; };
	class min_rf_flora                            { quality = 4; price = 60; };
	class min_rf_flora_lite                       { quality = 4; price = 60; };
	class min_rf_tactical_multicam                { quality = 4; price = 60; };
	class min_rf_tactical_skol                    { quality = 4; price = 60; };
	class min_rf_tactical_surpat                  { quality = 4; price = 60; };
	class min_rf_tactical_emr                     { quality = 4; price = 60; };
	class min_rf_gorka_officer                    { quality = 4; price = 60; };
	class min_rf_gorka_hood                       { quality = 4; price = 60; };
	class min_rf_gorka_hood_lite                  { quality = 4; price = 60; };
	class min_rf_gorka                            { quality = 4; price = 60; };
	class min_rf_gorka_lite                       { quality = 4; price = 60; };
	class min_rf_klmk_officer                     { quality = 4; price = 60; };
	class min_rf_klmk_hood                        { quality = 4; price = 60; };
	class min_rf_klmk_hood_lite                   { quality = 4; price = 60; };
	class min_rf_klmk                             { quality = 4; price = 60; };
	class min_rf_klmk_lite                        { quality = 4; price = 60; };
	class min_rf_gorka_partizan_officer           { quality = 4; price = 60; };
	class min_rf_gorka_partizan_hood              { quality = 4; price = 60; };
	class min_rf_gorka_partizan_hood_lite         { quality = 4; price = 60; };
	class min_rf_gorka_partizan                   { quality = 4; price = 60; };
	class min_rf_gorka_partizan_lite              { quality = 4; price = 60; };
	class min_rf_emr_desert_officer               { quality = 4; price = 60; };
	class min_rf_emr_desert_hood                  { quality = 4; price = 60; };
	class min_rf_emr_desert_hood_lite             { quality = 4; price = 60; };
	class min_rf_emr_desert                       { quality = 4; price = 60; };
	class min_rf_emr_desert_lite                  { quality = 4; price = 60; };
	class min_rf_gorka_surpat_officer             { quality = 4; price = 60; };
	class min_rf_gorka_surpat_hood                { quality = 4; price = 60; };
	class min_rf_gorka_surpat_hood_lite           { quality = 4; price = 60; };
	class min_rf_gorka_surpat                     { quality = 4; price = 60; };
	class min_rf_gorka_surpat_lite                { quality = 4; price = 60; };
	class min_rf_emr_officer                      { quality = 4; price = 60; };
	class min_rf_emr_hood                         { quality = 4; price = 60; };
	class min_rf_emr_hood_lite                    { quality = 4; price = 60; };
	class min_rf_emr                              { quality = 4; price = 60; };
	class min_rf_emr_lite                         { quality = 4; price = 60; };
	
	///////////////////////////////////////////////////////////////////////
	// Бронежилеты
	///////////////////////////////////////////////////////////////////////
	class min_rf_armor_vest_GL_vsr                      { quality = 3; price = 70; };
	class min_rf_armor_vest_GL_green                    { quality = 3; price = 70; };
	class min_rf_armor_vest_GL_multicam                 { quality = 3; price = 70; };
	class min_rf_armor_vest_GL_surpat                   { quality = 3; price = 70; };
	class min_rf_armor_vest_GL_black                    { quality = 3; price = 70; };
	class min_rf_armor_vest_GL_flora                    { quality = 3; price = 70; };
	class min_rf_armor_vest_AR_vsr                      { quality = 3; price = 70; };
	class min_rf_armor_vest_AR_green                    { quality = 3; price = 70; };
	class min_rf_armor_vest_AR_multicam                 { quality = 3; price = 70; };
	class min_rf_armor_vest_AR_surpat                   { quality = 3; price = 70; };
	class min_rf_armor_vest_AR_black                    { quality = 3; price = 70; };
	class min_rf_armor_vest_AR_flora                    { quality = 3; price = 70; };
	class min_rf_armor_vest_M_vsr                       { quality = 3; price = 70; };
	class min_rf_armor_vest_M_green                     { quality = 3; price = 70; };
	class min_rf_armor_vest_M_multicam                  { quality = 3; price = 70; };
	class min_rf_armor_vest_M_surpat                    { quality = 3; price = 70; };
	class min_rf_armor_vest_M_black                     { quality = 3; price = 70; };
	class min_rf_armor_vest_M_flora                     { quality = 3; price = 70; };
	class min_rf_lite_vest_vsr                          { quality = 3; price = 70; };
	class min_rf_lite_vest_green                        { quality = 3; price = 70; };
	class min_rf_lite_vest_multicam                     { quality = 3; price = 70; };
	class min_rf_lite_vest_surpat                       { quality = 3; price = 70; };
	class min_rf_lite_vest_black                        { quality = 3; price = 70; };
	class min_rf_lite_vest_flora                        { quality = 3; price = 70; };
	class min_rf_lite_vest_GL_vsr                       { quality = 3; price = 70; };
	class min_rf_lite_vest_GL_green                     { quality = 3; price = 70; };
	class min_rf_lite_vest_GL_multicam                  { quality = 3; price = 70; };
	class min_rf_lite_vest_GL_surpat                    { quality = 3; price = 70; };
	class min_rf_lite_vest_GL_black                     { quality = 3; price = 70; };
	class min_rf_lite_vest_GL_flora                     { quality = 3; price = 70; };
	class min_rf_lite_vest_AR_vsr                       { quality = 3; price = 70; };
	class min_rf_lite_vest_AR_green                     { quality = 3; price = 70; };
	class min_rf_lite_vest_AR_multicam                  { quality = 3; price = 70; };
	class min_rf_lite_vest_AR_surpat                    { quality = 3; price = 70; };
	class min_rf_lite_vest_AR_black                     { quality = 3; price = 70; };
	class min_rf_lite_vest_AR_flora                     { quality = 3; price = 70; };
	class min_rf_lite_vest_M_vsr                        { quality = 3; price = 70; };
	class min_rf_lite_vest_M_green                      { quality = 3; price = 70; };
	class min_rf_lite_vest_M_multicam                   { quality = 3; price = 70; };
	class min_rf_lite_vest_M_surpat                     { quality = 3; price = 70; };
	class min_rf_lite_vest_M_black                      { quality = 3; price = 70; };
	class min_rf_lite_vest_M_flora                      { quality = 3; price = 70; };
	class min_rf_tactical_vest_vsr                      { quality = 3; price = 70; };
	class min_rf_tactical_vest_green                    { quality = 3; price = 70; };
	class min_rf_tactical_vest_multicam                 { quality = 3; price = 70; };
	class min_rf_tactical_vest_surpat                   { quality = 3; price = 70; };
	class min_rf_tactical_vest_black                    { quality = 3; price = 70; };
	class min_rf_tactical_vest_flora                    { quality = 3; price = 70; };
	class min_rf_tactical_vest_GL_vsr                   { quality = 3; price = 70; };
	class min_rf_tactical_vest_GL_green                 { quality = 3; price = 70; };
	class min_rf_tactical_vest_GL_multicam              { quality = 3; price = 70; };
	class min_rf_tactical_vest_GL_surpat                { quality = 3; price = 70; };
	class min_rf_tactical_vest_GL_black                 { quality = 3; price = 70; };
	class min_rf_tactical_vest_GL_flora                 { quality = 3; price = 70; };
	class min_rf_tactical_vest_AR_vsr                   { quality = 3; price = 70; };
	class min_rf_tactical_vest_AR_green                 { quality = 3; price = 70; };
	class min_rf_tactical_vest_AR_multicam              { quality = 3; price = 70; };
	class min_rf_tactical_vest_AR_surpat                { quality = 3; price = 70; };
	class min_rf_tactical_vest_AR_black                 { quality = 3; price = 70; };
	class min_rf_tactical_vest_AR_flora                 { quality = 3; price = 70; };
	class min_rf_tactical_vest_M_vsr                    { quality = 3; price = 70; };
	class min_rf_tactical_vest_M_green                  { quality = 3; price = 70; };
	class min_rf_tactical_vest_M_multicam               { quality = 3; price = 70; };
	class min_rf_tactical_vest_M_surpat                 { quality = 3; price = 70; };
	class min_rf_tactical_vest_M_black                  { quality = 3; price = 70; };
	class min_rf_tactical_vest_M_flora                  { quality = 3; price = 70; };
	class min_rf_armor_vest_vsr                         { quality = 3; price = 70; };
	class min_rf_armor_vest_green                       { quality = 3; price = 70; };
	class min_rf_armor_vest_multicam                    { quality = 3; price = 70; };
	class min_rf_armor_vest_surpat                      { quality = 3; price = 70; };
	class min_rf_armor_vest_black                       { quality = 3; price = 70; };
	class min_rf_armor_vest_flora                       { quality = 3; price = 70; };
	class min_rf_highcapacity_special_vsr               { quality = 3; price = 70; };
	class min_rf_highcapacity_special_green             { quality = 3; price = 70; };
	class min_rf_highcapacity_special_multicam          { quality = 3; price = 70; };
	class min_rf_highcapacity_special_surpat            { quality = 3; price = 70; };
	class min_rf_highcapacity_special_black             { quality = 3; price = 70; };
	class min_rf_highcapacity_special_flora             { quality = 3; price = 70; };
	class min_rf_highcapacity_special_GL_vsr            { quality = 3; price = 70; };
	class min_rf_highcapacity_special_GL_green          { quality = 3; price = 70; };
	class min_rf_highcapacity_special_GL_multicam       { quality = 3; price = 70; };
	class min_rf_highcapacity_special_GL_surpat         { quality = 3; price = 70; };
	class min_rf_highcapacity_special_GL_black          { quality = 3; price = 70; };
	class min_rf_highcapacity_special_GL_flora          { quality = 3; price = 70; };
	class min_rf_highcapacity_vest_vsr                  { quality = 3; price = 70; };
	class min_rf_highcapacity_vest_green                { quality = 3; price = 70; };
	class min_rf_highcapacity_vest_multicam             { quality = 3; price = 70; };
	class min_rf_highcapacity_vest_surpat               { quality = 3; price = 70; };
	class min_rf_highcapacity_vest_black                { quality = 3; price = 70; };
	class min_rf_highcapacity_vest_flora                { quality = 3; price = 70; };

	///////////////////////////////////////////////////////////////////////////////
	// Рюкзаки
	///////////////////////////////////////////////////////////////////////////////
	class min_rf_backpack_vsr               { quality = 4; price = 750; };
	class min_rf_backpack_green             { quality = 4; price = 750; };
	class min_rf_backpack_winter            { quality = 4; price = 750; };
	class min_rf_backpack_surpat            { quality = 4; price = 750; };
	class min_rf_backpack_black             { quality = 4; price = 750; };
	class min_rf_backpack_flora             { quality = 4; price = 750; };
	class min_rf_torna_vsr                  { quality = 4; price = 650; };
	class min_rf_torna_green                { quality = 4; price = 650; };
	class min_rf_torna_surpat               { quality = 4; price = 650; };
	class min_rf_torna_black                { quality = 4; price = 650; };
	class min_rf_torna_flora                { quality = 4; price = 650; };
	
	////////////////////////////////////////////////////////////////////////
	// Головные уборы|Шлемы
	////////////////////////////////////////////////////////////////////////
	class min_rf_cap_flora_desert               { quality = 1; price = 50; };
	class min_rf_cap_surpat                     { quality = 1; price = 50; };
	class min_rf_cap_flora                      { quality = 1; price = 50; };
	class min_rf_bandana_white                  { quality = 1; price = 50; };
	class min_rf_bandana_olive                  { quality = 1; price = 50; };
	class min_rf_bandana_black                  { quality = 1; price = 50; };
	class min_rf_beret_green                    { quality = 1; price = 50; };
	class min_rf_beret_red                      { quality = 1; price = 50; };
	class min_rf_helmet_para                    { quality = 2; price = 180; };
	class min_rf_cap_headphones                 { quality = 1; price = 40; };
	class min_rf_helmet_mich_hex                { quality = 2; price = 180; };
	class min_rf_helmet_mich_green_hex          { quality = 2; price = 180; };
	class min_rf_helmet_mich_urban              { quality = 2; price = 180; };
	class min_rf_headset                        { quality = 1; price = 40; };
	class min_rf_helmet_recon                   { quality = 2; price = 180; };
	class min_rf_helmet_recon_desert            { quality = 2; price = 180; };
	class min_rf_helmet_recon_black             { quality = 2; price = 180; };
	class min_rf_helmet_crew_winter             { quality = 2; price = 180; };
	class min_rf_helmet_crew_desert             { quality = 2; price = 180; };
	class min_rf_helmet_crew_surpat             { quality = 2; price = 180; };
	class min_rf_helmet_crew                    { quality = 2; price = 180; };
	class min_rf_ushanka                        { quality = 1; price = 50; };
	class min_rf_beanie_white                   { quality = 1; price = 50; };
	class min_rf_beanie_black                   { quality = 1; price = 50; };
	class min_rf_helmet_pilot                   { quality = 2; price = 180; };
	class min_rf_helmet_ace                     { quality = 2; price = 180; };
	class min_rf_hat_multicam                   { quality = 1; price = 40; };
	class min_rf_hat_flora_desert               { quality = 1; price = 40; };
	class min_rf_hat_skol                       { quality = 1; price = 40; };
	class min_rf_hat_surpat                     { quality = 1; price = 40; };
	class min_rf_hat_flora                      { quality = 1; price = 40; };
	class min_rf_helmet_soldier_winter          { quality = 2; price = 180; };
	class min_rf_helmet_soldier_izlom           { quality = 2; price = 180; };
	class min_rf_helmet_soldier_desert          { quality = 2; price = 180; };
	class min_rf_helmet_soldier_surpat          { quality = 2; price = 180; };
	class min_rf_helmet_soldier_flora           { quality = 2; price = 180; };
	
	////////////////////////////////////////////////////////////////////////
	// Защита лица
	////////////////////////////////////////////////////////////////////////
	class min_rf_balaclava_olive               { quality = 1; price = 30; };
	class min_rf_balaclava_black               { quality = 1; price = 30; };
	class min_rf_balaclava_white               { quality = 1; price = 30; };
	class min_rf_balaclava_goggles_white       { quality = 1; price = 30; };
	class min_rf_balaclava_goggles_olive       { quality = 1; price = 30; };
	class min_rf_balaclava_goggles_black       { quality = 1; price = 30; };
	class min_rf_tactical_goggles              { quality = 1; price = 20; };
	class min_rf_scarf_white                   { quality = 1; price = 20; };
	class min_rf_scarf_olive                   { quality = 1; price = 20; };
	class min_rf_scarf_desert                  { quality = 1; price = 20; };
	class min_rf_scarf_goggles_white           { quality = 1; price = 20; };
	class min_rf_scarf_goggles_olive           { quality = 1; price = 20; };
	class min_rf_scarf_goggles_desert          { quality = 1; price = 20; };
	class min_rf_scarf_goggles_black           { quality = 1; price = 20; };
	class min_rf_scarf_black                   { quality = 1; price = 20; };
	
	////////////////////////////////////////////////////////////////////////////////////////
	// Вспомогательное
	////////////////////////////////////////////////////////////////////////////////////////
	class acc_min_rf_perst_1ik                        { quality = 1; price = 8; };
	
	////////////////////////////////////////////////////////////////////////////////////////
	// Глушители
	////////////////////////////////////////////////////////////////////////////////////////
	class muzzle_min_rf_tgp_a                     { quality = 2; price = 60; sellPrice = 5; };
	class muzzle_min_rf_pbs_1                     { quality = 2; price = 60; sellPrice = 5; };
	
	////////////////////////////////////////////////////////////////////////////////////////
	// Оптика
	////////////////////////////////////////////////////////////////////////////////////////
	class optic_min_rf_1p_87                     { quality = 3; price = 80; sellPrice = 5; };
	class optic_min_rf_pkm_a                     { quality = 3; price = 80; sellPrice = 5; };
	class optic_min_rf_po_4x24_p                 { quality = 3; price = 80; sellPrice = 5; };
	class optic_min_rf_ekp_8_18                  { quality = 3; price = 80; sellPrice = 5; };
	class optic_min_rf_eotech_553                { quality = 3; price = 80; sellPrice = 5; };
	class optic_min_rf_1pn_97                    { quality = 4; price = 100; sellPrice = 5; };
	
	////////////////////////////////////////////////////////////////////////////////////////
	// Пист.пулемёт
	////////////////////////////////////////////////////////////////////////////////////////
	class SMG_min_rf_pp_2000                                  { quality = 1; price = 500; };
	
	////////////////////////////////////////////////////////////////////////////////////////
	// Пулемёты
	////////////////////////////////////////////////////////////////////////////////////////
	class LMG_min_rf_6p69_camo                                { quality = 4; price = 1500; };
	class LMG_min_rf_6p69_desert                              { quality = 4; price = 1500; };
	class LMG_min_rf_6p69                                     { quality = 4; price = 1500; };
	
    ////////////////////////////////////////////////////////////////////////////////////////
	// Автоматы
	////////////////////////////////////////////////////////////////////////////////////////
	class arifle_min_rf_ak_12_grip_winter                   { quality = 2; price = 5000; };
	class arifle_min_rf_ak_12_grip_camo                     { quality = 2; price = 5000; };
	class arifle_min_rf_ak_12_grip_desert                   { quality = 2; price = 5000; };
	class arifle_min_rf_ak_12_grip                          { quality = 2; price = 5000; };
	class arifle_min_rf_ak_12_winter                        { quality = 2; price = 5000; };
	class arifle_min_rf_ak_12_camo                          { quality = 2; price = 5000; };
	class arifle_min_rf_ak_12_desert                        { quality = 2; price = 5000; };
	class arifle_min_rf_ak_12                               { quality = 2; price = 5000; };
	class arifle_min_rf_ak_12_gp_winter                     { quality = 3; price = 6000; };
	class arifle_min_rf_ak_12_gp_camo                       { quality = 3; price = 6000; };
	class arifle_min_rf_ak_12_gp_desert                     { quality = 3; price = 6000; };
	class arifle_min_rf_ak_12_gp                            { quality = 3; price = 6000; };
	class arifle_min_rf_ash_12_camo                         { quality = 3; price = 5500; };
	class arifle_min_rf_ash_12_desert                       { quality = 3; price = 5500; };
	class arifle_min_rf_ash_12                              { quality = 3; price = 5500; };
	class arifle_min_rf_aek_a545_winter                     { quality = 2; price = 5000; };
	class arifle_min_rf_aek_a545_camo                       { quality = 2; price = 5000; };
	class arifle_min_rf_aek_a545_desert                     { quality = 2; price = 5000; };
	class arifle_min_rf_aek_a545                            { quality = 2; price = 5000; };
	
	////////////////////////////////////////////////////////////////////////////////////////
	// Снайперские винтовки
	////////////////////////////////////////////////////////////////////////////////////////
	class srifle_min_rf_vs_121_winter                        { quality = 5; price = 12000; };
	class srifle_min_rf_vs_121_camo                          { quality = 5; price = 12000; };
	class srifle_min_rf_vs_121_desert                        { quality = 5; price = 12000; };
	class srifle_min_rf_vs_121                               { quality = 5; price = 12000; };
	class srifle_min_rf_orsis_t5000_winter                   { quality = 5; price = 12000; };
	class srifle_min_rf_orsis_t5000_camo                     { quality = 5; price = 12000; };
	class srifle_min_rf_orsis_t5000_desert                   { quality = 5; price = 12000; };
	class srifle_min_rf_orsis_t5000                          { quality = 5; price = 12000; };
	
	////////////////////////////////////////////////////////////////////////////////////////
	// Патроны
	////////////////////////////////////////////////////////////////////////////////////////
	class 100Rnd_min_rf_762x54_Box                       { quality = 3; price = 100; };//патроны для пулемёта
	class 100Rnd_min_rf_762x54_T_Box                     { quality = 3; price = 100; };//патроны для пулемёта
	class 20Rnd_min_rf_127x55_Mag                        { quality = 2; price = 80; };//патроны для Автомата
	class 5Rnd_min_rf_338_Mag                            { quality = 4; price = 130; };//патроны для Снайперские винтовки
	class 20Rnd_min_rf_9x19_Mag                          { quality = 1; price = 50; };//патроны для Пист.пулемёт
	class 20Rnd_min_rf_9x19_T_Mag                        { quality = 1; price = 50; };//патроны для Пист.пулемёт

    ////////////////////////////////////////////////////////////////////////////////////////
	//  Гранатометы
	////////////////////////////////////////////////////////////////////////////////////////
	class launch_min_rf_verba                         { quality = 10; price = 10000; };
	class launch_min_rf_RPG32                         { quality = 9; price = 8000; };
	class launch_min_rf_titan_short                   { quality = 9; price = 8000; };
	
    ////////////////////////////////////////////////////////////////////////////////////////
	//  Снаряды для гранатометов
	////////////////////////////////////////////////////////////////////////////////////////
	class 1Rnd_min_rf_9M336_missiles                         { quality = 6; price = 800; };