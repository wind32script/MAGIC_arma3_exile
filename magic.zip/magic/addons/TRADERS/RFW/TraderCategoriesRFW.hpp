    class RFUniforms
	{
		name = "Russian Униформа";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\uniform_ca.paa";
		items[] = 
		{
			"min_rf_emr_ghillie",
			"min_rf_emr_desert_ghillie",
			"min_rf_winter_suit_hood_lite",
			"min_rf_winter_suit_hood",
			"min_rf_winter_suit",
			"min_rf_winter_suit_officer",
			"min_rf_helipilot_desert_overall",
			"min_rf_helipilot_overall",
			"min_rf_pilot_desert_overall",
			"min_rf_pilot_overall",
			"min_rf_hex_officer",
			"min_rf_hex",
			"min_rf_hex_lite",
			"min_rf_green_hex_officer",
			"min_rf_green_hex",
			"min_rf_green_hex_lite",
			"min_rf_izlom_officer",
			"min_rf_izlom",
			"min_rf_izlom_lite",
			"min_rf_flora_desert_officer",
			"min_rf_flora_desert",
			"min_rf_flora_desert_lite",
			"min_rf_surpat_officer",
			"min_rf_surpat",
			"min_rf_surpat_lite",
			"min_rf_urban_officer",
			"min_rf_urban",
			"min_rf_urban_lite",
			"min_rf_flora_officer",
			"min_rf_flora",
			"min_rf_flora_lite",
			"min_rf_tactical_multicam",
			"min_rf_tactical_skol",
			"min_rf_tactical_surpat",
			"min_rf_tactical_emr",
			"min_rf_gorka_officer",
			"min_rf_gorka_hood",
			"min_rf_gorka_hood_lite",
			"min_rf_gorka",
			"min_rf_gorka_lite",
			"min_rf_klmk_officer",
			"min_rf_klmk_hood",
			"min_rf_klmk_hood_lite",
			"min_rf_klmk",
			"min_rf_klmk_lite",
			"min_rf_gorka_partizan_officer",
			"min_rf_gorka_partizan_hood",
			"min_rf_gorka_partizan_hood_lite",
			"min_rf_gorka_partizan",
			"min_rf_gorka_partizan_lite",
			"min_rf_emr_desert_officer",
			"min_rf_emr_desert_hood",
			"min_rf_emr_desert_hood_lite",
			"min_rf_emr_desert",
			"min_rf_emr_desert_lite",
			"min_rf_gorka_surpat_officer",
			"min_rf_gorka_surpat_hood",
			"min_rf_gorka_surpat_hood_lite",
			"min_rf_gorka_surpat",
			"min_rf_gorka_surpat_lite",
			"min_rf_emr_officer",
			"min_rf_emr_hood",
			"min_rf_emr_hood_lite",
			"min_rf_emr",
			"min_rf_emr_lite"
		};
	};
	
	class RFVests
	{
		name = "Russian Бронежилеты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\vest_ca.paa";
		items[] = 
		{
			"min_rf_armor_vest_GL_vsr",
			"min_rf_armor_vest_GL_green",
			"min_rf_armor_vest_GL_multicam",
			"min_rf_armor_vest_GL_surpat",
			"min_rf_armor_vest_GL_black",
			"min_rf_armor_vest_GL_flora",
			"min_rf_armor_vest_AR_vsr",
			"min_rf_armor_vest_AR_green",
			"min_rf_armor_vest_AR_multicam",
			"min_rf_armor_vest_AR_surpat",
			"min_rf_armor_vest_AR_black",
			"min_rf_armor_vest_AR_flora",
			"min_rf_armor_vest_M_vsr",
			"min_rf_armor_vest_M_green",
			"min_rf_armor_vest_M_multicam",
			"min_rf_armor_vest_M_surpat",
			"min_rf_armor_vest_M_black",
			"min_rf_armor_vest_M_flora",
			"min_rf_lite_vest_vsr",
			"min_rf_lite_vest_green",
			"min_rf_lite_vest_multicam",
			"min_rf_lite_vest_surpat",
			"min_rf_lite_vest_black",
			"min_rf_lite_vest_flora",
			"min_rf_lite_vest_GL_vsr",
			"min_rf_lite_vest_GL_green",
			"min_rf_lite_vest_GL_multicam",
			"min_rf_lite_vest_GL_surpat",
			"min_rf_lite_vest_GL_black",
			"min_rf_lite_vest_GL_flora",
			"min_rf_lite_vest_AR_vsr",
			"min_rf_lite_vest_AR_green",
			"min_rf_lite_vest_AR_multicam",
			"min_rf_lite_vest_AR_surpat",
			"min_rf_lite_vest_AR_black",
			"min_rf_lite_vest_AR_flora",
			"min_rf_lite_vest_M_vsr",
			"min_rf_lite_vest_M_green",
			"min_rf_lite_vest_M_multicam",
			"min_rf_lite_vest_M_surpat",
			"min_rf_lite_vest_M_black",
			"min_rf_lite_vest_M_flora",
			"min_rf_tactical_vest_vsr",
			"min_rf_tactical_vest_green",
			"min_rf_tactical_vest_multicam",
			"min_rf_tactical_vest_surpat",
			"min_rf_tactical_vest_black",
			"min_rf_tactical_vest_flora",
			"min_rf_tactical_vest_GL_vsr",
			"min_rf_tactical_vest_GL_green",
			"min_rf_tactical_vest_GL_multicam",
			"min_rf_tactical_vest_GL_surpat",
			"min_rf_tactical_vest_GL_black",
			"min_rf_tactical_vest_GL_flora",
			"min_rf_tactical_vest_AR_vsr",
			"min_rf_tactical_vest_AR_green",
			"min_rf_tactical_vest_AR_multicam",
			"min_rf_tactical_vest_AR_surpat",
			"min_rf_tactical_vest_AR_black",
			"min_rf_tactical_vest_AR_flora",
			"min_rf_tactical_vest_M_vsr",
			"min_rf_tactical_vest_M_green",
			"min_rf_tactical_vest_M_multicam",
			"min_rf_tactical_vest_M_surpat",
			"min_rf_tactical_vest_M_black",
			"min_rf_tactical_vest_M_flora",
			"min_rf_armor_vest_vsr",
			"min_rf_armor_vest_green",
			"min_rf_armor_vest_multicam",
			"min_rf_armor_vest_surpat",
			"min_rf_armor_vest_black",
			"min_rf_armor_vest_flora",
			"min_rf_highcapacity_special_vsr",
			"min_rf_highcapacity_special_green",
			"min_rf_highcapacity_special_multicam",
			"min_rf_highcapacity_special_surpat",
			"min_rf_highcapacity_special_black",
			"min_rf_highcapacity_special_flora",
			"min_rf_highcapacity_special_GL_vsr",
			"min_rf_highcapacity_special_GL_green",
			"min_rf_highcapacity_special_GL_multicam",
			"min_rf_highcapacity_special_GL_surpat",
			"min_rf_highcapacity_special_GL_black",
			"min_rf_highcapacity_special_GL_flora",
			"min_rf_highcapacity_vest_vsr",
			"min_rf_highcapacity_vest_green",
			"min_rf_highcapacity_vest_multicam",
			"min_rf_highcapacity_vest_surpat",
			"min_rf_highcapacity_vest_black",
			"min_rf_highcapacity_vest_flora"
		};
	};
	
	class RFBackpacks
	{
		name = "Russian Рюкзаки";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\backpack_ca.paa";
		items[] = 
		{
			"min_rf_backpack_vsr",
			"min_rf_backpack_green",
			"min_rf_backpack_winter",
			"min_rf_backpack_surpat",
			"min_rf_backpack_black",
			"min_rf_backpack_flora",
			"min_rf_torna_vsr",
			"min_rf_torna_green",
			"min_rf_torna_surpat",
			"min_rf_torna_black",
			"min_rf_torna_flora"
		};
	};
	
	class RFHeadgear 
	{
		name = "Russian Головные уборы|Шлемы";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\headgear_ca.paa";
		items[] =
		{
			"min_rf_cap_flora_desert",
			"min_rf_cap_surpat",
			"min_rf_cap_flora",
			"min_rf_bandana_white",
			"min_rf_bandana_olive",
			"min_rf_bandana_black",
			"min_rf_beret_green",
			"min_rf_beret_red",
			"min_rf_helmet_para",
			"min_rf_cap_headphones",
			"min_rf_helmet_mich_hex",
			"min_rf_helmet_mich_green_hex",
			"min_rf_helmet_mich_urban",
			"min_rf_headset",
			"min_rf_helmet_recon",
			"min_rf_helmet_recon_desert",
			"min_rf_helmet_recon_black",
			"min_rf_helmet_crew_winter",
			"min_rf_helmet_crew_desert",
			"min_rf_helmet_crew_surpat",
			"min_rf_helmet_crew",
			"min_rf_ushanka",
			"min_rf_beanie_white",
			"min_rf_beanie_black",
			"min_rf_helmet_pilot",
			"min_rf_helmet_ace",
			"min_rf_hat_multicam",
			"min_rf_hat_flora_desert",
			"min_rf_hat_skol",
			"min_rf_hat_surpat",
			"min_rf_hat_flora",
			"min_rf_helmet_soldier_winter",
			"min_rf_helmet_soldier_izlom",
			"min_rf_helmet_soldier_desert",
			"min_rf_helmet_soldier_surpat",
			"min_rf_helmet_soldier_flora"
		};
	};
	
    class RFGlasses 
	{
		name = "Russian Защита лица";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\Goggles_ca.paa";
		items[] =
		{
			"min_rf_balaclava_olive",
			"min_rf_balaclava_black",
			"min_rf_balaclava_white",
			"min_rf_balaclava_goggles_white",
			"min_rf_balaclava_goggles_olive",
			"min_rf_balaclava_goggles_black",
			"min_rf_tactical_goggles",
			"min_rf_scarf_white",
			"min_rf_scarf_olive",
			"min_rf_scarf_desert",
			"min_rf_scarf_goggles_white",
			"min_rf_scarf_goggles_olive",
			"min_rf_scarf_goggles_desert",
			"min_rf_scarf_goggles_black",
			"min_rf_scarf_black"
		};
	};
	
	class RFPointerAttachments 
	{
		name = "Russian Вспомогательное";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"acc_min_rf_perst_1ik"
		};
	};
	
	class RFMuzzleAttachments 
	{
		name = "Russian Глушители";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemmuzzle_ca.paa";
		items[] = 
		{
			"muzzle_min_rf_tgp_a",
			"muzzle_min_rf_pbs_1"
		};
	};
	
	class RFOpticAttachments 
	{
		name = "Russian Оптика";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemoptic_ca.paa";
		items[] = 
		{
			"optic_min_rf_1p_87",
			"optic_min_rf_pkm_a",
			"optic_min_rf_po_4x24_p",
			"optic_min_rf_ekp_8_18",
			"optic_min_rf_eotech_553",
			"optic_min_rf_1pn_97"
		};
	};
	
	class RFSubMachineGuns 
	{
		name = "Russian Пист.пулемёты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"SMG_min_rf_pp_2000"
		};
	};
	
	class RFLightMachineGuns 
	{
		name = "Russian Пулемёты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"LMG_min_rf_6p69_camo",
			"LMG_min_rf_6p69_desert",
			"LMG_min_rf_6p69"
		};
	};
	
	class RFAssaultRifles
	{
		name = "Russian Автоматы";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"arifle_min_rf_ak_12_grip_winter",
			"arifle_min_rf_ak_12_grip_camo",
			"arifle_min_rf_ak_12_grip_desert",
			"arifle_min_rf_ak_12_grip",
			"arifle_min_rf_ak_12_winter",
			"arifle_min_rf_ak_12_camo",
			"arifle_min_rf_ak_12_desert",
			"arifle_min_rf_ak_12",
			"arifle_min_rf_ak_12_gp_winter",
			"arifle_min_rf_ak_12_gp_camo",
			"arifle_min_rf_ak_12_gp_desert",
			"arifle_min_rf_ak_12_gp",
			"arifle_min_rf_ash_12_camo",
			"arifle_min_rf_ash_12_desert",
			"arifle_min_rf_ash_12",
			"arifle_min_rf_aek_a545_winter",
			"arifle_min_rf_aek_a545_camo",
			"arifle_min_rf_aek_a545_desert",
			"arifle_min_rf_aek_a545"
		};
	};
	
	class RFSniperRifles
	{
		name = "Russian Снайперские винтовки";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
		    "srifle_min_rf_vs_121_winter",
			"srifle_min_rf_vs_121_camo",
			"srifle_min_rf_vs_121_desert",
			"srifle_min_rf_vs_121",
			"srifle_min_rf_orsis_t5000_winter",
			"srifle_min_rf_orsis_t5000_camo",
			"srifle_min_rf_orsis_t5000_desert",
			"srifle_min_rf_orsis_t5000"
		};
	};
	
	class RFAmmunition
	{
		name = "Russian Патроны";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\CargoMag_ca.paa";
		items[] = 
		{
			"100Rnd_min_rf_762x54_Box",
		    "100Rnd_min_rf_762x54_T_Box",
			"20Rnd_min_rf_127x55_Mag",
			"5Rnd_min_rf_338_Mag",
			"20Rnd_min_rf_9x19_Mag",
			"20Rnd_min_rf_9x19_T_Mag"
		};
	};
	
    class RFLaunchers
	{
		name = "Russian Гранатометы";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\cargothrow_ca.paa";
		items[] =
		{
			"launch_min_rf_verba",
		    "launch_min_rf_RPG32",
			"launch_min_rf_titan_short"
		};
	};
	
	class RFLauncherAmmo
	{
		name = "Russian Снаряды для гранатометов";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"1Rnd_min_rf_9M336_missiles"
		};
	};