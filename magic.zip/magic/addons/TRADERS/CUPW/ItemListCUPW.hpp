    ///////////////////////////////////////////////////////////////////////////////
	// Униформа
	///////////////////////////////////////////////////////////////////////////////
	class CUP_U_B_BAF_DDPM_S1_RolledUp                  { quality = 1; price = 60; };
	class CUP_U_B_BAF_DPM_S1_RolledUp                   { quality = 1; price = 60; };
	class CUP_U_B_BAF_MTP_S1_RolledUp                   { quality = 1; price = 60; };
	class CUP_U_B_BAF_MTP_S5_UnRolled                   { quality = 1; price = 60; };
	class CUP_U_B_BAF_MTP_S6_UnRolled                   { quality = 1; price = 60; };
	class CUP_U_O_CHDKZ_Bardak                          { quality = 1; price = 60; };
	class CUP_U_O_CHDKZ_Kam_04                          { quality = 1; price = 60; };
	class CUP_U_C_Citizen_02                            { quality = 1; price = 60; };
	class CUP_U_C_Citizen_01                            { quality = 1; price = 60; };
	class CUP_U_C_Citizen_04                            { quality = 1; price = 60; };
	class CUP_U_C_Fireman_01                            { quality = 1; price = 60; };
	class CUP_U_B_GER_Fleck_Ghillie                     { quality = 1; price = 60; };
	class CUP_U_B_GER_Flecktarn_2                       { quality = 1; price = 60; };
	class CUP_U_B_USMC_Ghillie_WDL                      { quality = 1; price = 60; };
	class CUP_U_I_Ghillie_Top                           { quality = 1; price = 60; };
	class CUP_U_B_USMC_MARPAT_WDL_TwoKneepads           { quality = 1; price = 60; };
	class CUP_U_C_Mechanic_01                           { quality = 1; price = 60; };
	class CUP_U_C_Rescuer_01                            { quality = 1; price = 60; };
	class CUP_U_O_Partisan_VSR_Mixed1                   { quality = 3; price = 70; };
	class CUP_U_C_Pilot_01                              { quality = 3; price = 70; };
	class CUP_U_C_Policeman_01                          { quality = 1; price = 60; };
	class CUP_U_C_Priest_01                             { quality = 1; price = 60; };
	class CUP_U_C_Profiteer_04                          { quality = 1; price = 60; };
	class CUP_U_I_RACS_Desert_2                         { quality = 1; price = 60; };
	class CUP_U_C_Rocker_01                             { quality = 1; price = 60; };
	class CUP_U_C_Rocker_03                             { quality = 1; price = 60; };
	class CUP_U_C_Rocker_02                             { quality = 1; price = 60; };
	class CUP_U_C_Rocker_04                             { quality = 1; price = 60; };
	class CUP_U_O_RUS_EMR_1_VDV                         { quality = 3; price = 70; };
	class CUP_U_O_RUS_EMR_1                             { quality = 3; price = 70; };
	class CUP_U_O_RUS_Flora_1_VDV                       { quality = 3; price = 70; };
	class CUP_U_O_RUS_Flora_1                           { quality = 3; price = 70; };
	class CUP_U_O_RUS_EMR_2_VDV                         { quality = 3; price = 70; };
	class CUP_U_O_RUS_Flora_2_VDV                       { quality = 3; price = 70; };
	class CUP_U_O_SLA_Officer_Suit                      { quality = 3; price = 70; };
	class CUP_U_O_SLA_Urban                             { quality = 3; price = 70; };
	class CUP_U_C_Suit_01                               { quality = 3; price = 70; };
	class CUP_U_O_TK_Officer                            { quality = 3; price = 70; };
	class CUP_U_B_USArmy_TwoKnee                        { quality = 3; price = 70; };
	class CUP_U_B_USArmy_UBACS                          { quality = 3; price = 70; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Бронежилеты
	///////////////////////////////////////////////////////////////////////////////
	class CUP_V_RUS_6B3_1                               { quality = 3; price = 80; };
	class CUP_V_RUS_6B3_2                               { quality = 3; price = 80; };
	class CUP_V_RUS_6B3_3                               { quality = 3; price = 80; };
	class CUP_V_B_GER_Carrier_Vest_3                    { quality = 3; price = 80; };
	class CUP_V_B_GER_Carrier_Vest_2                    { quality = 3; price = 80; };
	class CUP_V_I_Guerilla_Jacket                       { quality = 3; price = 80; };
	class CUP_V_B_Interceptor_Rifleman                  { quality = 3; price = 80; };
	class CUP_V_B_IOTV_gl                               { quality = 3; price = 80; };
	class CUP_V_B_IOTV_MG                               { quality = 3; price = 80; };
	class CUP_V_B_IOTV_Medic                            { quality = 3; price = 80; };
	class CUP_V_B_IOTV_Rifleman                         { quality = 3; price = 80; };
	class CUP_V_B_IOTV_AT                               { quality = 3; price = 80; };
	class CUP_V_B_IOTV_SL                               { quality = 3; price = 80; };
	class CUP_V_B_IOTV_tl                               { quality = 3; price = 80; };
	class CUP_V_B_RRV_DA2                               { quality = 3; price = 80; };
	class CUP_V_B_RRV_DA1                               { quality = 3; price = 80; };
	class CUP_V_B_MTV_Pouches                           { quality = 3; price = 80; };
	class CUP_V_B_MTV_PistolBlack                       { quality = 3; price = 80; };
	class CUP_V_B_MTV_Marksman                          { quality = 3; price = 80; };
	class CUP_V_B_MTV_noCB                              { quality = 3; price = 80; };
	class CUP_V_B_MTV_TL                                { quality = 3; price = 80; };
	class CUP_V_BAF_Osprey_Mk2_DDPM_Crewman             { quality = 3; price = 80; };
	class CUP_V_BAF_Osprey_Mk2_DDPM_Grenadier           { quality = 3; price = 80; };
	class CUP_V_BAF_Osprey_Mk2_DDPM_Officer             { quality = 3; price = 80; };
	class CUP_V_BAF_Osprey_Mk2_DPM_Crewman              { quality = 3; price = 80; };
	class CUP_V_BAF_Osprey_Mk2_DPM_Empty                { quality = 3; price = 80; };
	class CUP_V_BAF_Osprey_Mk2_DPM_Grenadier            { quality = 3; price = 80; };
	class CUP_V_BAF_Osprey_Mk4_MTP_Grenadier            { quality = 3; price = 80; };
	class CUP_V_B_USArmy_PilotVest                      { quality = 3; price = 80; };
	class CUP_V_B_PilotVest                             { quality = 3; price = 80; };
	class CUP_V_O_Ins_Carrier_Rig_MG                    { quality = 3; price = 80; };
	class CUP_V_OI_TKI_Jacket4_05                       { quality = 3; price = 80; };
	class CUP_V_OI_TKI_Jacket3_01                       { quality = 3; price = 80; };
	class CUP_V_OI_TKI_Jacket2_02                       { quality = 3; price = 80; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Головные уборы|Шлемы
	///////////////////////////////////////////////////////////////////////////////
	class CUP_H_RUS_6B27_NVG                           { quality = 3; price = 80; };
	class CUP_H_RUS_6B27_NVG_olive                     { quality = 3; price = 80; };
	class CUP_H_SLA_BeretRed                           { quality = 1; price = 25; };
	class CUP_H_BAF_Officer_Beret                      { quality = 1; price = 25; };
	class CUP_H_BAF_Officer_Beret_PRR_U                { quality = 1; price = 25; };
	class CUP_H_BAF_Crew_Helmet_DDPM                   { quality = 3; price = 80; };
	class CUP_H_BAF_Crew_Helmet_DPM                    { quality = 3; price = 80; };
	class CUP_H_BAF_Crew_Helmet_MTP                    { quality = 3; price = 80; };
	class CUP_H_BAF_Helmet_2_DPM                       { quality = 3; price = 80; };
	class CUP_H_BAF_Helmet_3_DDPM                      { quality = 3; price = 80; };
	class CUP_H_BAF_Helmet_3_DPM                       { quality = 3; price = 80; };
	class CUP_H_BAF_Helmet_3_MTP                       { quality = 3; price = 80; };
	class CUP_H_BAF_Helmet_Pilot                       { quality = 3; price = 80; };
	class CUP_H_RUS_Beret_Spetsnaz                     { quality = 1; price = 25; };
	class CUP_H_RUS_Beret_VDV                          { quality = 1; price = 25; };
	class CUP_H_C_Fireman_Helmet_01                    { quality = 1; price = 25; };
	class CUP_H_USArmy_HelmetMICH_earpro               { quality = 3; price = 80; };
	class CUP_H_USArmy_HelmetMICH_earpro_ess           { quality = 3; price = 80; };
	class CUP_H_USArmy_HelmetMICH_ESS                  { quality = 3; price = 80; };
	class CUP_H_USArmy_HelmetMICH_headset              { quality = 3; price = 80; };
	class CUP_H_ChDKZ_Cap                              { quality = 1; price = 25; };
	class CUP_H_C_Policecap_01                         { quality = 1; price = 25; };
	class CUP_H_PMC_PRR_Headset                        { quality = 1; price = 25; };
	class CUP_H_RACS_Beret_Blue                        { quality = 1; price = 25; };
	class CUP_H_ChDKZ_Beret                            { quality = 1; price = 25; };
	class CUP_H_SLA_Beret                              { quality = 1; price = 25; };
	class CUP_H_SLA_Helmet                             { quality = 3; price = 80; };
	class CUP_H_SLA_OfficerCap                         { quality = 1; price = 25; };
	class CUP_H_SLA_Pilot_Helmet                       { quality = 3; price = 80; };
	class CUP_H_SLA_TankerHelmet                       { quality = 1; price = 25; };
	class CUP_H_TK_Beret                               { quality = 1; price = 25; };
	class CUP_H_TKI_Lungee_01                          { quality = 1; price = 25; };
	class CUP_H_RUS_ZSH_Shield_Down                    { quality = 1; price = 25; };
	class CUP_RUS_Balaclava_blk                        { quality = 1; price = 15; };
	class CUP_RUS_Balaclava_grn                        { quality = 1; price = 15; };
	class CUP_TK_NeckScarf                             { quality = 1; price = 15; };
	class CUP_FR_NeckScarf                             { quality = 1; price = 15; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Рюкзаки
	///////////////////////////////////////////////////////////////////////////////
	class CUP_B_CivPack_WDL                        { quality = 3; price = 350; };
	class CUP_B_ACRPara_m95                        { quality = 3; price = 350; };
	class CUP_B_GER_Pack_Flecktarn                 { quality = 3; price = 350; };
	class CUP_B_GER_Pack_Tropentarn                { quality = 3; price = 350; };
	class CUP_B_HikingPack_Civ                     { quality = 3; price = 350; };
	class CUP_B_USPack_Black                       { quality = 3; price = 350; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Автоматы
	///////////////////////////////////////////////////////////////////////////////
	class CUP_arifle_CZ805_A1						{ quality = 3; price = 5000; };
	class CUP_arifle_CZ805_GL						{ quality = 3; price = 5000; };
	class CUP_arifle_CZ805_B						{ quality = 3; price = 5000; };
	class CUP_arifle_CZ805_B_GL						{ quality = 3; price = 5000; };
	class CUP_smg_EVO							    { quality = 3; price = 5000; };
	class CUP_arifle_FNFAL							{ quality = 3; price = 5000; };
	class CUP_arifle_FNFAL_railed					{ quality = 3; price = 5000; };
	class CUP_arifle_G36A							{ quality = 3; price = 5000; };
	class CUP_arifle_G36C						    { quality = 3; price = 5000; };
	class CUP_arifle_G36K							{ quality = 3; price = 5000; };
	class CUP_arifle_G36A_camo						{ quality = 3; price = 5000; };
	class CUP_arifle_G36C_camo						{ quality = 3; price = 5000; };
	class CUP_arifle_G36K_camo						{ quality = 3; price = 5000; };
	//class CUP_srifle_L129A1						{ quality = 3; price = 5000; };
	class CUP_srifle_L129A1_HG						{ quality = 3; price = 5000; };
	class CUP_arifle_L85A2							{ quality = 3; price = 5000; };
	class CUP_arifle_L85A2_G						{ quality = 3; price = 5000; };
	class CUP_arifle_L85A2_NG						{ quality = 3; price = 5000; };
	class CUP_arifle_L85A2_GL					    { quality = 3; price = 5000; };
	class CUP_arifle_L86A2					        { quality = 3; price = 5000; };
	class CUP_arifle_M16A2							{ quality = 3; price = 5000; };
	class CUP_arifle_M16A2_GL			            { quality = 3; price = 5000; };
	class CUP_arifle_M16A4_Base					    { quality = 3; price = 5000; };
	class CUP_arifle_M16A4_GL						{ quality = 3; price = 5000; };
	class CUP_arifle_M4A1_black						{ quality = 3; price = 5000; };
	class CUP_arifle_M4A1							{ quality = 3; price = 5000; };
	class CUP_arifle_M4A1_desert					{ quality = 3; price = 5000; };
	class CUP_arifle_M4A1_BUIS_GL					{ quality = 3; price = 5000; };
	class CUP_arifle_M4A1_BUIS_desert_GL			{ quality = 3; price = 5000; };
	class CUP_arifle_M4A3_desert					{ quality = 3; price = 5000; };
	class CUP_srifle_Mk12SPR						{ quality = 3; price = 5000; };
	class CUP_arifle_Mk16_CQC_SFG					{ quality = 3; price = 5000; };
	class CUP_arifle_Mk16_CQC_EGLM					{ quality = 3; price = 5000; };
	class CUP_smg_MP5A5								{ quality = 3; price = 5000; };
	class CUP_smg_MP5SD6							{ quality = 3; price = 5000; };
	class CUP_arifle_Sa58RIS1					    { quality = 3; price = 5000; };
	class CUP_arifle_Sa58RIS1_des					{ quality = 3; price = 5000; };
	class CUP_arifle_Sa58RIS2_gl					{ quality = 3; price = 5000; };
	class CUP_arifle_XM8_Carbine					{ quality = 3; price = 5000; };
	class CUP_arifle_XM8_Railed						{ quality = 3; price = 5000; };
	class CUP_arifle_XM8_Carbine_GL					{ quality = 3; price = 5000; };
	class CUP_arifle_xm8_SAW						{ quality = 3; price = 5000; };
	class CUP_arifle_AKM						    { quality = 3; price = 5000; };
	class CUP_arifle_AK107							{ quality = 3; price = 5000; };
	class CUP_arifle_AK107_GL						{ quality = 3; price = 5000; };
	class CUP_arifle_AKS_Gold					    { quality = 3; price = 5000; };
	class CUP_sgun_Saiga12K							{ quality = 3; price = 5000; };
    
	///////////////////////////////////////////////////////////////////////////////
	// Пистолеты
	///////////////////////////////////////////////////////////////////////////////
	class CUP_hgun_BallisticShield_Armed			{ quality = 2; price = 500; };
	class CUP_hgun_Compact							{ quality = 2; price = 500; };
	class CUP_hgun_Duty							    { quality = 2; price = 500; };
	class CUP_hgun_Glock17							{ quality = 2; price = 500; };
	class CUP_hgun_Colt1911						    { quality = 2; price = 500; };
	class CUP_hgun_Phantom					        { quality = 2; price = 500; };
	class CUP_hgun_M9								{ quality = 2; price = 500; };
	class CUP_hgun_PB6P9						    { quality = 2; price = 500; };
	class CUP_hgun_TaurusTracker455					{ quality = 2; price = 500; };
	class CUP_hgun_TaurusTracker455_gold			{ quality = 2; price = 500; };
	class CUP_hgun_Makarov						    { quality = 1; price = 300; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Пулемёты
	///////////////////////////////////////////////////////////////////////////////
	class CUP_lmg_minimi					{ quality = 5; price = 10000; };
	class CUP_lmg_minimi_railed				{ quality = 5; price = 10000; };
	class CUP_lmg_L110A1					{ quality = 5; price = 10000; };
	class CUP_lmg_L7A2						{ quality = 5; price = 10000; };
	class CUP_lmg_M240						{ quality = 5; price = 10000; };
	class CUP_lmg_m249_SQuantoon			{ quality = 5; price = 10000; };
	class CUP_lmg_m249_pip1					{ quality = 5; price = 10000; };
	class CUP_lmg_m249_para					{ quality = 5; price = 10000; };
	class CUP_lmg_M60E4						{ quality = 5; price = 10000; };
	class CUP_arifle_MG36					{ quality = 5; price = 10000; };
	class CUP_arifle_MG36_camo				{ quality = 5; price = 10000; };
	class CUP_lmg_Mk48_des					{ quality = 5; price = 10000; };
	class CUP_lmg_Mk48_wdl					{ quality = 5; price = 10000; };
	class CUP_lmg_UK59						{ quality = 5; price = 10000; };
	class CUP_lmg_PKM						{ quality = 5; price = 10000; };
	class CUP_lmg_Pecheneg					{ quality = 5; price = 10000; };
	class CUP_arifle_RPK74				    { quality = 5; price = 10000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Пист.пулемёты,дробовики
	///////////////////////////////////////////////////////////////////////////////
	class CUP_sgun_AA12								{ quality = 3; price = 3000; };
	class CUP_glaunch_6G30						    { quality = 3; price = 3000; };
	class CUP_sgun_M1014							{ quality = 3; price = 3000; };
	class CUP_glaunch_M32						    { quality = 3; price = 3000; };
	class CUP_glaunch_M79					        { quality = 3; price = 3000; };
	class CUP_glaunch_Mk13							{ quality = 3; price = 3000; };
	class CUP_smg_bizon								{ quality = 3; price = 3000; };
	class CUP_hgun_MicroUzi                         { quality = 3; price = 3000; };
	class CUP_hgun_SA61                             { quality = 3; price = 3000; };
	
	///////////////////////////////////////////////////////////////////////////////
	//	Снайперские винтовки
	///////////////////////////////////////////////////////////////////////////////
	class CUP_srifle_AS50							{ quality = 5; price = 12000; };
	class CUP_srifle_CZ550							{ quality = 5; price = 12000; };
	class CUP_srifle_CZ550_rail						{ quality = 5; price = 12000; };
	class CUP_srifle_CZ750							{ quality = 5; price = 12000; };
	class CUP_srifle_G22_des						{ quality = 5; price = 12000; };
	class CUP_srifle_AWM_des						{ quality = 5; price = 12000; };
	class CUP_srifle_M107_Base						{ quality = 6; price = 16000; };
	//class CUP_srifle_M110						    { quality = 4; price = 12000; };
	class CUP_srifle_M14						    { quality = 5; price = 12000; };
	//class CUP_srifle_M14_DMR						{ quality = 5; price = 12000; };
	class CUP_srifle_M40A3							{ quality = 5; price = 12000; };
	class CUP_srifle_LeeEnfield						{ quality = 5; price = 12000; };
	class CUP_srifle_LeeEnfield_rail				{ quality = 5; price = 12000; };
	class CUP_srifle_VSSVintorez					{ quality = 3; price = 12000; };
	class CUP_srifle_ksvk						    { quality = 5; price = 15000; };
	class CUP_srifle_SVD					        { quality = 3; price = 12000; };
	class CUP_srifle_SVD_des						{ quality = 3; price = 12000; };

    ///////////////////////////////////////////////////////////////////////////////
	//	Взрывчатка и т.д
	///////////////////////////////////////////////////////////////////////////////
	class CUP_HandGrenade_RGO						{ quality = 2; price = 200; };
	class CUP_HandGrenade_RGD5						{ quality = 2; price = 200; };
	class CUP_HandGrenade_L109A1_HE					{ quality = 2; price = 200; };
	class CUP_HandGrenade_L109A2_HE					{ quality = 2; price = 200; };
	class CUP_Mine_M                                { quality = 3; price = 3000; };
	class CUP_IED_V1_M                              { quality = 3; price = 3000; };
	class CUP_IED_V2_M                              { quality = 3; price = 3000; };
	class CUP_IED_V3_M                              { quality = 3; price = 3000; };
	class CUP_IED_V4_M                              { quality = 3; price = 3000; };
	class CUP_PipeBomb_M                            { quality = 3; price = 3000; };
	class CUP_TimeBomb_M                            { quality = 3; price = 3000; };
	class CUP_MineE_M                               { quality = 3; price = 3000; };

	///////////////////////////////////////////////////////////////////////////////
	//  Гранатометы
	///////////////////////////////////////////////////////////////////////////////
	class CUP_launch_M136							{ quality = 9; price = 8000; };
	class CUP_launch_MAAWS							{ quality = 9; price = 8000; };
	class CUP_launch_Mk153Mod0						{ quality = 9; price = 8000; };
	class CUP_launch_9K32Strela						{ quality = 9; price = 8000; };
	class CUP_launch_Igla							{ quality = 9; price = 8000; };
	class CUP_launch_FIM92Stinger					{ quality = 9; price = 8000; };
	class CUP_launch_Javelin						{ quality = 9; price = 8000; };
	class CUP_launch_M47							{ quality = 9; price = 8000; };
	class CUP_launch_NLAW						    { quality = 9; price = 8000; };
	class CUP_launch_Metis					        { quality = 9; price = 8000; };
	class CUP_launch_RPG18							{ quality = 8; price = 7000; };
	class CUP_launch_RPG7V							{ quality = 8; price = 7000; };
	
	///////////////////////////////////////////////////////////////////////////////
	//  Снаряды для гранатометов
	///////////////////////////////////////////////////////////////////////////////
	class CUP_M136_M                                { quality = 5; price = 2000; };
	class CUP_MAAWS_HEAT_M                          { quality = 5; price = 2000; };
	class CUP_MAAWS_HEDP_M                          { quality = 5; price = 2000; };
	class CUP_SMAW_HEAA_M                           { quality = 5; price = 2000; };
	class CUP_SMAW_HEDP_M                           { quality = 5; price = 2000; };
	class CUP_SMAW_Spotting                         { quality = 5; price = 2000; };
	class CUP_Strela_2_M                            { quality = 5; price = 2000; };
	class CUP_Igla_M                                { quality = 5; price = 2000; };
	class CUP_Stinger_M                             { quality = 5; price = 2000; };
	class CUP_Javelin_M                             { quality = 5; price = 2000; };
	class CUP_Dragon_EP1_M                          { quality = 5; price = 2000; };
	class CUP_NLAW_M                                { quality = 4; price = 2000; };
	class CUP_AT13_M                                { quality = 4; price = 2000; };
	class CUP_RPG18_M                               { quality = 4; price = 1000; };
	class CUP_PG7V_M                                { quality = 4; price = 1000; };
	class CUP_PG7VM_M                               { quality = 4; price = 1000; };
	class CUP_PG7VL_M                               { quality = 4; price = 1000; };
	class CUP_PG7VR_M                               { quality = 4; price = 1000; };
	class CUP_OG7_M                                 { quality = 4; price = 1000; };
	class CUP_TBG7V_M                               { quality = 4; price = 1000; };

    ///////////////////////////////////////////////////////////////////////////////
	//  Оптика
	///////////////////////////////////////////////////////////////////////////////
	class CUP_optic_CompM4									{ quality = 1; price = 60; sellPrice = 6; };
	class CUP_optic_AN_PAS_13c2								{ quality = 3; price = 1000; sellPrice = 50; };
	class CUP_optic_AN_PAS_13c1								{ quality = 3; price = 1000; sellPrice = 50; };
	class CUP_optic_AN_PVS_10								{ quality = 2; price = 650; sellPrice = 6; };
	class CUP_optic_AN_PVS_4								{ quality = 3; price = 1000; sellPrice = 50; };
	class CUP_optic_CWS							            { quality = 2; price = 850; sellPrice = 15; };
	class CUP_optic_Elcan								    { quality = 1; price = 60; sellPrice = 6; };
	class CUP_optic_Elcan_reflex							{ quality = 1; price = 60; sellPrice = 6; };
	class CUP_optic_ElcanM145								{ quality = 1; price = 250; sellPrice = 15; };
	class CUP_optic_ELCAN_SpecterDR							{ quality = 1; price = 250; sellPrice = 15; };
	class CUP_optic_Eotech533Grey							{ quality = 1; price = 60; sellPrice = 6; };
	class CUP_optic_Eotech533								{ quality = 1; price = 60; sellPrice = 6; };
	class CUP_optic_LeupoldMk4								{ quality = 1; price = 350; sellPrice = 25; };
	class CUP_optic_LeupoldMk4_10x40_LRT_Desert				{ quality = 1; price = 350; sellPrice = 25; };
	class CUP_optic_LeupoldM3LR								{ quality = 1; price = 250; sellPrice = 15; };
	class CUP_optic_LeupoldMk4_CQ_T							{ quality = 1; price = 60; sellPrice = 6; };
	class CUP_optic_LeupoldMk4_MRT_tan						{ quality = 1; price = 200; sellPrice = 10; };
	class CUP_optic_Leupold_VX3								{ quality = 1; price = 250; sellPrice = 15; };
	class CUP_optic_CompM2_Black							{ quality = 1; price = 60; sellPrice = 6; };
	class CUP_optic_MRad								    { quality = 1; price = 60; sellPrice = 6; };
	class CUP_optic_ZDDot							        { quality = 1; price = 60; sellPrice = 6; };
	class CUP_optic_SB_11_4x20_PM							{ quality = 1; price = 60; sellPrice = 6; };
	class CUP_optic_SB_3_12x50_PMII						    { quality = 1; price = 350; sellPrice = 25; };
	class CUP_optic_SUSAT							        { quality = 1; price = 60; sellPrice = 6; };
	class CUP_optic_RCO										{ quality = 1; price = 60; sellPrice = 6; };
	class CUP_optic_ACOG								    { quality = 1; price = 60; sellPrice = 6; };
	class CUP_optic_TrijiconRx01_black						{ quality = 1; price = 60; sellPrice = 6; };
	class CUP_optic_Kobra				                    { quality = 1; price = 60; sellPrice = 6; };
	class CUP_optic_NSPU			                        { quality = 1; price = 60; sellPrice = 6; };
	class CUP_optic_PSO_1								    { quality = 1; price = 60; sellPrice = 6; };
	class CUP_optic_PSO_3							        { quality = 1; price = 60; sellPrice = 6; };
	class CUP_optic_GOSHAWK							        { quality = 1; price = 60; sellPrice = 6; };
	class CUP_optic_PechenegScope							{ quality = 1; price = 60; sellPrice = 6; };
	class CUP_SVD_camo_d						            { quality = 1; price = 60; sellPrice = 6; };
	class CUP_SVD_camo_g							        { quality = 1; price = 60; sellPrice = 6; };
	class CUP_optic_MAAWS_Scope                             { quality = 1; price = 60; sellPrice = 6; };
	class CUP_optic_HoloBlack                               { quality = 1; price = 60; sellPrice = 6; };
	class CUP_optic_SMAW_Scope                              { quality = 1; price = 60; sellPrice = 6; };
	class CUP_optic_NSPU_RPG                                { quality = 1; price = 60; sellPrice = 6; };
	class CUP_optic_PGO7V                                   { quality = 1; price = 60; sellPrice = 6; };
	class CUP_optic_PGO7V2                                  { quality = 1; price = 60; sellPrice = 6; };
	class CUP_optic_PGO7V3                                  { quality = 1; price = 60; sellPrice = 6; };

    ///////////////////////////////////////////////////////////////////////////////
	//  Глушители
	///////////////////////////////////////////////////////////////////////////////
	class CUP_muzzle_snds_M9						{ quality = 1; price = 75; sellPrice = 5; };
	class CUP_muzzle_snds_AWM						{ quality = 1; price = 75; sellPrice = 5; };
	class CUP_muzzle_snds_G36_black					{ quality = 1; price = 75; sellPrice = 5; };
	class CUP_muzzle_snds_G36_desert			    { quality = 1; price = 75; sellPrice = 5; };
	class CUP_acc_bfa								{ quality = 1; price = 75; sellPrice = 5; };
	class CUP_muzzle_snds_L85						{ quality = 1; price = 75; sellPrice = 5; };
	class CUP_acc_sffh								{ quality = 1; price = 75; sellPrice = 5; };
	class CUP_muzzle_snds_M110					    { quality = 1; price = 75; sellPrice = 5; };
	class CUP_muzzle_snds_M14						{ quality = 1; price = 75; sellPrice = 5; };
	class CUP_muzzle_snds_M16						{ quality = 1; price = 75; sellPrice = 5; };
	class CUP_muzzle_snds_M16_camo					{ quality = 1; price = 75; sellPrice = 5; };
	class CUP_muzzle_mfsup_SCAR_L					{ quality = 1; price = 75; sellPrice = 5; };
	class CUP_muzzle_snds_SCAR_L					{ quality = 1; price = 75; sellPrice = 5; };
	class CUP_muzzle_snds_SCAR_H					{ quality = 1; price = 75; sellPrice = 5; };
	class CUP_muzzle_Bizon							{ quality = 1; price = 75; sellPrice = 5; };
	class CUP_muzzle_snds_XM8						{ quality = 1; price = 75; sellPrice = 5; };
	class CUP_muzzle_PBS4							{ quality = 1; price = 75; sellPrice = 5; };

    ///////////////////////////////////////////////////////////////////////////////
	//  Патроны
	///////////////////////////////////////////////////////////////////////////////
	class CUP_20Rnd_B_AA12_Pellets							{ quality = 1; price = 55; };
	class CUP_20Rnd_B_AA12_74Slug							{ quality = 1; price = 55; };
	class CUP_20Rnd_B_AA12_HE								{ quality = 1; price = 55; };
	class CUP_6Rnd_HE_GP25_M							    { quality = 1; price = 55; };
	class CUP_5Rnd_127x99_as50_M							{ quality = 1; price = 55; };
	class CUP_15Rnd_9x19_M9									{ quality = 1; price = 55; };
	class CUP_5x_22_LR_17_HMR_M								{ quality = 1; price = 55; };
	class CUP_10Rnd_762x51_CZ750_Tracer						{ quality = 1; price = 55; };
	class CUP_10Rnd_762x51_CZ750							{ quality = 1; price = 55; };
	class CUP_30Rnd_556x45_Stanag							{ quality = 1; price = 55; };
	class CUP_30Rnd_556x45_G36								{ quality = 1; price = 55; };
	class CUP_30Rnd_TE1_Red_Tracer_556x45_G36			    { quality = 1; price = 55; };
	class CUP_30Rnd_TE1_Green_Tracer_556x45_G36				{ quality = 1; price = 55; };
	class CUP_30Rnd_TE1_Yellow_Tracer_556x45_G36			{ quality = 1; price = 55; };
	class CUP_100Rnd_556x45_BetaCMag						{ quality = 3; price = 55; };
	class CUP_100Rnd_TE1_Red_Tracer_556x45_BetaCMag			{ quality = 3; price = 55; };
	class CUP_100Rnd_TE1_Green_Tracer_556x45_BetaCMag		{ quality = 3; price = 55; };
	class CUP_100Rnd_TE1_Yellow_Tracer_556x45_BetaCMag		{ quality = 3; price = 55; };
	class CUP_20Rnd_556x45_Stanag							{ quality = 1; price = 55; };
	class CUP_20Rnd_762x51_CZ805B							{ quality = 1; price = 55; };
	class CUP_20Rnd_TE1_Yellow_Tracer_762x51_CZ805B			{ quality = 1; price = 55; };
	class CUP_20Rnd_TE1_Red_Tracer_762x51_CZ805B			{ quality = 1; price = 55; };
	class CUP_20Rnd_TE1_Green_Tracer_762x51_CZ805B			{ quality = 1; price = 55; };
	class CUP_20Rnd_TE1_White_Tracer_762x51_CZ805B			{ quality = 1; price = 55; };
	class CUP_30Rnd_9x19_EVO								{ quality = 1; price = 55; };
	class CUP_20Rnd_762x51_FNFAL_M							{ quality = 1; price = 55; };
	class CUP_200Rnd_TE4_Red_Tracer_556x45_M249				{ quality = 3; price = 80; };
	class CUP_200Rnd_TE4_Yellow_Tracer_556x45_M249			{ quality = 3; price = 80; };
	class CUP_200Rnd_TE4_Green_Tracer_556x45_M249			{ quality = 3; price = 80; };
	class CUP_200Rnd_TE1_Red_Tracer_556x45_M249				{ quality = 3; price = 80; };
	class CUP_100Rnd_TE4_Green_Tracer_556x45_M249			{ quality = 3; price = 80; };
	class CUP_100Rnd_TE4_Red_Tracer_556x45_M249				{ quality = 3; price = 80; };
	class CUP_100Rnd_TE4_Yellow_Tracer_556x45_M249			{ quality = 3; price = 80; };
	class CUP_200Rnd_TE4_Green_Tracer_556x45_L110A1			{ quality = 3; price = 80; };
	class CUP_200Rnd_TE4_Red_Tracer_556x45_L110A1			{ quality = 3; price = 80; };
	class CUP_200Rnd_TE4_Yellow_Tracer_556x45_L110A1		{ quality = 3; price = 80; };
	class CUP_5Rnd_762x67_G22							    { quality = 1; price = 55; };
	class CUP_20Rnd_762x51_L129_M                           { quality = 1; price = 55; };
	class CUP_100Rnd_TE4_LRT4_White_Tracer_762x51_Belt_M	{ quality = 1; price = 55; };
	class CUP_100Rnd_TE4_LRT4_Red_Tracer_762x51_Belt_M		{ quality = 1; price = 55; };
	class CUP_8Rnd_B_Beneli_74Slug				            { quality = 1; price = 25; };
	class CUP_8Rnd_B_Beneli_74Pellets			            { quality = 1; price = 25; };
	class CUP_10Rnd_127x99_M107				                { quality = 6; price = 155; };
	class CUP_20Rnd_762x51_B_M110			                { quality = 6; price = 155; };
	class CUP_20Rnd_TE1_Yellow_Tracer_762x51_M110			{ quality = 1; price = 55; };
	class CUP_20Rnd_TE1_Red_Tracer_762x51_M110			    { quality = 1; price = 55; };
	class CUP_20Rnd_TE1_Green_Tracer_762x51_M110		    { quality = 1; price = 55; };
	class CUP_20Rnd_TE1_White_Tracer_762x51_M110			{ quality = 1; price = 55; }; 
	class CUP_20Rnd_762x51_DMR							    { quality = 1; price = 55; };
	class CUP_20Rnd_TE1_Yellow_Tracer_762x51_DMR			{ quality = 1; price = 55; };
	class CUP_20Rnd_TE1_Red_Tracer_762x51_DMR				{ quality = 1; price = 55; };
	class CUP_20Rnd_TE1_Green_Tracer_762x51_DMR				{ quality = 1; price = 55; };
	class CUP_20Rnd_TE1_White_Tracer_762x51_DMR				{ quality = 1; price = 55; };
	class CUP_6Rnd_FlareWhite_M203							{ quality = 1; price = 55; };
	class CUP_6Rnd_FlareGreen_M203							{ quality = 1; price = 55; };
	class CUP_6Rnd_FlareRed_M203							{ quality = 1; price = 55; };
	class CUP_6Rnd_FlareYellow_M203							{ quality = 1; price = 55; };
	class CUP_6Rnd_Smoke_M203							    { quality = 1; price = 55; };
	class CUP_6Rnd_SmokeRed_M203						    { quality = 1; price = 55; };
	class CUP_6Rnd_SmokeGreen_M203						    { quality = 1; price = 55; };
	class CUP_6Rnd_SmokeYellow_M203							{ quality = 1; price = 55; };
	class CUP_5Rnd_762x51_M24								{ quality = 1; price = 55; };
	class CUP_30Rnd_9x19_MP5								{ quality = 1; price = 55; };
	class CUP_30Rnd_Sa58_M_TracerG							{ quality = 1; price = 55; };
	class CUP_30Rnd_Sa58_M_TracerR							{ quality = 1; price = 55; };
	class CUP_30Rnd_Sa58_M_TracerY			                { quality = 1; price = 55; };
	class CUP_30Rnd_Sa58_M				                    { quality = 1; price = 55; };
	class CUP_10x_303_M			                            { quality = 1; price = 55; };
	class CUP_50Rnd_UK59_762x54R_Tracer			            { quality = 1; price = 55; };
	class CUP_30Rnd_762x39_AK47_M							{ quality = 1; price = 55; };
	class CUP_30Rnd_545x39_AK_M							    { quality = 1; price = 55; };
	class CUP_30Rnd_Subsonic_545x39_AK_M				 	{ quality = 1; price = 55; };
	class CUP_30Rnd_TE1_Green_Tracer_545x39_AK_M			{ quality = 1; price = 55; };
	class CUP_30Rnd_TE1_Red_Tracer_545x39_AK_M				{ quality = 1; price = 55; };
	class CUP_30Rnd_TE1_White_Tracer_545x39_AK_M			{ quality = 1; price = 55; };
	class CUP_30Rnd_TE1_Yellow_Tracer_545x39_AK_M			{ quality = 1; price = 55; };
	class CUP_45Rnd_TE4_LRT4_Green_Tracer_545x39_RPK_M		{ quality = 1; price = 55; };
	class CUP_IlumFlareWhite_GP25_M			                { quality = 1; price = 55; };
	class CUP_IlumFlareRed_GP25_M			                { quality = 1; price = 55; };
	class CUP_IlumFlareGreen_GP25_M		                    { quality = 1; price = 55; };
	class CUP_1Rnd_HE_GP25_M							    { quality = 1; price = 55; };
	class CUP_FlareWhite_GP25_M							    { quality = 1; price = 55; };
	class CUP_FlareGreen_GP25_M								{ quality = 1; price = 55; };
	class CUP_FlareRed_GP25_M				                { quality = 1; price = 55; };
	class CUP_FlareYellow_GP25_M				            { quality = 1; price = 55; };
	class CUP_1Rnd_SMOKE_GP25_M			                    { quality = 1; price = 55; };
	class CUP_1Rnd_SmokeRed_GP25_M						    { quality = 1; price = 55; };
	class CUP_1Rnd_SmokeGreen_GP25_M			            { quality = 1; price = 55; };
	class CUP_1Rnd_SmokeYellow_GP25_M		                { quality = 1; price = 55; };
	class CUP_10Rnd_9x39_SP5_VSS_M		                    { quality = 3; price = 80; };
	class CUP_20Rnd_9x39_SP5_VSS_M							{ quality = 3; price = 80; };
	class CUP_5Rnd_127x108_KSVK_M							{ quality = 6; price = 155; };
	class CUP_100Rnd_TE4_LRT4_762x54_PK_Tracer_Green_M		{ quality = 1; price = 55; };
	class CUP_64Rnd_9x19_Bizon_M			                { quality = 1; price = 55; };
	class CUP_64Rnd_Green_Tracer_9x19_Bizon_M			    { quality = 1; price = 55; };
	class CUP_64Rnd_Red_Tracer_9x19_Bizon_M			        { quality = 1; price = 55; };
	class CUP_64Rnd_White_Tracer_9x19_Bizon_M				{ quality = 1; price = 55; };
	class CUP_64Rnd_Yellow_Tracer_9x19_Bizon_M			    { quality = 1; price = 55; };
	class CUP_8Rnd_B_Saiga12_74Slug_M				        { quality = 1; price = 55; };
	class CUP_8Rnd_B_Saiga12_74Pellets_M                    { quality = 1; price = 55; };
	class CUP_10Rnd_762x54_SVD_M				            { quality = 1; price = 55; };
	class CUP_10Rnd_9x19_Compact							{ quality = 1; price = 25; };
	class CUP_18Rnd_9x19_Phantom                            { quality = 1; price = 25; };
	class CUP_17Rnd_9x19_glock17							{ quality = 1; price = 25; };
	class CUP_7Rnd_45ACP_1911							    { quality = 1; price = 25; };
	class CUP_8Rnd_9x18_Makarov_M							{ quality = 1; price = 25; };
	class CUP_6Rnd_45ACP_M							        { quality = 1; price = 25; };
	class CUP_8Rnd_9x18_MakarovSD_M			                { quality = 1; price = 25; };
	class CUP_30Rnd_9x19_UZI			                    { quality = 1; price = 55; };
	class CUP_20Rnd_B_765x17_Ball_M			                { quality = 1; price = 55; };
	class CUP_5Rnd_86x70_L115A1                             { quality = 1; price = 55; }; 