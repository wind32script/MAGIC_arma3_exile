    class CUPPointerAttachments 
	{
		name = "CUP Вспомогательное";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
		//not used from the items list
		};
	};
	
	class CUPUniforms
	{
		name = "CUP Униформа";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\uniform_ca.paa";
		items[] = 
		{
			"CUP_U_B_BAF_DDPM_S1_RolledUp",
			"CUP_U_B_BAF_DPM_S1_RolledUp",
			"CUP_U_B_BAF_MTP_S1_RolledUp",
			"CUP_U_B_BAF_MTP_S5_UnRolled",
			"CUP_U_B_BAF_MTP_S6_UnRolled",
			"CUP_U_O_CHDKZ_Bardak",
			"CUP_U_O_CHDKZ_Kam_04",
			"CUP_U_C_Citizen_02",
			"CUP_U_C_Citizen_01",
			"CUP_U_C_Citizen_04",
			"CUP_U_C_Fireman_01",
			"CUP_U_B_GER_Fleck_Ghillie",
			"CUP_U_B_GER_Flecktarn_2",
			"CUP_U_B_USMC_Ghillie_WDL",
			"CUP_U_I_Ghillie_Top",
			"CUP_U_B_USMC_MARPAT_WDL_TwoKneepads",
			"CUP_U_C_Mechanic_01",
			"CUP_U_C_Rescuer_01",
			"CUP_U_O_Partisan_VSR_Mixed1",
			"CUP_U_C_Pilot_01",
			"CUP_U_C_Policeman_01",
			"CUP_U_C_Priest_01",
			"CUP_U_C_Profiteer_04",
			"CUP_U_I_RACS_Desert_2",
			"CUP_U_C_Rocker_01",
			"CUP_U_C_Rocker_03",
			"CUP_U_C_Rocker_02",
			"CUP_U_C_Rocker_04",
			"CUP_U_O_RUS_EMR_1_VDV",
			"CUP_U_O_RUS_EMR_1",
			"CUP_U_O_RUS_Flora_1_VDV",
			"CUP_U_O_RUS_Flora_1",
			"CUP_U_O_RUS_EMR_2_VDV",
			"CUP_U_O_RUS_Flora_2_VDV",
			"CUP_U_O_SLA_Officer_Suit",
			"CUP_U_O_SLA_Urban",
	        "CUP_U_C_Suit_01",
			"CUP_U_O_TK_Officer",
			"CUP_U_B_USArmy_TwoKnee",
			"CUP_U_B_USArmy_UBACS"
		};
	};
	
	class CUPVests
	{
		name = "CUP Бронежилеты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\vest_ca.paa";
		items[] = 
		{
			"CUP_V_RUS_6B3_1",
			"CUP_V_RUS_6B3_2",
			"CUP_V_RUS_6B3_3",
			"CUP_V_B_GER_Carrier_Vest_3",
			"CUP_V_B_GER_Carrier_Vest_2",
			"CUP_V_I_Guerilla_Jacket",
			"CUP_V_B_Interceptor_Rifleman",
			"CUP_V_B_IOTV_gl",
			"CUP_V_B_IOTV_MG",
			"CUP_V_B_IOTV_Medic",
			"CUP_V_B_IOTV_Rifleman",
			"CUP_V_B_IOTV_AT",
			"CUP_V_B_IOTV_SL",
			"CUP_V_B_IOTV_tl",
			"CUP_V_B_RRV_DA2",
			"CUP_V_B_RRV_DA1",
			"CUP_V_B_MTV_Pouches",
			"CUP_V_B_MTV_PistolBlack",
			"CUP_V_B_MTV_Marksman",
			"CUP_V_B_MTV_noCB",
			"CUP_V_B_MTV_TL",
			"CUP_V_BAF_Osprey_Mk2_DDPM_Crewman",
			"CUP_V_BAF_Osprey_Mk2_DDPM_Grenadier",
			"CUP_V_BAF_Osprey_Mk2_DDPM_Officer",
			"CUP_V_BAF_Osprey_Mk2_DPM_Crewman",
			"CUP_V_BAF_Osprey_Mk2_DPM_Empty",
			"CUP_V_BAF_Osprey_Mk2_DPM_Grenadier",
			"CUP_V_BAF_Osprey_Mk4_MTP_Grenadier",
			"CUP_V_B_USArmy_PilotVest",
			"CUP_V_B_PilotVest",
			"CUP_V_O_Ins_Carrier_Rig_MG",
			"CUP_V_OI_TKI_Jacket4_05",
			"CUP_V_OI_TKI_Jacket3_01",
			"CUP_V_OI_TKI_Jacket2_02"
		};
	};
	
	class CUPHeadgear
	{
		name = "CUP Головные уборы";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\headgear_ca.paa";
		items[] =
		{
			"CUP_H_RUS_6B27_NVG",
			"CUP_H_RUS_6B27_NVG_olive",
			"CUP_H_SLA_BeretRed",
			"CUP_H_BAF_Officer_Beret",
			"CUP_H_BAF_Officer_Beret_PRR_U",
			"CUP_H_BAF_Crew_Helmet_DDPM",
			"CUP_H_BAF_Crew_Helmet_DPM",
			"CUP_H_BAF_Crew_Helmet_MTP",
			"CUP_H_BAF_Helmet_2_DPM",
			"CUP_H_BAF_Helmet_3_DDPM",
			"CUP_H_BAF_Helmet_3_DPM",
			"CUP_H_BAF_Helmet_3_MTP",
			"CUP_H_BAF_Helmet_Pilot",
			"CUP_H_RUS_Beret_Spetsnaz",
	        "CUP_H_RUS_Beret_VDV",
			"CUP_H_C_Fireman_Helmet_01",
			"CUP_H_USArmy_HelmetMICH_earpro",
			"CUP_H_USArmy_HelmetMICH_earpro_ess",
			"CUP_H_USArmy_HelmetMICH_ESS",
			"CUP_H_USArmy_HelmetMICH_headset",
			"CUP_H_ChDKZ_Cap",
			"CUP_H_C_Policecap_01",
			"CUP_H_PMC_PRR_Headset",
			"CUP_H_RACS_Beret_Blue",
			"CUP_H_ChDKZ_Beret",
			"CUP_H_SLA_Beret",
			"CUP_H_SLA_Helmet",
			"CUP_H_SLA_OfficerCap",
			"CUP_H_SLA_Pilot_Helmet",
			"CUP_H_SLA_TankerHelmet",
			"CUP_H_TK_Beret",
			"CUP_H_TKI_Lungee_01",
			"CUP_H_RUS_ZSH_Shield_Down",
			"CUP_RUS_Balaclava_blk",
			"CUP_RUS_Balaclava_grn",
			"CUP_TK_NeckScarf",
			"CUP_FR_NeckScarf"
		};
	};
	
	class CUPBackpacks
	{
		name = "CUP Рюкзаки";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\backpack_ca.paa";
		items[] = 
		{
			"CUP_B_CivPack_WDL",
			"CUP_B_ACRPara_m95",
			"CUP_B_GER_Pack_Flecktarn",
			"CUP_B_GER_Pack_Tropentarn",
			"CUP_B_HikingPack_Civ",
			"CUP_B_USPack_Black"
		};
	};
	
	class CUPMuzzleAttachments 
	{
		name = "CUP Глушители";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemmuzzle_ca.paa";
		items[] = 
		{
            "CUP_muzzle_snds_M9",
            "CUP_muzzle_snds_AWM",
            "CUP_muzzle_snds_G36_black",
            "CUP_muzzle_snds_G36_desert",
            "CUP_acc_bfa",
            "CUP_muzzle_snds_L85",
            "CUP_acc_sffh",
            "CUP_muzzle_snds_M110",
            "CUP_muzzle_snds_M14",
            "CUP_muzzle_snds_M16",
            "CUP_muzzle_snds_M16_camo",
            "CUP_muzzle_mfsup_SCAR_L",
            "CUP_muzzle_snds_SCAR_L",
            "CUP_muzzle_snds_SCAR_H",
            "CUP_muzzle_Bizon",
            "CUP_muzzle_snds_XM8",
            "CUP_muzzle_PBS4"
		};
	};

	class CUPOpticAttachments 
	{
		name = "CUP Оптика";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemoptic_ca.paa";
		items[] = 
		{
            "CUP_optic_CompM4",
            "CUP_optic_AN_PAS_13c2",
            "CUP_optic_AN_PAS_13c1",
            "CUP_optic_AN_PVS_10",
            "CUP_optic_AN_PVS_4",
            "CUP_optic_CWS",
            "CUP_optic_Elcan",
            "CUP_optic_Elcan_reflex",
            "CUP_optic_ElcanM145",
            "CUP_optic_ELCAN_SpecterDR",
            "CUP_optic_Eotech533Grey",
            "CUP_optic_Eotech533",
            "CUP_optic_LeupoldMk4",
            "CUP_optic_LeupoldMk4_10x40_LRT_Desert",
            "CUP_optic_LeupoldM3LR",
            "CUP_optic_LeupoldMk4_CQ_T",
            "CUP_optic_LeupoldMk4_MRT_tan",
            "CUP_optic_Leupold_VX3",
            "CUP_optic_CompM2_Black",
            "CUP_optic_MRad",
            "CUP_optic_ZDDot",
            "CUP_optic_SB_11_4x20_PM",
            "CUP_optic_SB_3_12x50_PMII",
            "CUP_optic_SUSAT",
            "CUP_optic_RCO",
            "CUP_optic_ACOG",
            "CUP_optic_TrijiconRx01_black",
            "CUP_optic_Kobra",
            "CUP_optic_NSPU",
            "CUP_optic_PSO_1",
            "CUP_optic_PSO_3",
            "CUP_optic_GOSHAWK",
            "CUP_optic_PechenegScope",
            "CUP_SVD_camo_d",
            "CUP_SVD_camo_g",
			"CUP_optic_MAAWS_Scope",
			"CUP_optic_HoloBlack",
			"CUP_optic_SMAW_Scope",
			"CUP_optic_NSPU_RPG",
			"CUP_optic_PGO7V",
			"CUP_optic_PGO7V2",
			"CUP_optic_PGO7V3"
		};
	};

	class CUPAmmunition
	{
		name = "CUP Патроны";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"CUP_20Rnd_B_AA12_Pellets",
            "CUP_20Rnd_B_AA12_74Slug", 
            "CUP_20Rnd_B_AA12_HE",
            "CUP_6Rnd_HE_GP25_M",
            "CUP_1Rnd_HE_GP25_M",
            "CUP_IlumFlareWhite_GP25_M",
            "CUP_IlumFlareRed_GP25_M",
            "CUP_IlumFlareGreen_GP25_M",
            "CUP_FlareWhite_GP25_M",
            "CUP_FlareGreen_GP25_M",
            "CUP_FlareRed_GP25_M",
            "CUP_FlareYellow_GP25_M",
            "CUP_1Rnd_SMOKE_GP25_M",
            "CUP_1Rnd_SmokeRed_GP25_M",
            "CUP_1Rnd_SmokeGreen_GP25_M",
            "CUP_5Rnd_127x99_as50_M",
            "CUP_15Rnd_9x19_M9",
            "CUP_5x_22_LR_17_HMR_M",
            "CUP_10Rnd_762x51_CZ750_Tracer",
            "CUP_10Rnd_762x51_CZ750",
            "CUP_30Rnd_556x45_Stanag",
            "CUP_30Rnd_556x45_G36",
            "CUP_30Rnd_TE1_Red_Tracer_556x45_G36",
            "CUP_30Rnd_TE1_Green_Tracer_556x45_G36",
            "CUP_30Rnd_TE1_Yellow_Tracer_556x45_G36",
            "CUP_100Rnd_556x45_BetaCMag",
            "CUP_100Rnd_TE1_Red_Tracer_556x45_BetaCMag",
            "CUP_100Rnd_TE1_Green_Tracer_556x45_BetaCMag",
            "CUP_100Rnd_TE1_Yellow_Tracer_556x45_BetaCMag",
            "CUP_20Rnd_556x45_Stanag",
            "CUP_20Rnd_762x51_CZ805B",
            "CUP_20Rnd_TE1_Yellow_Tracer_762x51_CZ805B",
            "CUP_20Rnd_TE1_Red_Tracer_762x51_CZ805B",
            "CUP_20Rnd_TE1_Green_Tracer_762x51_CZ805B",
            "CUP_20Rnd_TE1_White_Tracer_762x51_CZ805B",
            "CUP_30Rnd_9x19_EVO",
            "CUP_20Rnd_762x51_FNFAL_M",
            "CUP_200Rnd_TE4_Red_Tracer_556x45_M249",
            "CUP_200Rnd_TE4_Yellow_Tracer_556x45_M249",
            "CUP_200Rnd_TE4_Green_Tracer_556x45_M249",
            "CUP_200Rnd_TE1_Red_Tracer_556x45_M249",
            "CUP_100Rnd_TE4_Green_Tracer_556x45_M249",
            "CUP_100Rnd_TE4_Red_Tracer_556x45_M249",
            "CUP_100Rnd_TE4_Yellow_Tracer_556x45_M249",
            "CUP_200Rnd_TE4_Green_Tracer_556x45_L110A1",
            "CUP_200Rnd_TE4_Red_Tracer_556x45_L110A1",
            "CUP_200Rnd_TE4_Yellow_Tracer_556x45_L110A1",
            "CUP_5Rnd_762x67_G22",
            "CUP_20Rnd_762x51_L129_M",
            "CUP_100Rnd_TE4_LRT4_White_Tracer_762x51_Belt_M",
            "CUP_100Rnd_TE4_LRT4_Red_Tracer_762x51_Belt_M",
            "CUP_8Rnd_B_Beneli_74Slug",
            "CUP_8Rnd_B_Beneli_74Pellets",
            "CUP_10Rnd_127x99_M107",
            "CUP_20Rnd_762x51_B_M110",
            "CUP_20Rnd_TE1_Yellow_Tracer_762x51_M110",
            "CUP_20Rnd_TE1_Red_Tracer_762x51_M110",
            "CUP_20Rnd_TE1_Green_Tracer_762x51_M110",
            "CUP_20Rnd_TE1_White_Tracer_762x51_M110",
            "CUP_20Rnd_762x51_DMR",
            "CUP_20Rnd_TE1_Yellow_Tracer_762x51_DMR",
            "CUP_20Rnd_TE1_Red_Tracer_762x51_DMR",
            "CUP_20Rnd_TE1_Green_Tracer_762x51_DMR",
            "CUP_20Rnd_TE1_White_Tracer_762x51_DMR",
            "CUP_6Rnd_FlareWhite_M203",
            "CUP_6Rnd_FlareGreen_M203",
            "CUP_6Rnd_FlareRed_M203",
            "CUP_6Rnd_FlareYellow_M203",
            "CUP_6Rnd_Smoke_M203",
            "CUP_6Rnd_SmokeRed_M203",
            "CUP_6Rnd_SmokeGreen_M203",
            "CUP_6Rnd_SmokeYellow_M203",
            "CUP_5Rnd_762x51_M24",
            "CUP_30Rnd_9x19_MP5",
            "CUP_30Rnd_Sa58_M_TracerG",
            "CUP_30Rnd_Sa58_M_TracerR",
            "CUP_30Rnd_Sa58_M_TracerY",
            "CUP_30Rnd_Sa58_M",
            "CUP_10x_303_M",
            "CUP_50Rnd_UK59_762x54R_Tracer",
            "CUP_30Rnd_762x39_AK47_M",
            "CUP_30Rnd_545x39_AK_M",
            "CUP_30Rnd_Subsonic_545x39_AK_M",
            "CUP_30Rnd_TE1_Green_Tracer_545x39_AK_M",
            "CUP_30Rnd_TE1_Red_Tracer_545x39_AK_M",
            "CUP_30Rnd_TE1_White_Tracer_545x39_AK_M",
			"CUP_30Rnd_TE1_Yellow_Tracer_545x39_AK_M",
			"CUP_45Rnd_TE4_LRT4_Green_Tracer_545x39_RPK_M",
			"CUP_1Rnd_SmokeYellow_GP25_M",
			"CUP_10Rnd_9x39_SP5_VSS_M",
			"CUP_20Rnd_9x39_SP5_VSS_M",
			"CUP_5Rnd_127x108_KSVK_M",
			"CUP_100Rnd_TE4_LRT4_762x54_PK_Tracer_Green_M",
			"CUP_64Rnd_9x19_Bizon_M",
			"CUP_64Rnd_Green_Tracer_9x19_Bizon_M",
			"CUP_64Rnd_Red_Tracer_9x19_Bizon_M",
			"CUP_64Rnd_White_Tracer_9x19_Bizon_M",
			"CUP_64Rnd_Yellow_Tracer_9x19_Bizon_M",
			"CUP_8Rnd_B_Saiga12_74Slug_M",
			"CUP_8Rnd_B_Saiga12_74Pellets_M",
			"CUP_10Rnd_762x54_SVD_M",
			"CUP_10Rnd_9x19_Compact",
			"CUP_18Rnd_9x19_Phantom",
			"CUP_17Rnd_9x19_glock17",
			"CUP_8Rnd_9x18_Makarov_M",
			"CUP_6Rnd_45ACP_M",
			"CUP_8Rnd_9x18_MakarovSD_M",
			"CUP_30Rnd_9x19_UZI",
			"CUP_20Rnd_B_765x17_Ball_M",
			"CUP_5Rnd_86x70_L115A1"
		};
	};

	class CUPPistols 
	{
		name = "CUP Пистолеты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\handgun_ca.paa";
		items[] = 
		{
            "CUP_hgun_BallisticShield_Armed",
            "CUP_hgun_Compact",
            "CUP_hgun_Duty",
            "CUP_hgun_Phantom",
            "CUP_hgun_Glock17",
            "CUP_hgun_Colt1911",
            "CUP_hgun_M9",
            "CUP_hgun_PB6P9",
            "CUP_hgun_TaurusTracker455",
            "CUP_hgun_TaurusTracker455_gold",
            "CUP_hgun_Makarov"
		};
	};

	class CUPSubMachineGuns
	{
		name = "CUP Пист.пулемёты,дробовики";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
            "CUP_sgun_AA12",
            "CUP_glaunch_6G30",
            "CUP_sgun_M1014",
            "CUP_glaunch_M32",
            "CUP_glaunch_M79",
            "CUP_glaunch_Mk13",
            "CUP_smg_bizon",
			"CUP_hgun_MicroUzi",
			"CUP_hgun_SA61"
		};
	};

	class CUPLightMachineGuns
	{
		name = "CUP Пулемёты";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
            "CUP_lmg_minimi",
            "CUP_lmg_minimi_railed",
            "CUP_lmg_L110A1",
            "CUP_lmg_L7A2",
            "CUP_lmg_M240",
            "CUP_lmg_m249_SQuantoon",
            "CUP_lmg_m249_pip1",
            "CUP_lmg_m249_para",
            "CUP_lmg_M60E4",
            "CUP_arifle_MG36",
            "CUP_arifle_MG36_camo",
            "CUP_lmg_Mk48_des",
            "CUP_lmg_Mk48_wdl",
            "CUP_lmg_UK59",
            "CUP_lmg_PKM",
            "CUP_lmg_Pecheneg",
            "CUP_arifle_RPK74"
		};
	};

	class CUPAssaultRifles
	{
		name = "CUP Автоматы";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
            "CUP_arifle_CZ805_A1",
            "CUP_arifle_CZ805_GL",
            "CUP_arifle_CZ805_B",
            "CUP_arifle_CZ805_B_GL",
            "CUP_smg_EVO",
            "CUP_arifle_FNFAL",
            "CUP_arifle_FNFAL_railed",
            "CUP_arifle_G36A",
            "CUP_arifle_G36C",
            "CUP_arifle_G36K",
            "CUP_arifle_G36A_camo",
            "CUP_arifle_G36C_camo",
            "CUP_arifle_G36K_camo",
            //"CUP_srifle_L129A1",
            "CUP_srifle_L129A1_HG",
            "CUP_arifle_L85A2",
            "CUP_arifle_L85A2_G",
            "CUP_arifle_L85A2_NG",
            "CUP_arifle_L85A2_GL",
            "CUP_arifle_L86A2",
            "CUP_arifle_M16A2",
            "CUP_arifle_M16A2_GL",
            "CUP_arifle_M16A4_Base",
            "CUP_arifle_M16A4_GL",
            "CUP_arifle_M4A1_black",
            "CUP_arifle_M4A1",
            "CUP_arifle_M4A1_desert",
            "CUP_arifle_M4A1_BUIS_GL",
            "CUP_arifle_M4A1_BUIS_desert_GL",
            "CUP_arifle_M4A3_desert",
            "CUP_srifle_Mk12SPR",
            "CUP_arifle_Mk16_CQC_SFG",
            "CUP_arifle_Mk16_CQC_EGLM",
            "CUP_smg_MP5A5",
            "CUP_smg_MP5SD6",
            "CUP_arifle_Sa58RIS1",
            "CUP_arifle_Sa58RIS1_des",
            "CUP_arifle_Sa58RIS2_gl",
            "CUP_arifle_XM8_Carbine",
            "CUP_arifle_XM8_Railed",
            "CUP_arifle_XM8_Carbine_GL",
            "CUP_arifle_xm8_SAW",
            "CUP_arifle_AKM",
            "CUP_arifle_AK107",
            "CUP_arifle_AK107_GL",
            "CUP_arifle_AKS_Gold",
            "CUP_sgun_Saiga12K"
		};
	};

	class CUPSniperRifles
	{
		name = "CUP Снайперские винтовки";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
            "CUP_srifle_AS50",
            "CUP_srifle_CZ550",
            "CUP_srifle_CZ550_rail",
            "CUP_srifle_CZ750",
            "CUP_srifle_G22_des",
            "CUP_srifle_AWM_des",
            "CUP_srifle_M107_Base",
            //"CUP_srifle_M110",
            "CUP_srifle_M14",
            //"CUP_srifle_M14_DMR",
            "CUP_srifle_M40A3",
            "CUP_srifle_LeeEnfield",
            "CUP_srifle_LeeEnfield_rail",
            "CUP_srifle_VSSVintorez",
            "CUP_srifle_ksvk",
            "CUP_srifle_SVD",
            "CUP_srifle_SVD_des"
		};
	};

	class CUPExplosive
	{
		name = "CUP Взрывчатка и т.д";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
            "CUP_HandGrenade_RGO",
            "CUP_HandGrenade_RGD5",
            "CUP_HandGrenade_L109A1_HE",
			"CUP_HandGrenade_L109A2_HE",
			"CUP_Mine_M",
			"CUP_IED_V1_M",
			"CUP_IED_V2_M",
			"CUP_IED_V3_M",
			"CUP_IED_V4_M",
			"CUP_PipeBomb_M",
			"CUP_TimeBomb_M",
			"CUP_MineE_M"
		};
	};
	
	class CUPLaunchers 
	{
		name = "CUP Гранатометы";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
            "CUP_launch_M136",
            "CUP_launch_MAAWS",
            "CUP_launch_Mk153Mod0",
            "CUP_launch_9K32Strela",
            "CUP_launch_Igla",
            "CUP_launch_FIM92Stinger",
            "CUP_launch_Javelin",
            "CUP_launch_M47",
            "CUP_launch_NLAW",
            "CUP_launch_Metis",
            "CUP_launch_RPG18",
            "CUP_launch_RPG7V"
		};
	};
	
	class CUPLauncherAmmo
	{
		name = "CUP Снаряды для гранатометов";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
            "CUP_M136_M",
            "CUP_MAAWS_HEAT_M",
            "CUP_MAAWS_HEDP_M",
            "CUP_SMAW_HEAA_M",
            "CUP_SMAW_HEDP_M",
            "CUP_SMAW_Spotting",
            "CUP_Strela_2_M",
            "CUP_Igla_M",
            "CUP_Stinger_M",
            "CUP_Javelin_M",
            "CUP_Dragon_EP1_M",
            "CUP_NLAW_M",
            "CUP_AT13_M",
            "CUP_RPG18_M",
            "CUP_PG7V_M",
            "CUP_PG7VM_M",
            "CUP_PG7VL_M",
            "CUP_PG7VR_M",
            "CUP_OG7_M",
            "CUP_TBG7V_M"
		};
	};