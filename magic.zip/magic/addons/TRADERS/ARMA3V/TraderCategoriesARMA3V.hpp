    class A3UAVs
	{
		name = "Воздушные беспилотники";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\gps_ca.paa";
		items[] = 
		{
			//"CUP_B_AH6X_USA",
			//"CUP_B_Pchela1T_CDF",
			//"CUP_O_Pchela1T_RU",
			//"CUP_B_USMC_MQ9",
			"B_UAV_02_F",
			"B_UAV_02_CAS_F",
			"O_UAV_02_F",
			"O_UAV_02_CAS_F",
			"B_T_UAV_03_F",
			"O_T_UAV_04_CAS_F",
			"I_UAV_02_F",
			"I_UAV_02_CAS_F",
			"B_UAV_05_F"
		};
	};

	class A3UGVs
	{
		name = "Наземные беспилотники";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\gps_ca.paa";
		items[] = 
		{
			"B_UGV_01_F",
			"C_IDAP_UGV_01_F",
			"B_UGV_01_rcws_F",
			"O_UGV_01_F",
			"O_UGV_01_rcws_F",
			"O_T_UGV_01_ghex_F",
			"O_T_UGV_01_rcws_ghex_F",
			"I_UGV_01_F",
			"I_UGV_01_rcws_F",
			//DLC Contact
			"B_UGV_02_Demining_F",
			"B_UGV_02_Science_F"
		};
	};