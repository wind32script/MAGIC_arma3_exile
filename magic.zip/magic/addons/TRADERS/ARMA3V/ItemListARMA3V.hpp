    ///////////////////////////////////////////////////////////////////////////////
	// Воздушные беспилотники
	///////////////////////////////////////////////////////////////////////////////
	//class CUP_B_AH6X_USA                 { quality = 1; price = 20000; };
	//class CUP_B_Pchela1T_CDF             { quality = 1; price = 20000; };
	//class CUP_O_Pchela1T_RU              { quality = 1; price = 20000; };
	//class CUP_B_USMC_MQ9                 { quality = 6; price = 100000; };
	class B_UAV_02_F                       { quality = 6; price = 100000; };
	class B_UAV_02_CAS_F                   { quality = 6; price = 100000; };
	class O_UAV_02_F                       { quality = 6; price = 100000; };
	class O_UAV_02_CAS_F                   { quality = 6; price = 100000; };
	class B_T_UAV_03_F                     { quality = 10; price = 150000; };
	class O_T_UAV_04_CAS_F                 { quality = 6; price = 100000; };
	class I_UAV_02_F  					   { quality = 6; price = 100000; };
	class I_UAV_02_CAS_F 				   { quality = 6; price = 100000; };
	class B_UAV_05_F                       { quality = 10; price = 200000; };

	///////////////////////////////////////////////////////////////////////////////
	// Наземные беспилотники
	///////////////////////////////////////////////////////////////////////////////
	class B_UGV_01_F                     { quality = 3; price = 40000; };
	class C_IDAP_UGV_01_F                { quality = 3; price = 40000; };
	class B_UGV_01_rcws_F                { quality = 3; price = 40000; };
	class O_UGV_01_F                     { quality = 3; price = 40000; };
	class O_UGV_01_rcws_F                { quality = 3; price = 40000; };
	class O_T_UGV_01_ghex_F              { quality = 3; price = 40000; };
	class O_T_UGV_01_rcws_ghex_F         { quality = 3; price = 40000; };
	class I_UGV_01_F  					 { quality = 3; price = 40000; };
	class I_UGV_01_rcws_F  			     { quality = 3; price = 45000; };
	//DLC Contact
	class B_UGV_02_Demining_F            { quality = 3; price = 45000; };
	class B_UGV_02_Science_F             { quality = 3; price = 45000; };