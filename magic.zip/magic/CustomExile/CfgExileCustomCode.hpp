//Возрождать
ExileClient_object_player_death_startBleedingOut = "Custom\EnigmaRevive\ExileClient_object_player_death_startBleedingOut.sqf";
ExileClient_object_player_event_onInventoryOpened = "Custom\EnigmaRevive\ExileClient_object_player_event_onInventoryOpened.sqf";
//Spawn Selection by bambam
ExileClient_gui_selectSpawnLocation_event_onSpawnButtonClick = "xs\spawn\Overwrites\ExileClient_gui_selectSpawnLocation_event_onSpawnButtonClick.sqf";
ExileClient_gui_selectSpawnLocation_show = "xs\spawn\Overwrites\ExileClient_gui_selectSpawnLocation_show.sqf";
ExileClient_gui_selectSpawnLocation_zoomToMarker = "xs\spawn\Overwrites\ExileClient_gui_selectSpawnLocation_zoomToMarker.sqf";
ExileClient_gui_selectSpawnLocation_event_onListBoxSelectionChanged = "xs\spawn\Overwrites\ExileClient_gui_selectSpawnLocation_event_onListBoxSelectionChanged.sqf";
//ExileServer_object_player_createBambi = "xs\spawn\Overwrites\ExileServer_object_player_createBambi.sqf";
//LauncherTrader
ExileClient_util_playerEquipment_add = "CustomExile\fix\LauncherTraderFIX\ExileClient_util_playerEquipment_add.sqf";
//xm8
ExileClient_gui_xm8_slide_apps_onOpen = "Custom\xm8Apps\ExileClient_gui_xm8_slide_apps_onOpen.sqf";
//ExAdClient
ExileClient_gui_xm8_slide                       = "ExAdClient\XM8\CustomCode\ExileClient_gui_xm8_slide.sqf";
ExileClient_gui_xm8_show                        = "ExAdClient\XM8\CustomCode\ExileClient_gui_xm8_show.sqf";
ExileClient_gui_virtualGarageDialog_show        = "ExAdClient\virtualgarage\customcode\ExileClient_gui_virtualGarageDialog_show.sqf";
//ExileServer_system_territory_database_load    = "ExAdClient\VirtualGarage\CustomCode\ExileServer_system_territory_database_load.sqf";
//suicide
ExileClient_gui_escape_suicide = "CustomExile\fix\overrides\ExileClient_gui_escape_suicide.sqf";
//03.03.2018
ExileClient_gui_vehicleTraderDialog_updateVehicle = "CustomExile\fix\overrides\ExileClient_gui_vehicleTraderDialog_updateVehicle.sqf";
//TradeFix
ExileServer_system_trading_network_purchaseVehicleRequest = "CustomExile\fix\ExileServer_system_trading_network_purchaseVehicleRequest.sqf";
//fixVG
ExileServer_object_vehicle_network_storeVehicleRequest = "CustomExile\fix\ExileServer_object_vehicle_network_storeVehicleRequest.sqf";
//TraderPlus
ExileClient_gui_traderDialog_show = "SM\TraderPlus\overrides\ExileClient_gui_traderDialog_show.sqf";
ExileClient_gui_traderDialog_updateItemStats = "SM\TraderPlus\overrides\ExileClient_gui_traderDialog_updateItemStats.sqf";
ExileClient_gui_vehicleTraderDialog_show = "SM\TraderPlus\overrides\ExileClient_gui_vehicleTraderDialog_show.sqf";
ExileClient_gui_traderDialog_event_onStoreDropDownSelectionChanged = "SM\TraderPlus\overrides\ExileClient_gui_traderDialog_event_onStoreDropDownSelectionChanged.sqf";
ExileClient_gui_vehicleTraderDialog_updateVehicleListBox = "SM\TraderPlus\overrides\ExileClient_gui_vehicleTraderDialog_updateVehicleListBox.sqf";
ExileClient_gui_traderDialog_updateStoreListBox = "SM\TraderPlus\overrides\ExileClient_gui_traderDialog_updateStoreListBox.sqf";
ExileClient_gui_traderDialog_event_onStoreListBoxSelectionChanged = "SM\TraderPlus\overrides\ExileClient_gui_traderDialog_event_onStoreListBoxSelectionChanged.sqf";
ExileClient_gui_traderDialog_event_onPurchaseButtonClick = "SM\TraderPlus\overrides\ExileClient_gui_traderDialog_event_onPurchaseButtonClick.sqf";
ExileClient_gui_traderDialog_event_onUnload = "SM\TraderPlus\overrides\ExileClient_gui_traderDialog_event_onUnload.sqf";
ExileClient_gui_traderDialog_event_onFilterCheckboxStateChanged = "SM\TraderPlus\overrides\ExileClient_gui_traderDialog_event_onFilterCheckboxStateChanged.sqf";
ExileClient_system_trading_network_purchaseItemResponse = "SM\TraderPlus\overrides\ExileClient_system_trading_network_purchaseItemResponse.sqf";
ExileClient_gui_traderDialog_updateInventoryListBox = "SM\TraderPlus\overrides\ExileClient_gui_traderDialog_updateInventoryListBox.sqf";
//VectorBuilding
ExileClient_gui_constructionMode_update = "SM\Vector\SM_gui_constructionMode_update.sqf";
ExileClient_gui_hud_event_onKeyUp = "SM\Vector\SM_gui_hud_event_onKeyUp.sqf";
ExileClient_construction_thread = "SM\Vector\SM_construction_thread.sqf";
//Limit Base Building
ExileClient_construction_beginNewObject = "SM\Vector\ExileClient_construction_beginNewObject.sqf";
//SM_Paint
ExileServer_object_construction_database_load = "SM_Paint\overrides\ExileServer_object_construction_database_load.sqf";
//Спавн на базу
//ExileClient_gui_selectSpawnLocation_show = "Custom\territorySpawn\ExileClient_gui_selectSpawnLocation_show.sqf";
ExileServer_system_territory_database_load = "Custom\territorySpawn\ExileServer_system_territory_database_load.sqf";
//VirtualGaragePublic
ExileServer_object_player_createBambi = "Scripts\Atlas_VirtualGaragePublic\ExileServer_object_player_createBambi.sqf";
ExileServer_object_player_database_load = "\Atlas_VirtualGaragePublic\exile_server\ExileServer_object_player_database_load.sqf";
//Продажа ящиков
ExileClient_gui_wasteDumpDialog_show = "Scripts\WasteDumpOverride\ExileClient_gui_wasteDumpDialog_show.sqf";
ExileClient_gui_wasteDumpDialog_event_onModeDropDownSelectionChanged = "Scripts\WasteDumpOverride\ExileClient_gui_wasteDumpDialog_event_onModeDropDownSelectionChanged.sqf";
ExileServer_system_trading_network_wasteDumpRequest = "Scripts\WasteDumpOverride\ExileServer_system_trading_network_wasteDumpRequest.sqf";
ExileClient_object_shippingContainer_smash = "Scripts\WasteDumpOverride\ExileClient_object_shippingContainer_smash.sqf";
//Отсутствие голода или жажды в безопасной зоне
//ExileClient_object_player_stats_update = "CustomExile\fix\overrides\ExileClient_object_player_stats_update.sqf";
//Trede_Zone Уведомления
ExileClient_object_player_event_onEnterSafezone = "CustomExile\fix\Trede_Zone\ExileClient_object_player_event_onEnterSafezone.sqf";
//Дальность действия БПЛА
ExileServer_system_simulationMonitor_thread_toggleSimulation = "CustomExile\fix\ExileServer_system_simulationMonitor_thread_toggleSimulation.sqf";
//fix бессмертие техники после выезда с трейд зоны
ExileClient_object_player_event_onLeaveSafezone = "Custom\AllowDamageThread\ExileClient_object_player_event_onLeaveSafezone.sqf";
//Ящик с лутом
ExileServer_system_lootManager_spawnLootInBuilding = "CustomExile\fix\Loot\ExileServer_system_lootManager_spawnLootInBuilding.sqf";
//PilotHUD
ExileClient_gui_hud_renderWeaponPanel = "Custom\PilotHUD\ExileClient_gui_hud_renderWeaponPanel.sqf";
//Использование автомобилей DLC без DLC
ExileClient_gui_interactionMenu_hook = "Custom\ExileDLCVehicles\ExileClient_gui_interactionMenu_hook.sqf";
//Crash Loot
ExileClient_object_container_pack = "Scripts\Crash_Loot\ExileClient_object_container_pack.sqf";
ExileServer_object_container_packContainer = "Scripts\Crash_Loot\ExileServer_object_container_packContainer.sqf";
//Lights
ExileClient_object_floodLight_network_toggleFloodLightRequest = "Custom\Lights\ExileClient_object_floodLight_network_toggleFloodLightRequest.sqf";
ExileClient_object_portableGenerator_switchOff = "Custom\Lights\ExileClient_object_portableGenerator_switchOff.sqf";
ExileClient_object_portableGenerator_switchOn = "Custom\Lights\ExileClient_object_portableGenerator_switchOn.sqf";
ExileServer_object_floodLight_network_toggleFloodLightRequest = "Custom\Lights\ExileServer_object_floodLight_network_toggleFloodLightRequest.sqf";
//Пояс смертника
//ExileClient_gui_inventory_event_onSlotDoubleClick = "Custom\ExileClient_gui_inventory_event_onSlotDoubleClick.sqf";
// Player markers
ExileClient_gui_safezone_safeESP = "Custom\pvemarkers\ExileClient_gui_safezone_safeESP.sqf";
//Анти PvP сука бля....
ExileClient_object_player_event_onHandleDamage = "Custom\anti_pvp\ExileClient_object_player_event_onHandleDamage.sqf";
//Xm8/Territory show max constructions in territory detail
ExileClient_gui_xm8_slide_territory_onOpen = "CustomExile\fix\ExileClient_gui_xm8_slide_territory_onOpen.sqf";
//Выход с игры без ожидания
ExileClient_gui_escape_abort = "Scripts\ExitWithoutWaiting\ExileClient_gui_escape_abort.sqf";
//Удаления кассетных снарядов
ExileServer_object_vehicle_carefulCreateVehicle = "CustomExile\fix\ExileServer_object_vehicle_carefulCreateVehicle.sqf";
//Хрень одна которую можно найти на форуме!
//ExileClient_object_player_initialize = "addons\fixes\ExileClient_object_player_initialize.sqf";
//ExileClient_object_player_stats_update = "addons\fixes\ExileClient_object_player_stats_update.sqf";
//Не отменяет респекты при смерти
ExileServer_object_player_event_onMpKilled = "CustomExile\fix\ExileServer_object_player_event_onMpKilled.sqf";
//Disable map shift click and hud display
ExileClient_gui_map_event_onDraw = "CustomExile\Exile_Client_Overrides\ExileClient_gui_map_event_onDraw.sqf";
//
ExileClient_system_trading_network_purchaseVehicleResponse = "CustomExile\Exile_Client_Overrides\ExileClient_system_trading_network_purchaseVehicleResponse.sqf";
//Dual Arms Client
ExileClient_object_player_event_onInventoryClosed = "custom\dual_arms\ExileClient_object_player_event_onInventoryClosed.sqf";
ExileClient_object_player_event_onKilled = "custom\dual_arms\ExileClient_object_player_event_onKilled.sqf";
ExileClient_object_player_event_onTake = "custom\dual_arms\ExileClient_object_player_event_onTake.sqf";
// deadBox
ExileServer_system_garbageCollector_unscheduled_deleteAllDead = "\atlas_dropDeadBox\exile\ExileServer_system_garbageCollector_unscheduled_deleteAllDead.sqf";    
//Dual Arms Server
ExileServer_system_network_event_onHandleDisconnect = "custom\dual_arms\ExileServer_system_network_event_onHandleDisconnect.sqf";
//Крышки
ExileClient_gui_lockerDialog_event_onDepositButtonClick = "Custom\dynamicLockerLimit\ExileClient_gui_lockerDialog_event_onDepositButtonClick.sqf";
ExileClient_gui_lockerDialog_show = "Custom\dynamicLockerLimit\ExileClient_gui_lockerDialog_show.sqf";
ExileClient_system_locker_network_lockerResponse = "Custom\dynamicLockerLimit\ExileClient_system_locker_network_lockerResponse.sqf";
ExileServer_system_locker_network_lockerDepositRequest = "Custom\dynamicLockerLimit\ExileServer_system_locker_network_lockerDepositRequest.sqf";

/* extDB3 Overrides for Server */
ExileServer_world_initialize = "Exile_Server_Overrides\ExileServer_world_initialize.sqf";
ExileServer_util_time_uptime = "Exile_Server_Overrides\ExileServer_util_time_uptime.sqf";
ExileServer_util_time_addTime = "Exile_Server_Overrides\ExileServer_util_time_addTime.sqf";
ExileServer_util_time_currentTime = "Exile_Server_Overrides\ExileServer_util_time_currentTime.sqf";
ExileServer_system_database_connect = "Exile_Server_Overrides\ExileServer_system_database_connect.sqf";
//ExileServer_system_database_connect = "custom\GADDvent\ExileServer_system_database_connect.sqf";
ExileServer_system_database_handleBig = "Exile_Server_Overrides\ExileServer_system_database_handleBig.sqf";
ExileServer_system_process_noobFilter = "Exile_Server_Overrides\ExileServer_system_process_noobFilter.sqf";
//ExileServer_object_player_createBambi = "Exile_Server_Overrides\ExileServer_object_player_createBambi.sqf";
//ExileServer_object_player_database_load = "Exile_Server_Overrides\ExileServer_object_player_database_load.sqf";
ExileServer_object_vehicle_database_load = "Exile_Server_Overrides\ExileServer_object_vehicle_database_load.sqf";
//ExileServer_object_player_event_onMpKilled = "Exile_Server_Overrides\ExileServer_object_player_event_onMpKilled.sqf";
ExileServer_object_container_database_load = "Exile_Server_Overrides\ExileServer_object_container_database_load.sqf";
ExileServer_object_container_database_insert = "Exile_Server_Overrides\ExileServer_object_container_database_insert.sqf";
ExileServer_system_territory_database_insert = "Exile_Server_Overrides\ExileServer_system_territory_database_insert.sqf";
ExileServer_object_container_database_update = "Exile_Server_Overrides\ExileServer_object_container_database_update.sqf";
ExileServer_object_container_createContainer = "Exile_Server_Overrides\ExileServer_object_container_createContainer.sqf";
ExileServer_system_database_query_selectFull = "Exile_Server_Overrides\ExileServer_system_database_query_selectFull.sqf";
//ExileServer_object_construction_database_load = "Exile_Server_Overrides\ExileServer_object_construction_database_load.sqf";
ExileServer_system_database_query_insertSingle = "Exile_Server_Overrides\ExileServer_system_database_query_insertSingle.sqf";
ExileServer_system_database_query_selectSingle = "Exile_Server_Overrides\ExileServer_system_database_query_selectSingle.sqf";
ExileServer_object_construction_database_insert = "Exile_Server_Overrides\ExileServer_object_construction_database_insert.sqf";
ExileServer_system_simulationMonitor_initialize = "Exile_Server_Overrides\ExileServer_system_simulationMonitor_initialize.sqf";
ExileServer_system_database_query_fireAndForget = "Exile_Server_Overrides\ExileServer_system_database_query_fireAndForget.sqf";
ExileServer_object_vehicle_createPersistentVehicle = "Exile_Server_Overrides\ExileServer_object_vehicle_createPersistentVehicle.sqf";
ExileServer_system_trading_network_sellItemRequest = "Exile_Server_Overrides\ExileServer_system_trading_network_sellItemRequest.sqf";
ExileServer_system_database_query_selectSingleField = "Exile_Server_Overrides\ExileServer_system_database_query_selectSingleField.sqf";
//ExileServer_system_trading_network_wasteDumpRequest = "Exile_Server_Overrides\ExileServer_system_trading_network_wasteDumpRequest.sqf";
ExileServer_object_vehicle_createNonPersistentVehicle = "Exile_Server_Overrides\ExileServer_object_vehicle_createNonPersistentVehicle.sqf";
ExileServer_system_territory_network_purchaseTerritory = "Exile_Server_Overrides\ExileServer_system_territory_network_purchaseTerritory.sqf";
ExileServer_system_territory_network_flagStolenRequest = "Exile_Server_Overrides\ExileServer_system_territory_network_flagStolenRequest.sqf";
ExileServer_system_trading_network_purchaseItemRequest = "Exile_Server_Overrides\ExileServer_system_trading_network_purchaseItemRequest.sqf";
ExileServer_system_territory_network_restoreFlagRequest = "Exile_Server_Overrides\ExileServer_system_territory_network_restoreFlagRequest.sqf";
//ExileServer_system_trading_network_purchaseVehicleRequest = "Exile_Server_Overrides\ExileServer_system_trading_network_purchaseVehicleRequest.sqf";
ExileServer_system_territory_network_payFlagRansomRequest = "Exile_Server_Overrides\ExileServer_system_territory_network_payFlagRansomRequest.sqf";
ExileServer_object_vehicle_network_retrieveVehicleRequest = "Exile_Server_Overrides\ExileServer_object_vehicle_network_retrieveVehicleRequest.sqf";
ExileServer_system_territory_maintenance_recalculateDueDate = "Exile_Server_Overrides\ExileServer_system_territory_maintenance_recalculateDueDate.sqf";
ExileServer_system_territory_network_territoryUpgradeRequest = "Exile_Server_Overrides\ExileServer_system_territory_network_territoryUpgradeRequest.sqf";
ExileServer_system_trading_network_purchaseVehicleSkinRequest = "Exile_Server_Overrides\ExileServer_system_trading_network_purchaseVehicleSkinRequest.sqf";
ExileServer_system_territory_network_payTerritoryProtectionMoneyRequest = "Exile_Server_Overrides\ExileServer_system_territory_network_payTerritoryProtectionMoneyRequest.sqf";