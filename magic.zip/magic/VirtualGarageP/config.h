class CfgPublicVirtualGarage
{
	//Максимум слотов к покупке, -1 - бексонечно
	maxSlots = 50;
	
	/**
		Цена за покупку новых слотов
		Алгоритм
			Количество активных слотов * multiplierSlotsCost
				Пример:
					3 слота * 3000 = 9000 за слот и так далее по возростанию
		
	**/
	multiplierSlotsCost = 15000;
	
	//Удалять инвентарь 1 - да, 0 - нет
	clearInventory = 0;
	
	//Допустимый тип транспорта для сохранения
	vehicleTypes[] = {"Car","Tank","Plane","Air","Ship","Submarine"};
	
	//Транспорт который нельзя ставить в гараж ни при каких условиях
	restrictedVehicles[] = 
	{
		"I_Truck_02_MRL_F",
		"RHS_BM21_MSV_01",
		"RHS_BM21_VDV_01",
		"RHS_BM21_VMF_01",
	    "RHS_BM21_VV_01",
		"rhsusf_M142_usarmy_WD",
		"rhsusf_M142_usarmy_D",
        "rhsusf_M142_usmc_WD",
		"CUP_B_M270_HE_USMC",
		"CUP_B_M270_DPICM_USMC",
		"CUP_B_M270_HE_USA",
		"CUP_B_M270_DPICM_USA",
		"CUP_I_M270_HE_AAF",
	    "CUP_I_M270_DPICM_AAF",
		"CUP_O_BM21_RU",
		"CUP_B_BM21_CDF",
		"CUP_O_BM21_CHDKZ",
		"CUP_O_BM21_TKA",
		"CUP_O_BM21_SLA",
	    "O_MBT_02_arty_F",
		"O_T_MBT_02_arty_ghex_F",
		"B_MBT_01_arty_F",
		"B_T_MBT_01_arty_F",
		"B_MBT_01_mlrs_F",
		"B_T_MBT_01_mlrs_F",
	    "rhsusf_m109_usarmy",
		"rhsusf_m109d_usarmy",
		"rhs_2s3_tv",
		"min_rf_2b26",
		"min_rf_2b26_desert",
		"min_rf_2b26_winter"
	};
};