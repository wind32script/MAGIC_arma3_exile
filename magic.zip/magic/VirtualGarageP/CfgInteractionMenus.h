class VGP
{
	targetType = 2;
	target = "Land_InfoStand_V2_F";

	class Actions 
	{
		class VGP: ExileAbstractAction
		{
			title = "Виртуальный Гараж";
			condition = "true";
			action = "call ExileClient_gui_virtualpGarageDialog_show";
		};
	};
};