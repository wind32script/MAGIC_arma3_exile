#include "MarXet\CfgMarXet.cpp"
#include "xs\spawn\CfgBaseSpawn.hpp"
class CfgSpawnTerritoryPlayer
{
	type = 2; // 0 - отключить. 1 - респавн только для владельца территории, то есть кто её создал. 2 - респавн владельца и модераторов. 3 - респавн для всех кто относится к клану. 4 - все флаги это для всех точка респа.
};

class CfgMarkers 
{
	class ExileSpawnTerritoryZone 
	{
		name = "Exile Spawn Territory Zone";
		icon = "exile_assets\texture\marker\spawn_zone_ca.paa";
		color[] = {1, 0, 0, 1};
		size = 32;
		shadow = true;
		scope = private;
	};
};


class CfgNetworkMessages
{
	#include "ExAdClient\CfgNetworkMessages.cpp"
	/* Virtual Garage */
	class RetrieveVehicleResponse
	{
		module = "VirtualGarage";
		parameters[] = {"STRING","STRING"};
	};
	class updateDataResponse
	{
		module = "VirtualGarage";
		parameters[] = {"STRING"};
	};
	/* ClaimVehicles */
	class saveVehicleRequest
    {
        module = "ClaimVehicles";
        parameters[] = {"STRING","STRING"};
    };
	/* MarXet */
	class buyNowRequest
    {
	    module = "MarXet";
	    parameters[] = {"STRING","STRING"};
    };
    class buyerBuyNowResponse
    {
	    module = "MarXet";
	    parameters[] = {"ARRAY","STRING","STRING","STRING"};
    };
	class sellerBuyNowResponse
    {
	   	module = "MarXet";
	   	parameters[] = {"ARRAY"};
    };
    class createNewListingRequest
    {
	    module = "MarXet";
	    parameters[] = {"ARRAY"};
    };
    class createNewListingResponse
    {
	    module = "MarXet";
	    parameters[] = {"BOOL","STRING","STRING","SCALAR"};
    };
    class updateInventoryRequest
    {
        module = "MarXet";
        parameters[] = {"SCALAR"};
    };
    class updateInventoryResponse
    {
	    module = "MarXet";
	    parameters[] = {"ARRAY"};
    };
	/* WireTransfer-master */
	class wireTransferRequest
	{
		module = "wire";
		parameters[] = {"STRING","SCALAR","BOOL"};
	};
	/* VirtualGarageP */
	class storepVehicleRequest
	{
		module="virtualp_garage";
		parameters[]=
		{
			"STRING",
			"STRING"
		};
	};
	class pstoreVehicleResponse
	{
		module = "virtualp_garage";
		parameters[] = 
		{
			"BOOL",
			"STRING"
		};
	};
	class buySlotsRequest
	{
		module = "virtualp_garage";
		parameters[] = {};
	};
	class buySlotsResponse
	{
		module = "virtualp_garage";
		parameters[] = {};
	};
	class storedVehicleResponse
	{
		module = "virtualp_garage";
		parameters[] = {"ARRAY"};
	};
	class storedVehicleRequest
	{
		module = "virtualp_garage";
		parameters[] = {"STRING"};
	};
	class retrievepVehicleResponse
	{
		module = "virtualp_garage";
		parameters[] = {"STRING"};
	};
	class retrievepVehicleRequest
	{
		module = "virtualp_garage";
		parameters[] = {"STRING","STRING"};
	};
	/* paint */
    class updatePaint
    {
        module = "paint";
        parameters[] = {"STRING","SCALAR","ARRAY"};
    };
};

class CfgClans
{
	registrationFee = 20000;
	clanNameAlphabet = "ЙЦУКЕНГШЩЗХЪФЫВАПРОЛДЖЭЯЧСМИТЬБЮйцукенгшщзхъфывапролджэячсмитьбюabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ._-!:\\/";
	maximumIcons = 20;
	maximumIconText = 50;
	maximumPolys = 10;
	maximumPolyNode = 10;
};

class Exile_AbstractCraftingRecipe
{
	name = "";
	pictureItem = ""; 
	returnedItems[] = {};
	components[] = {}; // Required components
	tools[] = {}; // Required tools (matches, gas cooker etc.)
	requiredInteractionModelGroup = ""; // See CfgInteractionModels
	requiresOcean = 0; // isSurfaceWater test
	requiresFire = 0; // inflamed object nearby
	requiresConcreteMixer = 0; // Check if concrete mixer is nearby
};

class CfgCraftingRecipes
{
    #include "Custom\EBM\recipes.hpp"
    #include "Custom\EBM\ExileCraftingRecipes.hpp"
};

class CfgExileAnimals
{
	enabled = 0;
	disableVanillaAnimals = 1;
	animalTypes[] = 
	{
		"Exile_Animal_Rooster_Abstract",
		"Exile_Animal_Hen_Abstract",
		"Exile_Animal_Goat_Abstract",
		"Exile_Animal_Sheep_Abstract"
	};
	spawnDistance = 150;
	spawnRadius = 50;
	minimumSpawnDelay = 5 * 60;
	maximumSpawnDelay = 10 * 60;
	keepAliveRadius = 500;
	minimumLifetime = 5 * 60;
};

class CfgExileArsenal
{
	#include "Custom\EBM\prices.hpp"
	#include "addons\TRADERS\ARMA3V\ItemListARMA3V.hpp"
	#include "addons\TRADERS\ARMA3W\ItemListARMA3W.hpp"
	#include "addons\TRADERS\APEX\ItemListAPEX.hpp"
    #include "addons\TRADERS\EXILE\ItemListExile.hpp"
	#include "addons\TRADERS\CUPW\ItemListCUPW.hpp"
	#include "addons\TRADERS\CUPV\ItemListCUPV.hpp"
	#include "addons\TRADERS\RHSV\ItemListRHSV.hpp"
	#include "addons\TRADERS\RHSW\ItemListRHSW.hpp"
	//#include "addons\TRADERS\MASV\ItemListMASV.hpp"
	//#include "addons\TRADERS\MASW\ItemListMASW.hpp"
	#include "addons\TRADERS\RFV\ItemListRFV.hpp"
	#include "addons\TRADERS\RFW\ItemListRFW.hpp"
	#include "addons\TRADERS\CUSTOM\ItemListCUSTOM.hpp"
};

class CfgTraderCategories 
{
	#include "Custom\EBM\traders.hpp"
	#include "addons\TRADERS\ARMA3V\TraderCategoriesARMA3V.hpp"
	#include "addons\TRADERS\ARMA3W\TraderCategoriesARMA3W.hpp"
	#include "addons\TRADERS\APEX\TraderCategoriesAPEX.hpp"
	#include "addons\TRADERS\EXILE\TraderCategoriesExile.hpp"
	#include "addons\TRADERS\CUPW\TraderCategoriesCUPW.hpp"
	#include "addons\TRADERS\CUPV\TraderCategoriesCUPV.hpp"
    #include "addons\TRADERS\RHSV\TraderCategoriesRHSV.hpp"
	#include "addons\TRADERS\RHSW\TraderCategoriesRHSW.hpp"
	//#include "addons\TRADERS\MASV\TraderCategoriesMASV.hpp"
	//#include "addons\TRADERS\MASW\TraderCategoriesMASW.hpp"
	#include "addons\TRADERS\RFV\TraderCategoriesRFV.hpp"
	#include "addons\TRADERS\RFW\TraderCategoriesRFW.hpp"
	#include "addons\TRADERS\CUSTOM\TraderCategoriesCUSTOM.hpp"
};

class CfgTraders
{
    #include "addons\TRADERS\CfgTraders.hpp"
};

class CfgExileCustomCode 
{
	#include "CustomExile\CfgExileCustomCode.hpp"	
};

class CfgTradeSafeZone
{
	colorBorder = "red";
};

class CfgExileEnvironment
{
	class Altis 
	{
		class FireFlies
		{
			enable = 0;
			startHour = 18;
			endHour = 4;
		};

		class Anomalies
		{
			enable = 0;
			startHour = 19;
			endHour = 6;
		};

		class Breathing
		{
			enable = 0;
		};

		class Snow
		{
			enable = 0;
			surfaces[] = {};
		};

		class Radiation 
		{
			enable = 1;
		};

		class Temperature
		{
			daytimeTemperature[] = {15.93,16.89,18.42,20.40,22.68,25.10,27.48,29.63,31.40,32.66,33.32,33.80,33.80,33.32,32.66,31.40,29.63,27.48,25.10,22.68,20.40,18.42,16.89,15.93,15.93};
			overcast = -2;
			rain = -5;
			wind = -1;
			altitude = -0.5;
			water = -5;
		};
	};

	class Namalsk: Altis 
	{
		class FireFlies: FireFlies
		{
			enable = 0;
		};

		class Anomalies: Anomalies
		{
			enable = 0;
		};

		class Breathing: Breathing
		{
			enable = 0;
		};

		class Snow: Snow
		{
			enable = 0;
			surfaces[] = {"#nam_snow"};
		};

		class Radiation: Radiation
		{
			enable = 1;
			contaminatedZones[] = 
			{
				{{3960.14,	8454.75,	152.862}, 	80, 	140},
				{{4974.70,	6632.82,	4.74293}, 	40, 	150},
				{{6487.92,	9302.03,	36.0014}, 	60, 	110}
			};
		};

		class Temperature: Temperature
		{
			daytimeTemperature[] = {-2.00,-1.77,-1.12,-0.10,1.24,2.78,4.40,6.00,7.46,8.65,9.50,9.90,9.90,9.50,8.65,7.46,6.00,4.40,2.78,1.24,-0.10,-1.12,-1.77,-2.00,-2.00};
		};
	};

	class Tanoa: Altis
	{
		class FireFlies: FireFlies
		{
			enable = 0;
		};

		class Anomalies: Anomalies
		{
			enable = 0;
		};

		class Breathing: Breathing
		{
			enable = 0;
		};

		class Snow: Snow
		{
			enable = 0;
		};

		class Radiation: Radiation
		{
			enable = 1;
		};

		class Temperature: Temperature
		{
			daytimeTemperature[] = {15.93,16.89,18.42,20.40,22.68,25.10,27.48,29.63,31.40,32.66,33.32,33.80,33.80,33.32,32.66,31.40,29.63,27.48,25.10,22.68,20.40,18.42,16.89,15.93,15.93};
		};
	};

	class Malden: Altis
	{
		class FireFlies: FireFlies
		{
			enable = 0;
		};

		class Anomalies: Anomalies
		{
			enable = 0;
		};

		class Breathing: Breathing
		{
			enable = 0;
		};

		class Snow: Snow
		{
			enable = 0;
		};

		class Radiation: Radiation
		{
			enable = 0;
		};

		class Temperature: Temperature
		{
			daytimeTemperature[] = {15.93,16.89,18.42,20.40,22.68,25.10,27.48,29.63,31.40,32.66,33.32,33.80,33.80,33.32,32.66,31.40,29.63,27.48,25.10,22.68,20.40,18.42,16.89,15.93,15.93};
		};
	};
};

class CfgExileHUD
{
	class ShortItemNames
	{
		SmokeShell[] 						= {"WHITE", 	"SMOKE"};
		1Rnd_Smoke_Grenade_shell[] 			= {"WHITE", 	"SMOKE"};
		3Rnd_Smoke_Grenade_shell[] 			= {"WHITE", 	"SMOKE"};

		SmokeShellBlue[] 					= {"BLUE", 		"SMOKE"};
		1Rnd_SmokeBlue_Grenade_shell[] 		= {"BLUE", 		"SMOKE"};
		3Rnd_SmokeBlue_Grenade_shell[] 		= {"BLUE", 		"SMOKE"};

		SmokeShellGreen[] 					= {"GREEN", 	"SMOKE"};
		1Rnd_SmokeGreen_Grenade_shell[] 	= {"GREEN", 	"SMOKE"};
		3Rnd_SmokeGreen_Grenade_shell[] 	= {"GREEN", 	"SMOKE"};

		SmokeShellOrange[] 					= {"ORANGE", 	"SMOKE"};
		1Rnd_SmokeOrange_Grenade_shell[]	= {"ORANGE", 	"SMOKE"};
		3Rnd_SmokeOrange_Grenade_shell[] 	= {"ORANGE", 	"SMOKE"};

		SmokeShellPurple[] 					= {"PURPLE", 	"SMOKE"};
		1Rnd_SmokePurple_Grenade_shell[] 	= {"PURPLE", 	"SMOKE"};
		3Rnd_SmokePurple_Grenade_shell[] 	= {"PURPLE", 	"SMOKE"};

		SmokeShellRed[] 					= {"RED", 		"SMOKE"};
		1Rnd_SmokeRed_Grenade_shell[] 		= {"RED", 		"SMOKE"};
		3Rnd_SmokeRed_Grenade_shell[] 		= {"RED", 		"SMOKE"};
				
		SmokeShellYellow[] 					= {"YELLOW", 	"SMOKE"};
		1Rnd_SmokeYellow_Grenade_shell[] 	= {"YELLOW", 	"SMOKE"};
		3Rnd_SmokeYellow_Grenade_shell[] 	= {"YELLOW", 	"SMOKE"};
				
		UGL_FlareCIR_F[] 					= {"IR", 		"FLARE"};
		3Rnd_UGL_FlareCIR_F[] 				= {"IR", 		"FLARE"};

		UGL_FlareGreen_F[] 					= {"GREEN", 	"FLARE"};
		3Rnd_UGL_FlareGreen_F[] 			= {"GREEN", 	"FLARE"};

		UGL_FlareRed_F[] 					= {"RED", 		"FLARE"};
		3Rnd_UGL_FlareRed_F[] 				= {"RED", 		"FLARE"};

		UGL_FlareWhite_F[] 					= {"WHITE", 	"FLARE"};
		3Rnd_UGL_FlareWhite_F[] 			= {"WHITE", 	"FLARE"};

		UGL_FlareYellow_F[] 				= {"YELLOW", 	"FLARE"};
		3Rnd_UGL_FlareYellow_F[] 			= {"YELLOW", 	"FLARE"};

		Chemlight_blue[] 					= {"BLUE", 		"LIGHT"};
		Chemlight_green[] 					= {"GREEN", 	"LIGHT"};
		Chemlight_red[] 					= {"RED", 		"LIGHT"};
		Chemlight_yellow[] 					= {"YELLOW", 	"LIGHT"};

		1Rnd_HE_Grenade_shell[] 			= {"40MM"};
		3Rnd_HE_Grenade_shell[] 			= {"40MM"};

		O_IR_Grenade[] 						= {"IR"};
		I_IR_Grenade[] 						= {"IR"};
		B_IR_Grenade[] 						= {"IR"};

		HandGrenade[] 						= {"RGO"};
		MiniGrenade[] 						= {"RGN"};
		
		rhs_mag_m67[]      		            = {"M67"};
        rhs_mag_rgn[]                       = {"RGN"};
        rhs_mag_rgo[]                       = {"RGO"};
        rhs_mag_rgd5[]                      = {"RGD5"};
        rhs_mag_m69[]                       = {"M69",       "PRACT"};      
        rhs_mag_m18_green[]                 = {"M18-G",         "SMOKE"};
        rhs_mag_m18_purple[]                = {"M18-P",         "SMOKE"};
        rhs_mag_m18_red[]                   = {"M18-R",         "SMOKE"};
        rhs_mag_m18_yellow[]                = {"M18-Y",         "SMOKE"};
        rhs_mag_rdg2_black[]                = {"RDG2-B",        "SMOKE"};
        rhs_mag_rdg2_white[]                = {"RDG2-W",        "SMOKE"};
        rhs_mag_nspd[]                      = {"NSPD",          "FLARE"};
        rhs_mag_nspn_green[]                = {"NSPN-G",        "FLARE"};
        rhs_mag_nspn_red[]                  = {"NSPN-R",        "FLARE"};
        rhs_mag_nspn_yellow[]               = {"NSPN-Y",        "FLARE"};
		rhs_mag_fakel[]				        = {"FAKEL"};
		rhs_mag_fakels[]					= {"FAKELS"};
		rhs_mag_m7a3_cs[]					= {"M7A3_CS"};
		rhs_mag_mk84[]						= {"MK84"};
		rhs_mag_mk3a2[]						= {"MK3A2"};
		rhs_mag_plamyam[]					= {"PLAMYA"};
		rhs_mag_zarya2[]					= {"ZARYA-2"};

		Exile_Item_ZipTie[]					= {"ZIP", "TIE"};
	};
};

class CfgExileLootSettings
{
	lifeTime = 30;
	spawnInterval = 15;
	maximumPositionCoverage = 30;
	maximumNumberOfLootSpotsPerBuilding = 3;
	maximumNumberOfItemsPerLootSpot = 5;
	midNumberOfItemsPerLootSpot = 3;
	minimumNumberOfItemsPerLootSpot = 1;
	percentageChanceToSpawnCrate = 1; // 2 = 2% chance to spawn a crate.  Keep it low.
	numberOfItemsPerCrate = 50;
	spawnRadius = 60;
	minimumDistanceToTraderZones = 500;
	minimumDistanceToTerritories = 150;
};

class CfgExileMobileXM8
{
	code = "";
};

class CfgExileMusic
{
	Ambient[] = {"ExileTrack03","ExileTrack04"};
	Combat[] = {"ExileTrack06","ExileTrack07"};
	Intro[] = {"ExileTrack02","ExileTrack03"};
};

class CfgExileParty 
{
	showESP = 1;
	allow3DMarkers = 1;
};

class CfgExileRussianRoulette
{
	buyInAmount = 100;
};

class CfgFlags 
{
	class USA
	{
		name = "USA";
		texture = "\A3\Data_F\Flags\flag_us_co.paa";
		uids[] = {};
	};
	class UNO
	{
		name = "UNO";
		texture = "\A3\Data_F\Flags\Flag_uno_CO.paa";
		uids[] = {};
	};
	class WhiteDamage
	{
		name = "White damage";
		texture = "\A3\Data_F\Flags\flag_white_dmg_co.paa";
		uids[] = {};
	};
	class IDAP
	{
		name = "IDAP";
		texture = "\A3\Data_F_Orange\Flags\flag_IDAP_CO.paa";
		uids[] = {};
	};
	class Syndikat
	{
		name = "Syndikat";
		texture = "\A3\Data_F_Exp\Flags\flag_SYND_CO.paa";
		uids[] = {};
	};
	class ddr
	{
		name = "DDR";
		texture = "\ddr_markers\flag\flag_ddr_co.paa";
		uids[] = {};
	};
	class Spanien
	{
		name = "Spanien";
		texture = "\ddr_markers\flag\flag_spanisch_co.paa";
		uids[] = {};
	};
	class Sachsen
	{
		name = "Sachsen";
		texture = "\ddr_markers\flag\flag_sachsen_co.paa";
		uids[] = {};
	};
	class Bayern
	{
		name = "Bayern";
		texture = "\ddr_markers\flag\flag_bayern_co.paa";
		uids[] = {};
	};
	class Baden_wuerttemberg
	{
		name = "Baden Württemberg";
		texture = "\ddr_markers\flag\flag_baden_wuerttemberg_co.paa";
		uids[] = {};
	};
	class Rheinland_pfalz
	{
		name = "Rheinland Pfalz";
		texture = "\ddr_markers\flag\flag_rheinland_pfalz_co.paa";
		uids[] = {};
	};
	class Bremen
	{
		name = "Bremen";
		texture = "\ddr_markers\flag\flag_bremen_co.paa";
		uids[] = {};
	};
	class Schleswig_holstein
	{
		name = "Schleswig Holstein";
		texture = "\ddr_markers\flag\flag_schleswig_holstein_co.paa";
		uids[] = {};
	};
	class Berlin
	{
		name = "Berlin";
		texture = "\ddr_markers\flag\flag_berlin_co.paa";
		uids[] = {};
	};
	class Nordrhein_westfalen
	{
		name = "Nordrhein Westfalen";
		texture = "\ddr_markers\flag\flag_nordrhein_westfalen_co.paa";
		uids[] = {};
	};
	class Brandenburg
	{
		name = "Brandenburg";
		texture = "\ddr_markers\flag\flag_brandenburg_co.paa";
		uids[] = {};
	};
	class Sachsen_anhalt
	{
		name = "Sachsen Anhalt";
		texture = "\ddr_markers\flag\flag_sachsen_anhalt_co.paa";
		uids[] = {};
	};
	class Thueringen
	{
		name = "Thüringen";
		texture = "\ddr_markers\flag\flag_thueringen_co.paa";
		uids[] = {};
	};
	class Hamburg
	{
		name = "Hamburg";
		texture = "\ddr_markers\flag\flag_hamburg_co.paa";
		uids[] = {};
	};
	class Niedersachsen
	{
		name = "Niedersachsen";
		texture = "\ddr_markers\flag\flag_niedersachsen_co.paa";
		uids[] = {};
	};
	class Saarland
	{
		name = "Saarland";
		texture = "\ddr_markers\flag\flag_saarland_co.paa";
		uids[] = {};
	};
	class Hessen
	{
		name = "Hessen";
		texture = "\ddr_markers\flag\flag_hessen_co.paa";
		uids[] = {};
	};
	class Mecklenburg_vorpommern
	{
		name = "Mecklenburg Vorpommern";
		texture = "\ddr_markers\flag\flag_mecklenburg_vorpommern_co.paa";
		uids[] = {};
	};
};

/*
class CfgGrinding
{
	// Enables code lock grinding on the server
	enableGrinding = 1;
	
	// Time it takes to grind a fresh lock in minutes
	grindDuration = 25;
	
	// Percentage chance the grinding will fail
	failChance = 25;
	
	// Percentage chance that failing will break your grinder (otherwise it will just remove a battery)
	breakChance = 20;
	
	// Notify the entire server if someone is hacking. 1 == notify, 0 == don't notify
	notifyServer = 1;
	
	// The cooldown time, in minutes, before another server side notification is sent out from a territory. This is on a per territory basis. 
	notificationCooldown = 30;
};
class CfgHacking 
{
	// Enables safe hacking on the server
	enableHacking = 1;
	
	// Time it takes to hack in minutes
	hackDuration = 20;
	
	// Percentage chance the hacking will fail
	failChance = 50;
	
	// Percentage chance the laptop will be removed on fail
	removeChance = 5;
	
	// Max attepts to hack a safe during one restart
	maxHackAttempts = 3;
	
	// Notify the entire server if someone is hacking. 1 == notify, 0 == don't notify
	notifyServer = 1;
	
	// The cooldown time, in minutes, before another server side notification is sent out from a territory. This is on a per territory basis. 
	notificationCooldown = 30;
	
	// The minimal amount of players on the server required in order to hack a safe (set to 0 to disable)
	minPlayers = 1;
	
	// How many safe hacks are allowed to be going at one time
	maxHacks = 5;
	
	// Show a map icon where the hacking is taking place
	showMapIcon = 1;
};*/

class ExileAbstractAction
{
	title = "";
	condition = "true";
	action = "";
	priority = 1.5;
	showWindow = false;
};

class CfgInteractionMenus
{
	#include "Custom\EBM\menus.hpp"
	#include "VirtualGarageP\CfgInteractionMenus.h"
	class Car
	{
		targetType = 2;
		target = "Car";

		class Actions 
		{
		    // Pack Bike
			class PackDeployedVehicle: ExileAbstractAction
			{
				title = "<img size='1'image='\exile_assets\texture\ui\xm8_app_settings_ca.paa'/> <t color='#eeba30'>Разобрать Транспорт</t>";          //title = "Разобрать Транспорт";		
				condition = "call ExAd_XM8_DV_fnc_canPack";
				action = "call ExAd_XM8_DV_fnc_pack";
			};
			class Lock: ExileAbstractAction
			{
				title = "<t color='#e90106'>Закрыть</t>";
				condition = "((locked ExileClientInteractionObject) isEqualTo 0) && ((locked ExileClientInteractionObject) != 1)";
				action = "true spawn ExileClient_object_lock_toggle";
			};
			class Unlock: ExileAbstractAction
			{
				title = "Открыть";
				condition = "((locked ExileClientInteractionObject) isEqualTo 2) && ((locked ExileClientInteractionObject) != 1)";
				action = "false spawn ExileClient_object_lock_toggle";
			};
            class ClaimVehicle: ExileAbstractAction
            {
                title = "Установить Кодовый Замок";
                condition = "true";
                action = "call ExileClient_ClaimVehicles_network_claimRequestSend";
            };
			class Repair: ExileAbstractAction
			{
				title = "Ремонтировать";
				condition = "true";
				action = "['RepairVehicle', _this select 0] call ExileClient_action_execute";
			};
			class Flip: ExileAbstractAction
			{
				title = "Перевернуть";
				condition = "call ExileClient_object_vehicle_interaction_show";
				action = "_this call ExileClient_object_vehicle_flip";
			};
			class Refuel: ExileAbstractAction
			{
				title = "Заправить";
				condition = "call ExileClient_object_vehicle_interaction_show";
				action = "_this call ExileClient_object_vehicle_refuel";
			};
			class DrainFuel: ExileAbstractAction
			{
				title = "Слить топливо";
				condition = "call ExileClient_object_vehicle_interaction_show";
				action = "_this call ExileClient_object_vehicle_drain";
			};
			class Paint: ExileAbstractAction
		    {
			    title = "Покрасить";
			    condition = "(((ExileClientInteractionObject getVariable ['ExileAlreadyKnownCode','']) != '') && ((locked ExileClientInteractionObject) == 0) && ((locked ExileClientInteractionObject) != 1) || ((local ExileClientInteractionObject) && (locked ExileClientInteractionObject) == 1))";
			    action = "_this spawn SM_Paint_Show";
		    };
			class ServicePointRepair: ExileAbstractAction
			{
				title = "Автосервис";
				condition = "(count (nearestObjects [(getPos player), buildingObjects ,vmsRange]) >0) && (enableServicePoint == 1) && ['playerCall', getPos player] Call Bones_fnc_vmsChecks";
				action = "_this call Bones_fnc_showServicePointDialogue";
			};
			class Loot: ExileAbstractAction
			{
				title = "Достать Лут из техники";
			    condition = "(!(alive (ExileClientInteractionObject)))";
				action = "_this spawn ExileClient_object_container_pack";
		    };
			class GetInDLCDriver: ExileAbstractAction
			{
				title = "['DLC Водитель'] call ExileClient_object_vehicle_getInteractionName";
				condition = "['Driver'] call ExileClient_object_vehicle_checkForDLCAndSeat";
				action = "['Driver'] call ExileClient_object_vehicle_moveInSeat";
				priority = 6;
			};
			class GetInDLCGunner: ExileAbstractAction
			{
				title = "['DLC Стрелок'] call ExileClient_object_vehicle_getInteractionName";
				condition = "['Gunner'] call ExileClient_object_vehicle_checkForDLCAndSeat";
				action = "['Gunner'] call ExileClient_object_vehicle_moveInSeat";
				priority = 6;
			};
			class GetInDLCCommander: ExileAbstractAction
			{
				title = "['DLC Командир'] call ExileClient_object_vehicle_getInteractionName";
				condition = "['Commander'] call ExileClient_object_vehicle_checkForDLCAndSeat";
				action = "['Commander'] call ExileClient_object_vehicle_moveInSeat";
				priority = 6;
			};
		};
	};

	class Air
	{
		target = "Air";
		targetType = 2;

		class Actions
		{
			class PackDeployedVehicle: ExileAbstractAction
			{
				title = "<img size='1'image='\exile_assets\texture\ui\xm8_app_settings_ca.paa'/> <t color='#eeba30'>Разобрать Транспорт</t>"; 
				condition = "call ExAd_XM8_DV_fnc_canPack";
				action = "call ExAd_XM8_DV_fnc_pack";
			};	
			class Lock: ExileAbstractAction
			{
				title = "Закрыть";
				condition = "((locked ExileClientInteractionObject) isEqualTo 0) && ((locked ExileClientInteractionObject) != 1)";
				action = "true spawn ExileClient_object_lock_toggle";
			};
			class Unlock: ExileAbstractAction
			{
				title = "Открыть";
				condition = "((locked ExileClientInteractionObject) isEqualTo 2) && ((locked ExileClientInteractionObject) != 1)";
				action = "false spawn ExileClient_object_lock_toggle";
			};
            class ClaimVehicle: ExileAbstractAction
            {
                title = "Установить Кодовый Замок";
                condition = "true";
                action = "call ExileClient_ClaimVehicles_network_claimRequestSend";
            };
			class Repair: ExileAbstractAction
			{
				title = "Ремонтировать";
				condition = "true";
				action = "['RepairVehicle', _this select 0] call ExileClient_action_execute";
			};
			class Flip: ExileAbstractAction
			{
				title = "Перевернуть";
				condition = "call ExileClient_object_vehicle_interaction_show";
				action = "_this call ExileClient_object_vehicle_flip";
			};
			class Refuel: ExileAbstractAction
			{
				title = "Заправить";
				condition = "call ExileClient_object_vehicle_interaction_show";
				action = "_this call ExileClient_object_vehicle_refuel";
			};
			class DrainFuel: ExileAbstractAction
			{
				title = "Слить топливо";
				condition = "call ExileClient_object_vehicle_interaction_show";
				action = "_this call ExileClient_object_vehicle_drain";
			};
			class RotateLeft: ExileAbstractAction
			{
				title = "Повернуть влево";	
				condition = "call ExileClient_object_vehicle_interaction_show";
				action = "[ExileClientInteractionObject,-15] call ExileClient_object_vehicle_rotate";
			};
			class RotateRight: ExileAbstractAction
			{
				title = "Повернуть вправо";
				condition = "call ExileClient_object_vehicle_interaction_show";
				action = "[ExileClientInteractionObject,15] call ExileClient_object_vehicle_rotate";
			};
			class Paint: ExileAbstractAction
		    {
			    title = "Покрасить";
			    condition = "(((ExileClientInteractionObject getVariable ['ExileAlreadyKnownCode','']) != '') && ((locked ExileClientInteractionObject) == 0) && ((locked ExileClientInteractionObject) != 1) || ((local ExileClientInteractionObject) && (locked ExileClientInteractionObject) == 1))";
			    action = "_this spawn SM_Paint_Show";
		    };
			class ServicePointRepair: ExileAbstractAction
			{
				title = "Автосервис";
				condition = "(count (nearestObjects [(getPos player), buildingObjects ,vmsRange]) >0) && (enableServicePoint == 1) && ['playerCall', getPos player] Call Bones_fnc_vmsChecks";
				action = "_this call Bones_fnc_showServicePointDialogue";
			};
			class Loot: ExileAbstractAction
			{
				title = "Достать Лут из техники";
			    condition = "(!(alive (ExileClientInteractionObject)))";
				action = "_this spawn ExileClient_object_container_pack";
		    };
			class GetInDLCDriver: ExileAbstractAction
			{
				title = "['DLC Водитель'] call ExileClient_object_vehicle_getInteractionName";
				condition = "['Driver'] call ExileClient_object_vehicle_checkForDLCAndSeat";
				action = "['Driver'] call ExileClient_object_vehicle_moveInSeat";
				priority = 6;
			};
			class GetInDLCGunner: ExileAbstractAction
			{
				title = "['DLC Стрелок'] call ExileClient_object_vehicle_getInteractionName";
				condition = "['Gunner'] call ExileClient_object_vehicle_checkForDLCAndSeat";
				action = "['Gunner'] call ExileClient_object_vehicle_moveInSeat";
				priority = 6;
			};
			class GetInDLCCommander: ExileAbstractAction
			{
				title = "['DLC Командир'] call ExileClient_object_vehicle_getInteractionName";
				condition = "['Commander'] call ExileClient_object_vehicle_checkForDLCAndSeat";
				action = "['Commander'] call ExileClient_object_vehicle_moveInSeat";
				priority = 6;
			};
		};
	};
	
	class Tank 
	{
		targetType = 2;
		target = "Tank";

		class Actions 
		{
			class Lock: ExileAbstractAction
			{
				title = "Закрыть";
				condition = "((locked ExileClientInteractionObject) isEqualTo 0) && ((locked ExileClientInteractionObject) != 1)";
				action = "true spawn ExileClient_object_lock_toggle";
			};
			class Unlock: ExileAbstractAction
			{
				title = "Открыть";
				condition = "((locked ExileClientInteractionObject) isEqualTo 2) && ((locked ExileClientInteractionObject) != 1)";
				action = "false spawn ExileClient_object_lock_toggle";
			};
            class ClaimVehicle: ExileAbstractAction
            {
                title = "Установить Кодовый Замок";
                condition = "true";
                action = "call ExileClient_ClaimVehicles_network_claimRequestSend";
            };
			class Repair: ExileAbstractAction
			{
				title = "Ремонтировать";
				condition = "true";
				action = "['RepairVehicle', _this select 0] call ExileClient_action_execute";
			};
			class Flip: ExileAbstractAction
			{
				title = "Перевернуть";
				condition = "call ExileClient_object_vehicle_interaction_show";
				action = "_this call ExileClient_object_vehicle_flip";
			};
			class Refuel: ExileAbstractAction
			{
				title = "Заправить";
				condition = "call ExileClient_object_vehicle_interaction_show";
				action = "_this call ExileClient_object_vehicle_refuel";
			};
			class DrainFuel: ExileAbstractAction
			{
				title = "Слить топливо";
				condition = "call ExileClient_object_vehicle_interaction_show";
				action = "_this call ExileClient_object_vehicle_drain";
			};
			class Paint: ExileAbstractAction
		    {
			    title = "Покрасить";
			    condition = "(((ExileClientInteractionObject getVariable ['ExileAlreadyKnownCode','']) != '') && ((locked ExileClientInteractionObject) == 0) && ((locked ExileClientInteractionObject) != 1) || ((local ExileClientInteractionObject) && (locked ExileClientInteractionObject) == 1))";
			    action = "_this spawn SM_Paint_Show";
		    };
			class ServicePointRepair: ExileAbstractAction
			{
				title = "Автосервис";
				condition = "(count (nearestObjects [(getPos player), buildingObjects ,vmsRange]) >0) && (enableServicePoint == 1) && ['playerCall', getPos player] Call Bones_fnc_vmsChecks";
				action = "_this call Bones_fnc_showServicePointDialogue";
			};
			class Loot: ExileAbstractAction
			{
				title = "Достать Лут из техники";
			    condition = "(!(alive (ExileClientInteractionObject)))";
				action = "_this spawn ExileClient_object_container_pack";
		    };
			class GetInDLCDriver: ExileAbstractAction
			{
				title = "['DLC Водитель'] call ExileClient_object_vehicle_getInteractionName";
				condition = "['Driver'] call ExileClient_object_vehicle_checkForDLCAndSeat";
				action = "['Driver'] call ExileClient_object_vehicle_moveInSeat";
				priority = 6;
			};
			class GetInDLCGunner: ExileAbstractAction
			{
				title = "['DLC Стрелок'] call ExileClient_object_vehicle_getInteractionName";
				condition = "['Gunner'] call ExileClient_object_vehicle_checkForDLCAndSeat";
				action = "['Gunner'] call ExileClient_object_vehicle_moveInSeat";
				priority = 6;
			};
			class GetInDLCCommander: ExileAbstractAction
			{
				title = "['DLC Командир'] call ExileClient_object_vehicle_getInteractionName";
				condition = "['Commander'] call ExileClient_object_vehicle_checkForDLCAndSeat";
				action = "['Commander'] call ExileClient_object_vehicle_moveInSeat";
				priority = 6;
			};
		};
	};
	
	class Safe
	{
		targetType = 2;
		target = "Exile_Container_Abstract_Safe";

		class Actions 
		{
			class Lock : ExileAbstractAction
			{
				title = "Закрыть";
				condition = "((ExileClientInteractionObject getvariable ['ExileIsLocked',1]) isEqualTo 0)";
				action = "true spawn ExileClient_object_lock_toggle";
			};
			class Unlock : ExileAbstractAction
			{
				title = "Открыть";
				condition = "((ExileClientInteractionObject getvariable ['ExileIsLocked',1]) isEqualTo -1)";
				action = "false spawn ExileClient_object_lock_toggle";
			};
			class Pack : ExileAbstractAction
			{
				title = "Упаковать";
				condition = "((ExileClientInteractionObject getvariable ['ExileIsLocked',1]) isEqualTo 0)";
				action = "_this spawn ExileClient_object_container_pack";
			};
			class SetPinCode : ExileAbstractAction
			{
				title = "Сменить пароль";
				condition = "((ExileClientInteractionObject getvariable ['ExileIsLocked',1]) isEqualTo 0)";
				action = "_this spawn ExileClient_object_lock_setPin";
			};
		};
	};

	class Laptop
	{
		targetType = 2;
		target = "Exile_Construction_Laptop_Static";

		class Actions
		{
			class CameraSystem: ExileAbstractAction
			{
				title = "CCTV Доступ";
				condition = "((ExileClientInteractionObject animationPhase 'LaptopLidRotation') >= 0.5)";
				action = "_this call ExileClient_gui_baseCamera_show";
			};
		};
	};

	class SupplyBox
	{
		targetType = 2;
		target = "Exile_Container_SupplyBox";

		class Actions
		{
			class Mount: ExileAbstractAction
			{
				title = "Монтировать";
				condition = "(isNull (attachedTo ExileClientInteractionObject)) && ((ExileClientInteractionObject getvariable ['ExileOwnerUID',1]) isEqualTo 1)";
				action = "_this call ExileClient_object_supplyBox_mount";
			};
			class Install: ExileAbstractAction
			{
				title = "Установка";
				condition = "isNull (attachedTo ExileClientInteractionObject) && ((ExileClientInteractionObject getvariable ['ExileOwnerUID',1]) isEqualTo 1)";
				action = "_this call ExileClient_object_supplyBox_install";
			};
			class Unmount: ExileAbstractAction
			{
				title = "Демонтаж";
				condition = "!(isNull (attachedTo ExileClientInteractionObject)) && ((ExileClientInteractionObject getvariable ['ExileOwnerUID',1]) isEqualTo 1)";
				action = "_this call ExileClient_object_supplyBox_unmount";
			};
		};
	};
	
	class SupplyBox_2
	{
		targetType = 2;
		target = "I_CargoNet_01_ammo_F";

		class Actions
		{
			class PackDeployedVehicle: ExileAbstractAction
			{
				title = "<img size='1'image='\exile_assets\texture\ui\xm8_app_settings_ca.paa'/> <t color='#eeba30'>Разобрать Ящик</t>"; 
				condition = "call ExAd_XM8_DV_fnc_canPack";
				action = "call ExAd_XM8_DV_fnc_pack";
			};
		};
	};	
	
	class Drawbridge
	{
		targetType = 2;
		target = "Exile_Construction_Abstract_DrawBridge";

		class Actions
		{
			class Lower: ExileAbstractAction
			{
				title = "Разложить";
				condition = "ExileClientInteractionObject call ExileClient_object_construction_openBridgeShow";
				action = "ExileClientInteractionObject animateSource ['DrawBridge_Source', 0];";
			};
			class Raise: ExileAbstractAction
			{
				title = "Сложить";
				condition = "((ExileClientInteractionObject animationSourcePhase 'DrawBridge_Source') < 0.5)";
				action = "ExileClientInteractionObject animateSource ['DrawBridge_Source', 2]";
			};
			class Paint: ExileAbstractAction
		    {
			    title = "Покрасить";
			    condition = "call ExileClient_util_world_isInOwnTerritory";
			    action = "_this spawn SM_Paint_Show";
		    };
		};
	};
	
	class ATM
    {
        targetType = 2;
        target = "Land_Atm_01_F";
		
        class Actions
        {
            class Locker: ExileAbstractAction
            {
                title = "Положить|Снять Деньги";
                condition = "true";
                action = "_this call ExileClient_gui_lockerDialog_show";
            };
        };
    };
	
	class ATM2
    {
        targetType = 2;
        target = "Land_Atm_02_F_Preview";
		
        class Actions
        {
            class Locker: ExileAbstractAction
            {
                title = "Положить|Снять Деньги";
                condition = "true";
                action = "_this call ExileClient_gui_lockerDialog_show";
            };
        };
    };
	
    class ATM4
    {
        targetType = 2;
        target = "Land_Atm_02_F";
		
        class Actions
        {
            class Locker: ExileAbstractAction
            {
                title = "Положить|Снять Деньги";
                condition = "true";
                action = "_this call ExileClient_gui_lockerDialog_show";
            };
        };
    };
	
	class Wire: ExileAbstractAction
    {
        targetType = 2;
        target = "Land_Atm_01_F";
		 
        class Actions 
        {
            class WireTransfer: ExileAbstractAction
            {
                title = "Денежный Перевод";
                condition = "ExilePlayerInSafezone";
                action = "call KBC_wire_fnc_showDialog";
            };
        };
    };

	class Construction
	{
		targetType = 2;
		target = "Exile_Construction_Abstract_Static";

		class Actions 
		{
			class Unlock : ExileAbstractAction
			{
				title = "Открыть";
				condition = "((ExileClientInteractionObject getvariable ['ExileIsLocked',1]) isEqualTo -1)";
				action = "false spawn ExileClient_object_lock_toggle";
			};
			class Lock : ExileAbstractAction
			{
				title = "Закрыть";
				condition = "((ExileClientInteractionObject getvariable ['ExileIsLocked',1]) isEqualTo 0)";
				action = "true spawn ExileClient_object_lock_toggle";
			};
			class Move: ExileAbstractAction
			{
				title = "Переместить";
				condition = "call ExileClient_util_world_isInOwnTerritory";
				action = "_this spawn ExileClient_object_construction_move";
			};
			class Deconstruct: ExileAbstractAction
			{
				title = "Удалить";
				condition = "call ExileClient_util_world_isInOwnTerritory";
				action = "_this spawn ExileClient_object_construction_deconstruct";
			};
			class AddALock : ExileAbstractAction
			{
				title = "Поставить Замок";
				condition = "call ExileClient_object_construction_lockAddShow";
				action = "_this spawn ExileClient_object_construction_lockAdd";
			};
			class Upgrade : ExileAbstractAction
			{
				title = "Апгрейдить";
				condition = "call ExileClient_object_construction_upgradeShow";
				action = "_this call ExileClient_object_construction_upgrade";
			};
			class Repair : ExileAbstractAction
			{
				title = "Ремонт";
				condition = "(!((ExileClientInteractionObject getVariable ['ExileConstructionDamage',0]) isEqualTo 0)) && (call ExileClient_util_world_isInOwnTerritory)";
				action = "_this call ExileClient_object_construction_repair";
			};
		    class Paint: ExileAbstractAction
		    {
			    title = "Покрасить";
			    condition = "call ExileClient_util_world_isInOwnTerritory";
			    action = "_this spawn SM_Paint_Show";
		    };
		};
	};

	class Container
	{
		targetType = 2;
		target = "Exile_Container_Abstract";

		class Actions 
		{
			class Pack 
			{
				title = "Упаковать";
				condition = "!((typeOf ExileClientInteractionObject) isEqualTo 'Exile_Container_SupplyBox')";
				action = "_this spawn ExileClient_object_container_pack";
			};
			class Move: ExileAbstractAction
			{
				title = "Передвинуть";
				condition = "(getNumber(configFile >> 'CfgVehicles' >> typeOf ExileClientInteractionObject >> 'exileIsLockable') isEqualTo 0) || ((ExileClientInteractionObject getvariable ['ExileIsLocked',1]) isEqualTo 0)";
				action = "_this spawn ExileClient_object_construction_move";
			};
		};
	};
	
	class Flag
	{
		targetType = 2;
		target = "Exile_Construction_Flag_Static";

		class Actions
		{
	        class AbandonTerritory: ExileAbstractAction
            {
              title = "Отказаться от территории";
              condition = "((typeOf ExileClientInteractionObject) isEqualTo 'Exile_Construction_Flag_Static' && (call ExileClient_util_world_isInOwnTerritory) && ((ExileClientInteractionObject getvariable ['ExileFlagStolen',1]) isEqualTo 0))";
              action = execVM "scripts\abandon.sqf";
            };
		};
	};

	class Boat
	{
		targetType = 2;
		target = "Ship";

		class Actions
		{
			class PackDeployedVehicle: ExileAbstractAction
			{
				title = "<img size='1'image='\exile_assets\texture\ui\xm8_app_settings_ca.paa'/> <t color='#eeba30'>Разобрать Транспорт</t>"; 
				condition = "call ExAd_XM8_DV_fnc_canPack";
				action = "call ExAd_XM8_DV_fnc_pack";
			};
			class Lock: ExileAbstractAction
			{
				title = "Закрыть";
				condition = "((locked ExileClientInteractionObject) isEqualTo 0) && ((locked ExileClientInteractionObject) != 1)";
				action = "true spawn ExileClient_object_lock_toggle";
			};
			class Unlock: ExileAbstractAction
			{
				title = "Открыть";
				condition = "((locked ExileClientInteractionObject) isEqualTo 2) && ((locked ExileClientInteractionObject) != 1)";
				action = "false spawn ExileClient_object_lock_toggle";
			};
			class Repair: ExileAbstractAction
			{
				title = "Ремонтировать";
				condition = "true";
				action = "['RepairVehicle', _this select 0] call ExileClient_action_execute";
			};
			class Refuel: ExileAbstractAction
			{
				title = "Заправить";
				condition = "call ExileClient_object_vehicle_interaction_show";
				action = "_this call ExileClient_object_vehicle_refuel";
			};
			class DrainFuel: ExileAbstractAction
			{
				title = "Слить топливо";
				condition = "call ExileClient_object_vehicle_interaction_show";
				action = "_this call ExileClient_object_vehicle_drain";
			};
			class Push: ExileAbstractAction
			{
				title = "Оттолкнуть!";
				condition = "((crew ExileClientInteractionObject) isEqualTo [])";
				action = "_this call ExileClient_object_vehicle_push";
			};
			class Paint: ExileAbstractAction
		    {
			    title = "Покрасить";
			    condition = "(((ExileClientInteractionObject getVariable ['ExileAlreadyKnownCode','']) != '') && ((locked ExileClientInteractionObject) == 0) && ((locked ExileClientInteractionObject) != 1) || ((local ExileClientInteractionObject) && (locked ExileClientInteractionObject) == 1))";
			    action = "_this spawn SM_Paint_Show";
		    };
			class Salvage: ExileAbstractAction
            {
                title = "Убрать Сгоревшую Технику";
                condition = "(!(alive (ExileClientInteractionObject)))";
                action = "_this call SalvageVehicle";
			};
			class ServicePointRepair: ExileAbstractAction
			{
				title = "Автосервис";
				condition = "(count (nearestObjects [(getPos player), buildingObjects ,vmsRange]) >0) && (enableServicePoint == 1) && ['playerCall', getPos player] Call Bones_fnc_vmsChecks";
				action = "_this call Bones_fnc_showServicePointDialogue";
			};
		};
	};

	class Bikes
	{
		targetType = 2;
		target = "Bicycle";

		class Actions
		{
			class Flip: ExileAbstractAction
			{
				title = "Перевернуть";
				condition = "true";
				action = "_this call ExileClient_object_vehicle_flip";
			};
		    class Paint: ExileAbstractAction
		    {
			    title = "Покрасить";
			    condition = "(((ExileClientInteractionObject getVariable ['ExileAlreadyKnownCode','']) != '') && ((locked ExileClientInteractionObject) == 0) && ((locked ExileClientInteractionObject) != 1) || ((local ExileClientInteractionObject) && (locked ExileClientInteractionObject) == 1))";
			    action = "_this spawn SM_Paint_Show";
		    };
			class Salvage: ExileAbstractAction
            {
                title = "Убрать Сгоревшую Технику";
                condition = "(!(alive (ExileClientInteractionObject)))";
                action = "_this call SalvageVehicle";
			};
			class ServicePointRepair: ExileAbstractAction
			{
				title = "Автосервис";
				condition = "(count (nearestObjects [(getPos player), buildingObjects ,vmsRange]) >0) && (enableServicePoint == 1) && ['playerCall', getPos player] Call Bones_fnc_vmsChecks";
				action = "_this call Bones_fnc_showServicePointDialogue";
			};
		};
	};

    class Player 
    {
	    targetType = 2;
	    target = "Exile_Unit_Player";

	class Actions 
	{
		class Drag: ExileAbstractAction
		{
			title = "Тащить";
			condition = "(alive ExileClientInteractionObject) && (ExileClientInteractionObject getVariable ['ExileIsHandcuffed', false]) && !(ExileClientIsHandcuffed) && !(ExileClientInteractionObject getVariable['IsBeingDragged',false])";
			action = "'Drag' call XG_DragPlayer";
		};
		class EndDrag: ExileAbstractAction
		{
			title = "Бросить тело";
			condition = "(alive ExileClientInteractionObject) && (ExileClientInteractionObject getVariable ['ExileIsHandcuffed', false]) && !(ExileClientIsHandcuffed) && (ExileClientInteractionObject getVariable['IsBeingDragged',false]) && ExileClientPlayerIsDragging";
			action = "'End' call XG_DragPlayer";
		};
		class Free: ExileAbstractAction
		{
			title = "Освободить";
			condition = "(alive ExileClientInteractionObject) && (ExileClientInteractionObject getVariable ['ExileIsHandcuffed', false]) && !(ExileClientIsHandcuffed) && !(ExileClientInteractionObject getVariable['IsBeingDragged',false]) && !(ExileClientPlayerIsDragging)";
			action = "_this call ExileClient_object_handcuffs_free";
		};
		class Search: ExileAbstractAction
		{
			title = "Проверить снаряжение";
			condition = "(alive ExileClientInteractionObject) && (ExileClientInteractionObject getVariable ['ExileIsHandcuffed', false]) && !(ExileClientIsHandcuffed) && !(ExileClientInteractionObject getVariable['IsBeingDragged',false]) && !(ExileClientPlayerIsDragging)";
			action = "_this call ExileClient_object_handcuffs_searchGear";
		};
		class Revive: ExileAbstractAction
		{
			title = "Реанимировать";
			condition = "(!(alive ExileClientInteractionObject) && (ExileClientInteractionObject getVariable ['EnigmaRevivePermitted', true]) && (magazines player find 'Exile_Item_Defibrillator' >= 0))";
			action = "_this spawn Enigma_RevivePlyr";
		};
		class Identify: ExileAbstractAction
		{
			title = "Опознать тело";
			condition = "!(alive ExileClientInteractionObject)";
			action = "_this call ExileClient_object_player_identifyBody";
			};
		};
	};
	
	class FastTravel
	{
		targetType = 2;
		target = "Land_InfoStand_V1_F";
		class Actions
		{
			class HackVG : ExileAbstractAction
			{
				title = "Путешествие";
				condition = "true";
				action = "createDialog 'ETG_FastTravelSystem_Dialog'";
			};
		};
	};

    class Weed
    {
        targetType = 2;
        target = "DDR_Weed_Plant";

        class Actions 
        {
            class HarvestWeed: ExileAbstractAction
            {
                title = "Harvest Weed";
                condition = "('Exile_Item_Knife' in (magazines player) && !ExilePlayerInSafezone)";
                action = "_this call DDR_fnc_Weed";
            };
        };
    };
    class Mushrooms
    {
        targetType = 2;
        target = "DDR_Mushrooms";

        class Actions 
        {
            class HarvestMushrooms: ExileAbstractAction
            {
                title = "Harvest Magic Mushrooms";
                condition = "('Exile_Item_Knife' in (magazines player) && !ExilePlayerInSafezone)";
                action = "_this call DDR_fnc_Mushrooms";
            };
        };
    };
    class Ore_Mining
    {
        targetType = 2;
        target = "DDR_Ore_Rock";

        class Actions 
        {
            class materials1: ExileAbstractAction
            {
                title = "Harvest For Gold Or Silver Ore";
                condition = "('DDR_Item_Pickaxe' in (magazines player) && !ExilePlayerInSafezone)";
                action = "_this call DDR_fnc_Ore_Mining";
            };
        };
    };
    class Crystal_Mining
    {
        targetType = 2;
        target = "DDR_Crystal_Rock";

        class Actions 
        {
            class materials2: ExileAbstractAction
            {
                title = "Harvest For Gems";
                condition = "('DDR_Item_Pickaxe' in (magazines player) && !ExilePlayerInSafezone)";
                action = "_this call DDR_fnc_Crystal_Mining";
            };
        };
    };
	
    class VIP_Straider
    {
        targetType = 2;
        target = "CUP_I_FENNEK_HMG_ION";
        class Actions
        {
            class HackVG : ExileAbstractAction
            {
				title = "<img size='1'image='\exile_assets\texture\ui\xm8_app_settings_ca.paa'/> <t color='#eeba30'>Разобрать Транспорт</t>"; 
                condition = "true";
                action = "_this call fnc_Straider_scrap";
            };
        };
    };	
    class VIP_Little_Bird
    {
        targetType = 2;
        target = "RHS_MELB_AH6M_L";
        class Actions
        {
            class HackVG : ExileAbstractAction
            {
				title = "<img size='1'image='\exile_assets\texture\ui\xm8_app_settings_ca.paa'/> <t color='#eeba30'>Разобрать Транспорт</t>"; 
                condition = "true";
                action = "_this call fnc_LittleBird_scrap";
            };
        };
    };	
    class VIP_Deploy_Turel
    {
        targetType = 2;
        target = "B_AAA_System_01_F";
        class Actions
        {
            class HackVG : ExileAbstractAction
            {
				title = "<img size='1'image='\exile_assets\texture\ui\xm8_app_settings_ca.paa'/> <t color='#eeba30'>Разобрать Турель</t>"; 
                condition = "true";
                action = "_this call fnc_Turel_scrap";
            };
        };
    };
    class VIP_Boat
    {
        targetType = 2;
        target = "O_Boat_Armed_01_hmg_F";
        class Actions
        {
            class HackVG : ExileAbstractAction
            {
				title = "<img size='1'image='\exile_assets\texture\ui\xm8_app_settings_ca.paa'/> <t color='#eeba30'>Разобрать Транспорт</t>"; 
                condition = "true";
                action = "_this call fnc_Boat_scrap";
            };
        };
    };
};

class CfgInteractionModels
{
	class WaterSource
	{
		name = "Water tanks, barrels, coolers or pumps";
		models[] = 	
		{
			"barrelwater_f", 
			"barrelwater_grey_f",
			"waterbarrel_f",
			"watertank_f",
			"Tank_rust_F",// added new
			"Sink_F",// added new
			"Slingload_01_Fuel_F",// added new
			"stallwater_f",
			"waterpump_01_f",
			"water_source_f",

			// Namalsk
			"wellpump",
			"Land_jhad_stand_water",
			"Land_Jbad_Misc_Well_L",
			"Land_jbad_Fridge",
			"Land_jbad_reservoir",
			"Land_jbad_teapot",
			"Land_KBud",
			
			//Tanoa
			"watertank_01_f",
			"watertank_02_f",
			"watertank_03_f",
			"watertank_04_f"
		};
	};

	class CleanWaterSource
	{
		name = "Water cooler";
		models[] = 	
		{
			"watercooler"
		};
	};

	class WorkBench
	{
		name = "Work Bench";
		models[] = 
		{
			"workstand_f.p3d"
		};
	};

	class ShippingContainerSource
	{
		name = "Shipping Containers";
		models[] = 
		{
			// Arma 3
			"CargoBox_V1_F",
			"Cargo20_blue_F",
			"Cargo20_brick_red_F",
			"Cargo20_cyan_F",
			"Cargo20_grey_F",
			"Cargo20_light_blue_F",
			"Cargo20_light_green_F",
			"Cargo20_military_green_F",
			"Cargo20_military_ruins_F",
			"Cargo20_orange_F",
			"Cargo20_red_F",
			"Cargo20_sand_F",
			"Cargo20_white_F",
			"Cargo20_yellow_F",
			"Cargo40_blue_F",
			"Cargo40_brick_red_F",
			"Cargo40_cyan_F",
			"Cargo40_grey_F",
			"Cargo40_light_blue_F",
			"Cargo40_light_green_F",
			"Cargo40_military_green_F",
			"Cargo40_orange_F",
			"Cargo40_red_F",
			"Cargo40_sand_F",
			"Cargo40_white_F",
			"Cargo40_yellow_F",

			// Namalsk
			"nam_container.p3d",
			"misc_cargo1d.p3d",
			"misc_cargo1b.p3d",
			"misc_cargo1bo.p3d",
			"misc_cargo2c.p3d",
			"misc_cargo1ao.p3d",
			
			//Tanoa
			"Land_ContainerLine_01_F",
			"Land_ContainerLine_02_F",
			"Land_ContainerLine_03_F",

			// Also allow wrecks
			"wreck_"
/*			
			"wreck_bmp2_f.p3d",
			"wreck_brdm2_f.p3d",
			"wreck_car2_f.p3d",
			"wreck_car3_f.p3d",
			"wreck_car_f.p3d",
			"wreck_cardismantled_f.p3d",
			"wreck_hmmwv_f.p3d",
			"wreck_hunter_f.p3d",
			"wreck_offroad2_f.p3d",
			"wreck_offroad_f.p3d",
			"wreck_skodovka_f.p3d",
			"wreck_slammer_f.p3d",
			"wreck_slammer_hull_f.p3d",
			"wreck_slammer_turret_f.p3d",
			"wreck_t72_hull_f.p3d",
			"wreck_t72_turret_f.p3d",
			"wreck_truck_dropside_f.p3d",
			"wreck_truck_f.p3d",
			"wreck_uaz_f.p3d",
			"wreck_ural_f.p3d"
			"wreck_van_f.p3d",
			*/


			// TODO: Ask community for CUP/AiA model names	
		};
	};

	class WoodSource
	{
		name = "Trees";
		models[] = 
		{
			" t_",
			" bo_t_",

			// A2 trees
            " str_",
            " Smrk_",
            " les_",
            " brg_"			
		};
	};

	// TODO: Add https://community.bistudio.com/wikidata/images/thumb/6/60/Arma3_CfgVehicles_Land_Tank_rust_F.jpg/150px-Arma3_CfgVehicles_Land_Tank_rust_F.jpg
	class FuelSource
	{
		name = "Fuel pumps, stations or barrels";
		models[] = 
		{
			"fuelstation_feed_f.p3d",
			"metalbarrel_f.p3d",
			"flexibletank_01_f.p3d",
			"fs_feed_f.p3d",
			//Tanoa
			"fuelstation_01_pump_f.p3d",
			"fuelstation_02_pump_f.p3d"
		};	
	};
};

class CfgLocker 
{
	numbersOnly = "0123456789";
	maxDeposit = 500000000;
	multiplyer = 2; // множитель для увеличения максимальной суммы депозита
};

class CfgPlayer 
{
	// In minutes ammount of time it takes to go from 100 - 0 if stationary
	hungerDecay = 100;
	thirstDecay = 100;
	// Damage taken from 0 (health||thirst)/sec
	healthDecay = 5.0;
	// Health regen if over BOTH
	thirstRegen = 90;
	hungerRegen = 90;
	// IF above meet recover HP%/MIN
	recoveryPerMinute = 2;
	// Set custom aim precision coefficient for weapon sway
	// https://community.bistudio.com/wiki/Arma_3_Stamina
	// Set to -1 if you want to use Arma 3 default value
	// setCustomAimCoef
	customAimCoefficient = 0.5;
	// 0 or 1
	enableFatigue = 0;
	enableStamina = 0;
	disableMapDrawing = 1;
	// Use the current gradient to affect the players movement when autorunning.
	// 0 == default exile auto run
	useGradientAffectedAutoRun = 0;
};

class CfgPoptabStorage
{
	class Exile_Container_Safe_Small      { max = 2500000; };
	class EBM_Medikit                     { max = 2500000; };
	class Exile_Container_CamoTent        { max = 2500000; };
	class Exile_Container_Safe            { max = 2500000; };
	class Exile_Container_Storagecrate    { max = 2500000; };
	class Fridge_01_closed_F              { max = 2500000; };
	class Land_Bunker_F                   { max = 2500000; };
	class Land_Cargo20_military_green_F   { max = 2500000; };
	class Land_Cargo20_sand_F             { max = 2500000; };
	class Land_Cargo40_light_green_F      { max = 2500000; };
	class Land_CargoBox_V1_F              { max = 2500000; };
	class Land_GarbageContainer_closed_F  { max = 2500000; };
	class Land_Icebox_F                   { max = 2500000; };
	class Land_MetalCase_01_large_F       { max = 2500000; };
	class Land_Metal_rack_F               { max = 2500000; };
	class Land_Metal_wooden_rack_F        { max = 2500000; };
	class Land_Pallet_MilBoxes_F          { max = 2500000; };
	class Land_PlasticCase_01_medium_F    { max = 2500000; };
	class Land_Rack_F                     { max = 2500000; };
	class Land_ShelvesMetal_F             { max = 2500000; };
	class Land_Suitcase_F                 { max = 2500000; };
	class Land_ToolTrolley_02_F           { max = 2500000; };
};

class CfgSimulation
{
	/*
		Use Arma built in Dynamic Simulation. 
		If you have any issues with players unable to get into cars, control vehicles, fly planes, etc. try turning this off
		Options:
			0: Use Exile's built in simulation system (Same system in 1.0.3 and below)
			1: Use Dynamic Simulation
	*/
	enableDynamicSimulation = 0;
	/*
		Simulation distance settings
		For more information:
			https://community.bistudio.com/wiki/setDynamicSimulationDistance
			https://community.bistudio.com/wiki/setDynamicSimulationDistanceCoef
	*/
	// The distance, in meters, will infantry units be simulated. Default: 500m
	groupSimulationDistance = 500;
	// The distance, in meters, will vehicles with crew be simulated. Default: 350m
	vehicleSimulationDistance = 250;
	// The distance, in meters, will all vehicles without crew be simulated. Default: 250m
	emptyVehicleSimulationDistance = 250;
	// The distance, in meters, will static objects be simulated. This includes anything from a small tin can to a building. Default: 50m
	propSimulationDistance = 50;
	// Multiplies the entity activation distance by set value if the entity is moving. Default: 2
	isMovingSimulationCoef = 2;
};

class CfgSlothMachine
{
	spinCost = 100;
	Jackpot = 10100;
	
	chances[] = 
	{
		{85, ""}, 					// 85% = Nothing
		{95, "Level1"}, 			// 10% = 1pt
		{96, "Level2"}, 			// 1% = 10pt
		{97, "Level3"}, 			// 1% = 25pt
		{98, "Level4"}, 			// 1% = 50pt
		{99, "Level5"},				// 1% = 100pt
		{100, "Jackpot"} 			// 1% = Jackpot
	};

	class Prizes 
	{
		class Level1
		{
			symbol = "\exile_assets\texture\item\Exile_Item_ToiletPaper.paa";
			prize = 101;
		};

		class Level2
		{
			symbol = "\exile_assets\texture\item\Exile_Item_CockONut.paa";
			prize = 110;
		};

		class Level3
		{
			symbol = "\exile_assets\texture\item\Exile_Item_Beer.paa";
			prize = 125;
		};

		class Level4
		{
			symbol = "\exile_assets\texture\item\Exile_Item_Knife.paa";
			prize = 150;
		};

		class Level5
		{
			symbol = "\exile_assets\texture\item\Exile_Item_Safe.paa";
			prize = 200;
		};
		
		class Jackpot
		{
			symbol = "\exile_assets\texture\item\Exile_Item_XmasPresent.paa";
		};
	};
};

class CfgTerritories
{
	// Base Cost / Radius
	// Level 1 is allways for Pop Tabs, >= 2 for Respect
	prices[] = 
	{
		//Цена покупки 		    Радиус 		    Количество объектов
		{50000,				        15,			15 					}, // Level 1
		{60000,					    30,			30 					}, // Level 2 
		{70000,					    45,			45 					}, // Level 3
		{80000,					    50,			65					}, // Level 4
		{90000,					    60,			75					}, // Level 5
		{95000,					    70,			85					}, // Level 6
		{100000,					75,		    80					}, // Level 7
		{150000,					85,		    90					}, // Level 8
		{200000,					95,		    100					}, // Level 9
		{250000,					150,		150					}, // Level 10
		{5000000000,				600,		1000				}  // Level 11
	};

	// A shortcut of the above maximum radius
	maximumRadius = 600;
	// The above * 2 plus coverving the 20m you can move while placing things
	minimumDistanceToOtherTerritories = 400; 
	// Maximum number of territories a player can own
	maximumNumberOfTerritoriesPerPlayer = 1;
	/**
	 * Defines the minimum distance to safe zones / trader cities where players
	 * cannot build territories
	 */
	minimumDistanceToTraderZones = 1500;
	/**
	 * Defines the minimum distance to spawn zones where players
	 * cannot build territories
	 */
	minimumDistanceToSpawnZones = 500;
	// Amount of pop tabs per object to pay
	popTabAmountPerObject = 15;
	// Amount of minutes building is disabled after a charge has been planted
	// in a territory. This basically prevents people from placing tons of walls
	// or removing walls while their territory is under attack.
	constructionBlockDuration = 5;
};

class CfgTrading
{
	sellPriceFactor = 0.2;    // ПРОЦЕНТ ПРОДАЖИ
	rekeyPriceFactor = 0.1;
	class requiredRespect 
	{
		Level1 = 0;
		Level2 = 10000;
		Level3 = 20000;
		Level4 = 30000;
		Level5 = 45000;
		Level6 = 60000;
		Level7 = 80000;
		Level8 = 90000;
		Level9 = 100000;
		Level10 = 120000;
		Level11 = 5000000;
	};
};

class CfgVehicleCustoms
{
	#include "CustomExile\VehicleCustoms.hpp"
};

class CfgVehicleTransport 
{
	class Exile_Container_SupplyBox
	{
		vehicles[] = {"Exile_Car_Van_Abstract", "Exile_Car_Offroad_Abstract", "Exile_Car_Zamak_Abstract", "Exile_Car_HEMMT_Abstract", "Exile_Car_Tempest_Abstract"};

		class Exile_Car_Van_Abstract
		{
			attachPosition[] = {0, -1.1, 0.2};
			cargoIndizes[] = {2, 3, 4, 5, 6, 7}; 
			detachPosition[] = {0, -4.4};
		};

		class Exile_Car_Offroad_Abstract
		{
			attachPosition[] = {0, -1.6, 0.4};
			cargoIndizes[] = {1, 2, 3, 4}; 
			detachPosition[] = {0, -4};
		};

		class Exile_Car_Zamak_Abstract
		{
			attachPosition[] = {0.03, 0.3, 0};
			cargoIndizes[] = {2, 3, 4, 5, 6, 7}; 
			detachPosition[] = {0.03, -4.8};
		};

		class Exile_Car_HEMMT_Abstract
		{
			attachPosition[] = {0.05, -0.1, 0.3};
			cargoIndizes[] = {1, 2, 8, 9}; 
			detachPosition[] = {0.05, -6.1};
		};

		class Exile_Car_Tempest_Abstract
		{
			attachPosition[] = {0.08, -0.85, 0.4};
			cargoIndizes[] = {1, 6, 7, 9}; 
			detachPosition[] = {0.08, -6};
		};
	};
};

class CfgVirtualGarage
{
	enableVirtualGarage = 1;	
	canAccessGarageInCombat = 1;
	clearInventoryOnStore = 0;
	numberOfVehicles[] = 
	{
		2,			// Level 1
		5, 			// Level 2 
		10, 		// Level 3
		15, 		// Level 4
		20, 		// Level 5
		25, 		// Level 6
		30, 		// Level 7
		35, 		// Level 8
		40, 		// Level 9
		50, 		// Level 10
		10000       // Level 11
	};
	allowedVehicleTypes[] = {"Car","Tank","Plane","Air","Ship","Submarine"};
};

class CfgXM8 
{
	extraApps[] = {"ExAd_CHVD","ExAd_VG","ExAd_JX","BRAmaRecipes","BaseMarker","ExAd_SB","ExAd_APOC_Airdrop","Supply_Box","ExAd_MRZR4","ExAd_Air","ExAd_WaterScooter"};
	
	class settings
	{
		controlID = 4070;
		appID = "App01";
		title = "Settings";
	};
	class healthScanner
	{
		controlID = 4120;
		appID = "App02";
		title = "Health Scanner";
	};
	class ExAd_JX
	{
		title = "Unit Scanner";
		controlID = 85100;					//IDC:85100 -> 85200
		logo = "ExadClient\XM8\Apps\JX\logo.paa";
		onLoad = "ExAdClient\XM8\Apps\JX\onLoad.sqf";
		onOpen = "ExAdClient\XM8\Apps\JX\onOpen.sqf";
		onClose = "ExAdClient\XM8\Apps\JX\onClose.sqf";
	};
	class slothMachine
	{
		controlID = 4140;
		appID = "App03";
		title = "Sloth Machine";
	};
    class ExAd_CHVD
    {
        title = "View Distance Settings";
        controlID = 50200;                  
        config = "ExadClient\XM8\Apps\CHVD\config.sqf";
        logo = "ExadClient\XM8\Apps\CHVD\Icon_CHVD.paa";
        onLoad = "ExAdClient\XM8\Apps\CHVD\onLoad.sqf";
        onOpen = "ExAdClient\XM8\Apps\CHVD\onOpen.sqf";
        onClose = "ExAdClient\XM8\Apps\CHVD\onClose.sqf";
    };
    class ExAd_VG 
    {
        title = "Virtual Garage";
        controlID = 50000;
        logo = "ExadClient\XM8\Apps\VG\Icon_VG.paa";
        onLoad = "ExAdClient\XM8\Apps\VG\onLoad.sqf";
        onOpen = "ExAdClient\XM8\Apps\VG\onOpen.sqf";
        onClose = "ExAdClient\XM8\Apps\VG\onClose.sqf";
    };
	class BRAmaRecipes
    {
        controlID = 107000;
        title = "Recipies";
        logo = "ExAdClient\XM8\Apps\BRAmaRecipes\BRAma.paa";
        config = "ExAdClient\XM8\Apps\BRAmaRecipes\config.sqf";
        onLoad = "ExAdClient\XM8\Apps\BRAmaRecipes\onLoad.sqf";
        onOpen = "ExAdClient\XM8\Apps\BRAmaRecipes\onOpen.sqf";
    };
	class BaseMarker
	 {
		 title = "Base Marker";
		 controlID = 70001;
		 logo = "ExAdClient\XM8\Apps\BaseMarker\BaseMarker.paa";
		 onLoad = "ExAdClient\XM8\Apps\BaseMarker\onLoad.sqf";
	};
	class ExAd_SB
    {
        title = "Statsbar Settings";
        controlID = 50400;                  //IDC:50400 -> 50475 || These need to be unique and out of range from each other
        logo = "exile_assets\texture\ui\xm8_app_settings_ca.paa";
        onLoad = "ExAdClient\XM8\Apps\SB_Settings\onLoad.sqf";
    };
	class ExAd_APOC_Airdrop
    {
        title = "АирДроп";
        controlID = 66000;                    //IDC:66000 -> 66005 || These need to be unique and out of range from each other
        appID = "App14";					  //Make sure this is the same as the button you are using. For example if your next free button is "XM8_App07_Button" then this would be "App07"
		//onOpen = "Custom\DonorOnlyApps\whatever.sqf";
        config = "ExadClient\XM8\Apps\APOC_Airdrop\config.sqf";
        onLoad = "ExAdClient\XM8\Apps\APOC_Airdrop\onLoad.sqf";
        onOpen = "ExAdClient\XM8\Apps\APOC_Airdrop\onOpen.sqf";
        onClose = "ExAdClient\XM8\Apps\APOC_Airdrop\onClose.sqf";
    };
	class Supply_Box
    {
        title = "Supply Crate";
        config = "ExAdClient\XM8\Apps\DeployVehicle\config.sqf";
        logo = "Custom\images\supplybox.paa";
        bambiState = 0;
        vehicleClass = "I_CargoNet_01_ammo_F";
        recipe[] = {{"Exile_Item_DuctTape",1}};
        packable = 1;
        quickFunction = "['Supply_Box'] call ExAd_XM8_DV_fnc_spawnVehicle";
    };
	class ExAd_MRZR4
    {
        title = "Deploy MRZR4";
        config = "ExAdClient\XM8\Apps\DeployVehicle\config.sqf";
        logo = "Custom\images\mrzr4.paa";
        bambiState = 0;
        vehicleClass = "rhsusf_mrzr4_w";
        recipe[] = {{"Exile_Item_DuctTape",1}};
        packable = 1;
        autoCleanUp = 1;
        quickFunction = "['ExAd_MRZR4'] call ExAd_XM8_DV_fnc_spawnVehicle";
    };
	class ExAd_Air
    {
        title = "Deploy Air";
        config = "ExAdClient\XM8\Apps\DeployVehicle\config.sqf";
        logo = "Custom\images\Air.paa";
        bambiState = 0;
        vehicleClass = "Exile_Chopper_Hummingbird_Green";
        recipe[] = {{"Exile_Item_DuctTape",1}};
        packable = 1;
        autoCleanUp = 1;
        quickFunction = "['ExAd_Air'] call ExAd_XM8_DV_fnc_spawnVehicle";
    };
	class ExAd_WaterScooter
    {
        title = "Deploy Water Scooter";
        config = "ExAdClient\XM8\Apps\DeployVehicle\config.sqf";
        logo = "Custom\images\waterscooter.paa";
        bambiState = 0;
        vehicleClass = "Exile_Boat_WaterScooter";
        recipe[] = {{"Exile_Item_DuctTape",1}};
        packable = 1;
        autoCleanUp = 1;
        quickFunction = "['ExAd_WaterScooter'] call ExAd_XM8_DV_fnc_spawnVehicle";
    };
/*
	class ExAd_Strider    
    {
        title = "VIP Техника";
		config = "Scripts\donat_apps.sqf"; 
        logo = "ExAdClient\XM8\Apps\DeployVehicle\baik.paa";
        bambiState = 0;
        vehicleClass = "I_MRAP_03_hmg_F";
        recipe[] = {};
        packable = 1;
        autoCleanUp = 0;
        quickFunction = "['ExAd_Strider'] call ExAd_XM8_DV_fnc_spawnVehicle";
    };*/
};

class XM8_App01_Button: RscExileXM8AppButton1x1
{
    textureNoShortcut = "\exile_assets\texture\ui\xm8_app_settings_ca.paa";
    text = "Настройки";
    onButtonClick = "['settings', 0] call ExileClient_gui_xm8_slide";
    resource = "XM8SlideSettings";
};
class XM8_App02_Button: RscExileXM8AppButton1x1
{
    textureNoShortcut = "\exile_assets\texture\ui\xm8_app_health_scanner_ca.paa";
    text = "Сканер Здоровья";
    onButtonClick = "['healthScanner', 0] call ExileClient_gui_xm8_slide";
    resource = "XM8SlideHealthScanner";
};
class XM8_App03_Button: RscExileXM8AppButton1x1
{
    textureNoShortcut = "\exile_assets\texture\ui\xm8_app_slothMachine_ca.paa";
    text = "Игровой Автомат";
    onButtonClick = "['slothMachine', 0] call ExileClient_gui_xm8_slide";
    resource = "XM8SlideSlothMachine";
};
class XM8_App04_Button: RscExileXM8AppButton1x1
{
    textureNoShortcut = "\exile_assets\texture\ui\xm8_app_boom_ca.paa";
    text = "BOOM!";
    onButtonClick = "call ExileClient_system_breaching_detonate";
    resource = "";
};
class XM8_App05_Button: RscExileXM8AppButton1x1
{
    textureNoShortcut = "ExadClient\XM8\Apps\Info\Icon_SI.paa";
    text = "Правила и Информация";
	onButtonClick = "ExileClientXM8CurrentSlide = 'apps';closeDialog 0;createDialog 'RscDisplayServerInfoMenu'";
    //onButtonClick = "['ExAd_Info', 0] call ExileClient_gui_xm8_slide";
    resource = "";
};
class XM8_App06_Button: RscExileXM8AppButton1x1
{
    textureNoShortcut = "ExadClient\XM8\Apps\CHVD\Icon_CHVD.paa";
    text = "Настройка прорисовки";
    onButtonClick = "['ExAd_CHVD', 0] call ExileClient_gui_xm8_slide";
    resource = "";
};
class XM8_App07_Button: RscExileXM8AppButton1x1
{
    textureNoShortcut = "ExAdClient\XM8\Apps\BRAmaRecipes\BRAma.paa";
    text = "Рецепты Брама";
    onButtonClick = "['BRAmaRecipes', 0] call ExileClient_gui_xm8_slide";
    resource = "";
};
class XM8_App08_Button: RscExileXM8AppButton1x1
{
    textureNoShortcut = "ExAdClient\XM8\Apps\BaseMarker\BaseMarker.paa";
    text = "Маркер Базы";
    onButtonClick = "['Basemarker', 0] call ExileClient_gui_xm8_slide";
    resource = "";
};
class XM8_App09_Button: RscExileXM8AppButton1x1
{
    textureNoShortcut = "exile_assets\texture\ui\xm8_app_settings_ca.paa";
    text = "Настройка Статус бар";
    onButtonClick = "['ExAd_SB', 0] call ExileClient_gui_xm8_slide";
    resource = "";
};
class XM8_App10_Button: RscExileXM8AppButton1x1
{
    textureNoShortcut = "\a3\Ui_f\data\GUI\Cfg\CommunicationMenu\supplydrop_ca.paa";
    text = "АирДроп";
    onButtonClick = "['ExAd_APOC_Airdrop', 0] call ExileClient_gui_xm8_slide";
    resource = "";
};
class XM8_App11_Button: RscExileXM8AppButton1x1
{
    textureNoShortcut = "ExadClient\XM8\Apps\JX\logo.paa";
    text = "Scanner/Сканер";
    onButtonClick = "['ExAd_JX', 0] call ExileClient_gui_xm8_slide";
    resource = "ExAd_JX";
};
class XM8_App12_Button: RscExileXM8AppButton1x1
{
    textureNoShortcut = "Custom\images\mrzr4.paa";
    text = "Собрать MRZR4";
    onButtonClick = "['ExAd_MRZR4'] call ExAd_XM8_DV_fnc_spawnVehicle";
    resource = "";
};
class XM8_App13_Button: RscExileXM8AppButton1x1
{
    textureNoShortcut = "Custom\images\Air.paa";
    text = "Собрать Вертолет";
    onButtonClick = "['ExAd_Air'] call ExAd_XM8_DV_fnc_spawnVehicle";
    resource = "";
};
class XM8_App14_Button: RscExileXM8AppButton1x1
{
    textureNoShortcut = "Custom\images\waterscooter.paa";
    text = "Собрать Гидроцикл";
    onButtonClick = "['ExAd_WaterScooter'] call ExAd_XM8_DV_fnc_spawnVehicle";
    resource = "";
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//											   BELOW IS WHERE ALL THE XM8 APP RESOURCES CAN GO
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class XM8SlideSettings: RscExileXM8Slide 
{
	idc = 4070;
	class Controls 
	{
		class GoBackButton: RscExileXM8ButtonMenu
		{
			idc = 4071;
			text = "НАЗАД"; 
			x = (30 - 3) * (0.025);
			y = (19 - 2) * (0.04);
			w = 6 * (0.025);
			h = 1 * (0.04);
			onButtonClick = "['extraApps', 1] call ExileClient_gui_xm8_slide";
		};

		class 8GDropDown: RscExileXM8Combo
		{
			idc = 4072;
			x = (5 - 3) * (0.025);
			y = (5 - 2) * (0.04);
			w = 7 * (0.025);
			h = 1 * (0.04);
			onLBSelChanged = "_this call ExileClient_gui_xm8_slide_settings_event_on8GSelectionChanged";
		};

		class 8GLabel: RscExileXM8Text
		{
			idc = -1;
			text = "Показывать мое устройство в глобальной сети 8G.";
			x = (13 - 3) * (0.025);
			y = (5 - 2) * (0.04);
			w = 22 * (0.025);
			h = 1 * (0.04);
			shadow = 0;
		};

		class SoundDropDown: RscExileXM8Combo
		{
			idc = 4075;
			x = (5 - 3) * (0.025);
			y = (7 - 2) * (0.04);
			w = 7 * (0.025);
			h = 1 * (0.04);
			onLBSelChanged = "_this call ExileClient_gui_xm8_slide_settings_event_onSoundSelectionChanged";
		};

		class SoundLabel: RscExileXM8Text
		{
			idc = -1;
			text = "Звуковой сигнал при оповещениях."; 
			x = (13 - 3) * (0.025);
			y = (7 - 2) * (0.04);
			w = 22 * (0.025);
			h = 1 * (0.04);
			shadow = 0;
		};

		class PartyEspDropDown: RscExileXM8Combo
		{
			idc = 4076;
			x = (5 - 3) * (0.025);
			y = (9 - 2) * (0.04);
			w = 7 * (0.025);
			h = 1 * (0.04);
			onLBSelChanged = "_this call ExileClient_gui_xm8_slide_settings_event_onPartyEspSelectionChanged";
		};

		class PartyEspLabel: RscExileXM8Text
		{
			idc = -1;
			text = "Цвет 3D значков сторон и тегов имен."; 
			x = (13 - 3) * (0.025);
			y = (9 - 2) * (0.04);
			w = 22 * (0.025);
			h = 1 * (0.04);
			shadow = 0;
		};

		class PartyEspSlider: RscExileXM8XSliderH
		{
			idc = 4078;
			x = (5 - 3) * (0.025);
			y = (11 - 2) * (0.04);
			w = 7 * (0.025);
			h = 1 * (0.04);
			onSliderPosChanged = "_this call ExileClient_gui_xm8_slide_settings_event_onPartyEspSliderChanged";
		};

		class PartyEspSliderLabel: RscExileXM8Text
		{
			idc = -1;
			text = "Прозрачность 3D значков и тегов имен."; 
			x = (13 - 3) * (0.025);
			y = (11 - 2) * (0.04);
			w = 22 * (0.025);
			h = 1 * (0.04);
			shadow = 0;
		};

		class PartyMarkerSlider: RscExileXM8XSliderH
		{
			idc = 4079;
			x = (5 - 3) * (0.025);
			y = (13 - 2) * (0.04);
			w = 7 * (0.025);
			h = 1 * (0.04);
			onSliderPosChanged = "_this call ExileClient_gui_xm8_slide_settings_event_onPartyMarkerSliderChanged";
		};

		class PartyMarkerSliderLabel: RscExileXM8Text
		{
			idc = -1;
			text = "Прозрачность 3D маркеров."; 
			x = (13 - 3) * (0.025);
			y = (13 - 2) * (0.04);
			w = 22 * (0.025);
			h = 1 * (0.04);
			shadow = 0;
		};

		class StreamModeDropDown: RscExileXM8Combo
		{
			idc = 4077;
			x = (5 - 3) * (0.025);
			y = (15 - 2) * (0.04);
			w = 7 * (0.025);
			h = 1 * (0.04);
			onLBSelChanged = "_this call ExileClient_gui_xm8_slide_settings_event_onStreamModeSelectionChanged";
		};

		class StreamModeLabel: RscExileXM8Text
		{
			idc = -1;
			text = "Скрыть PIN-код. Идеально подходит для стримеров.";
			x = (13 - 3) * (0.025);
			y = (15 - 2) * (0.04);
			w = 22 * (0.025);
			h = 1 * (0.04);
			shadow = 0;
		};
	};
};

class XM8SlideHealthScanner: RscExileXM8Slide
{
	idc = 4120;
	class Controls 
	{
		class GoBackButton: RscExileXM8ButtonMenu
		{
			idc = 4122;
			text = "НАЗАД"; 
			x = (30 - 3) * (0.025);
			y = (19 - 2) * (0.04);
			w = 6 * (0.025);
			h = 1 * (0.04);
			onButtonClick = "['extraApps', 1] call ExileClient_gui_xm8_slide";
		};

		class HealthInfoControlGroup: RscExileXM8ControlsGroupNoHScrollbars
		{
			idc = -1;
			x = (5 - 3) * (0.025);
			y = (5 - 2) * (0.04);
			w = 30 * (0.025);
			h = 15 * (0.04);
			colorBackground[] = {0,0,0,0.25};

			class controls
			{
				class HealthInfo: RscExileXM8StructuredText
				{
					idc = 4121;
					x = 0;
					y = 0;
					w = 29 * (0.025); // minus 1!
					h = 15 * (0.04);
				};
			};
		};
	};
};

class XM8SlideSlothMachine: RscExileXM8Slide
{
	idc = 4140;
	class Controls 
	{
		class Background: RscExileXM8PictureKeepAspect
		{
			idc = -1;
			text = "\exile_assets\texture\ui\slothMachine\xm8_slothMachineBackground.paa";
			x = -3.1 * (0.025) + (0);
			y = -6 * (0.04) + (0);
			w = 40 * (0.025);
			h = 33 * (0.04);
		};
		
		class XM8SlothMachineSpinButton: RscExileXM8PictureButton
		{
			idc = 4141;
			style = 0x30;
			x = 14.3 * (0.025) + (0);
			y = 15.9 * (0.04) + (0);
			w = 5.7 * (0.025);
			h = 2 * (0.04);
			text = "\exile_assets\texture\ui\slothMachine\button_off_ca.paa";
			action = "[] call ExileClient_gui_xm8_slide_slothMachine_event_onSpinButtonClick;";
		};
		
		class GoBackButton: RscExileXM8ButtonMenu
		{
			idc = 4148;
			text = "НАЗАД"; 
			x = (30 - 3) * (0.025);
			y = (19 - 2) * (0.04);
			w = 6 * (0.025);
			h = 1 * (0.04);
			sizeEx = .9 * (0.04);
			onButtonClick = "['extraApps', 1] call ExileClient_gui_xm8_slide";
		};
		
		class PopTabsLabel: RscExileXM8StructuredText
		{
			idc = 4142;
			text = "<t align='center'><t color='#e14141'><img image='\exile_assets\texture\ui\poptab_inline_ca.paa' size='1' shadow='true' /></t>";
			x = 6.5 * (0.025) + (0);
			y = 13 * (0.04) + (0);
			w = 6 * (0.025);
			h = 2 * (0.04);
		};
		
		class JackpotLabel: RscExileXM8StructuredText
		{
			idc = 4143;
			text = "<t align='center'><t color='#e14141'></t>";
			x = 14 * (0.025) + (0);
			y = 13 * (0.04) + (0);
			w = 6 * (0.025);
			h = 2 * (0.04);
		};
		
		class WinningsLabel: RscExileXM8StructuredText
		{
			idc = 4144;
			text = "<t align='center'><t color='#e14141'>0</t>";
			x = 21.5 * (0.025) + (0);
			y = 13 * (0.04) + (0);
			w = 6 * (0.025);
			h = 2 * (0.04);
		};
		
		class Symbol01: RscExileXM8PictureKeepAspect
		{
			idc = 4145;
			text = "";
			x = 6.55 * (0.025) + (0);
			y = 4 * (0.04) + (0);
			w = 5.83 * (0.025);
			h = 5 * (0.04);
		};
		
		class Symbol02: RscExileXM8PictureKeepAspect
		{
			idc = 4146;
			text = "";
			x = 14.1 * (0.025) + (0);
			y = 4 * (0.04) + (0);
			w = 5.83 * (0.025);
			h = 5 * (0.04);
		};
		
		class Symbol03: RscExileXM8PictureKeepAspect
		{
			idc = 4147;
			text = "";
			x = 21.6 * (0.025) + (0);
			y = 4 * (0.04) + (0);
			w = 5.83 * (0.025);
			h = 5 * (0.04);
		};
	};
};