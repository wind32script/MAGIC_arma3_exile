class CfgServerInfoMenu
{
   addAction = 0; // Enable/disable action menu item | use 0 to disable | default: 1 (enabled)
   antiHACK = "infiSTAR - BattlEye";
   hostedBy = "";
   ipPort = "62.171.129.60:2302";
   openKey = "User6"; // https://community.bistudio.com/wiki/inputAction/actions
   openAtLogin = no;
   restart = 4; // Amount of hours before server automatically restarts
   serverName = "[PvE]MAGIC|Exile RU-EU|";
   class menuItems
   {
      // title AND content accept formatted text ( since update Oct5.2016 )
      class first
      {
         menuName = "ГЛАВНАЯ";
         title = "<t color='#ffffff'>ГЛАВНАЯ ИНФОРМАЦИЯ</t>";
         content[] = {
            "<t size='1.25'>Сервер: [PvE]MAGIC|Exile RU-EU|<br />","<t size='1.25'>ID: 62.171.129.60 Порт: 2302<br />","<t size='1.25'>Discord:<br />","<t size='1.25'>https://discord.gg/EhTCyzswKJ<br />"
         };
      };
      class second
      {
         menuName = "ПРАВИЛА";
         title = "ПРАВИЛА СЕРВЕРА";
         content[] = {
            "<t size='1.25'>Общие правила:</t><br />1 Играя на сервере вы автоматически соглашаетесь со всеми нижеприведёнными правилами и обязуетесь их выполнять.<br />2 Правила должны соблюдать ВСЕ игроки нашего сервера.<br />3 Администрация в праве изменять и дополнять текущие правила сервера без дополнительной информации участников сообщества.<br />4 Игроки периодически обязаны проверять правила на наличие изменений.<br />5 Незнание правил не освобождает вас от ответственности.<br />6 Запрещена необоснованная смена ника.<br />7 Запрещается использовать оскорбительные, матерные ники, приставки (admin, moder, apple, vip) Наказание: кик/бан.<br />8 Запрещается использовать ники с рекламой сторонних сайтов и серверов. Наказание:кик/бан<br />9 Запрещено рекламировать чужие сервера (писать названия и ip) без согласия гл.администратора сервера.Бан перманентный!<br />10 Действия администрации не подлежат критике или обсуждению.<br />11 В группе и чате сервера запрещён любой вид троллинга (спам).Наказание-от кика до бана.<br />12 Играя на сервере вы соглашаетесь со всеми багами игры. Администрация, за пропажу лута, из-за отката или бага ответственность не несет.<br />13 Просьбы о ТП, спавне оружия/техники/инвентаря не рассматриваются админами сервера.<br />14 Запрещено использование любых читерских программ, скриптов и багов, дающих преимущество над другими игроками.<br />15 Запрещено оскорблять игроков<br />16 Запрещено расизм и нацизм в любых проявлениях<br />17 Запрещено подстрекать, либо провоцировать других игроков на нарушение правил.<br />18 Запрещено говорить в синий чат. Нарушение будет караться киком с сервера.<br />19 Сервер является PvE. Убийство других игроков карается баном.<br />",
            "<t size='1.25'>Постройка баз:</t><br />20 Запрещена постройка баз в радиусе 1500 метров от Торгового города.<br />21 Запрещена постройка баз в радиусе 500 метров от Точек респавна.<br />22 Запрещена постройка баз в радиусе 400 метров от Городов (в городах, деревнях).<br />23 Запрещена постройка баз в радиусе 400 метров от баз других игроков.<br />24 Запрещена застройка лутабельных объектов (заправки, ангары , дома и т.д.).<br />25  Запрещена застройка на военных объектах (во всех).<br />26 Разрешено одному игроку (клану) установка (постройка) одной базы.<br />27 Запрещена любая постройка на дорогах,загораживать проезд.<br />28 Запрещена постройка воздухе то есть если объект установлен воздухе без фундамента.<br />29 Запрещено постройка баз в радиусе 1500 метров от статичных миссиях(статичные миссии всегда на одних и тех же местах и имеет численность ботов от ~25шт.)<br />30 Купленная территория автоматически удаляется вместе с постройками и виртуальным гаражом через 14 дней, если игрок вовремя ее не оплатил.<br />",
			"<t size='1.25'>Техника игроков:</t><br />31 Запрещено воровать, взрывать, садиться, смотреть лут внутри и проводить другие действия с техникой других игроков без их ведома и согласия.<br />32 Запрещено оставлять свою технику на трейд-зоне и в радиусе ближе, чем 2000 метров от них. В противном случае она будет выставлена на аукцион без выдачи компенсации.<br />33 Техника не используемая автоматически удаляется через 3 дня.<br />34 Запрещено артиллерии или миномётом стрелять по городам!<br />35 Запрещено артиллерии или миномётом стрелять минами кассетами!<br />36 Запрещено артиллерии или миномётом стрелять по трейд зонам и по базам игрокам!<br />37 Если вы собрались чистить (выполнять) миссию из артиллерии или миномётом. Обязательно пишем с начало чат что вы будет работать с артиллерии или миномётом названия миссии и метку на карте Работает артиллерия или миномёт (перед названием миссии)<br />38 Вся техника которая не стоит виртуальном гараже на базе или в трейд-зонах, переносится на распродажу MarXet каждую неделю! Без выдачи компенсации!<br />",
			"<t size='1.25'>Маркеры:</t><br />39 Все игроки без исключений обязаны перед захватом какой либо миссии написать в синий чат об этом (занял миссию /название миссии/), а затем поставить маркер на ней с указанием своего игрового никнейма на карте в дополнительный (синий) канал. <br />40 Запрещено удалять намерено метки игроков которые ранее заняли миссию.<br />41 Если игрок/игроки хочет присоединиться к выполнению миссии он/они должен получить на это согласие игрока/игроков, занявших данную миссию.<br />42 Одной группе (клану) или игроку, играющей вместе разрешается выполнять только ОДНУ миссию! И только после её полного завершения(когда напишете что миссия завершена) разрешается взять следующую. Примечания: Если вы не состоите группе (клане) и играете вместе правила эти также касается!<br /><br />42 Если на карте две миссии 300-400 метров.то игроку/игрокам/группе(клану) можно занять их оба сразу.<br />43 Заняв миссию, игрок/группа игроков должны приступить к ее выполнению не позднее 10мин. с момента установки маркёра на миссии.<br />44 Если вы ставите мину и уходите не дождавшись подрыва ее-указывайте ее меткой в синий чат на карте!<br />0"
         };
      };
      /*class third
      {
         menuName = "REGULATIONS";
         title = "SERVER RULES";
         content[] = {"<t size='1.25'>1 General rule:</t><br />1.1 By playing on the server, you automatically agree to all of the following rules and agree to comply with them.<br />1.2 Rules must abide by ALL players of our server.<br />1.5 Ignorance of the rules does not exempt you from liability.<br />1.10 actions of the administration are not subject to criticism or debate.<br />1.5 The administration has the right to change and Supplement the current rules of the server without additional information of community members.<br />1.6 Players are required to check the rules periodically for changes.<br />1.7 The actions of the administration are not subject to criticism or discussion.<br />1.8 Prohibited unsubstantiated nick change.<br />1.9 It is forbidden to use offensive, abusive nicknames, prefixes (admin,moder,apple,vip)<br />1.10 It is forbidden to use nicknames with advertising of third-party sites and servers.<br />1.11 It is forbidden to advertise other people's servers without the consent of the main server administrator.<br />1.12 In chat server banned any kind of trolling (spam).<br />1.13 No foul language!<br />1.14 Prohibited from racism and Nazism in any manifestations (ban permanent).<br />1.15 It is forbidden to speak in blue chat. Violation will be punished by kick from the server.<br />1.16 It is forbidden to use any cheat programs, scripts and bugs that give an advantage over other players.<br />1.17 Administration, due to the rollback or bug,error, fashion and game engine not be held responsible.<br />1.18 It is forbidden to write to the administration with requests and complaints in PM in social networks,incentive, etc., etc.<br />1.19 The administration of the server does not owe anything to anyone and is not obliged to be on the server 24/7 to solve Your game problems and disputes.<br />1.20 The administration has the right to decide on the punishment for a particular action,as well as to make a decision to change these Rules.<br />",
            "<t size='1.25'>2 The construction of bases of:</t><br />2.1 It is forbidden to build bases within a radius of 1500 meters from the Commercial city.<br />2.2 It is forbidden to build bases within a radius of 500 meters from the points of respawn.<br />2.3 It is forbidden to build bases within a radius of 400 meters from Cities (in cities, villages).<br />2.4 It is forbidden to build bases within a radius of 400 meters from the bases of other players.<br />2.5 Prohibited construction lucabella objects (gas stations, hangars , houses, etc.).<br />2.6 It is forbidden to build on military facilities (in all).<br />2.7 Allowed one player (clan) installation (construction) of a database.<br />2.8 Prohibited any construction on the roads,block the passage.<br />2.9 It is forbidden to build the air that is, if the object is installed in the air without a Foundation.<br />2.10 Prohibited the construction of bases within a radius of 1500 meters from static missions(static always on the same places and has the number of bots from ~25pcs.)<br />2.11 The purchased area is automatically deleted along with the buildings and the virtual garage after 14 days, if the player does not pay for it on time.<br />",
			"<t size='1.25'>3 Transport players:</t><br />3.1 It is forbidden to steal, blow up, sit down, watch loot inside and carry out other actions with the transport of other players without their knowledge and consent.<br />3.2 It is forbidden to leave your vehicles on the trade zone and within a radius closer than 2000 meters from them. Otherwise, it will be auctioned without compensation.<br />3.3 Transport not in use is automatically deleted after 3 days.<br />3.4 Prohibited artillery or mortar fire on the city!<br />3.5 Prohibited from artillery or mortar to shoot mines cassettes!<br />3.6 Prohibited artillery or a mortar to shoot for a trade zone and at the bases of the players!<br />3.7 If you are going to clean (perform) the mission of artillery or mortar. Be sure to write in the beginning of the chat that you will work with artillery or mortar mission name and mark on the map the artillery or the mortar (before the name of the mission)<br />3.8 Prohibited artillery or mortar fire on static missions!<br />3.9 it is Forbidden to clean (run) static mission combat helicopters and planes! Violator of the penalty under paragraph 3.8 of the rules<br /><br />3.10 All equipment that is not a virtual garage on the basis of or in the trade zones, is transferred to the sale MarXet every week! Without issuing a refund.<br />",
			"<t size='1.25'>4. Markers:</t><br />4.1 All players without exception are obliged to take any mission to write in blue chat about it (took a mission /name of mission/) and then put a marker on it, indicating your game nickname on the map in the additional (blue) channel.<br />4.2 It is forbidden to remove the label intends players who had previously occupied the mission.<br />4.3 If a player/players wants to join the mission he/they must obtain the consent of the player/players who have completed the mission.<br />4.4 One group (clan) or player playing together is allowed to perform only ONE mission! And only after its full completion(when you write that the mission is completed) is permitted to take following. Note: If you are not a member of a group (clan) and play along these rules also apply!<br />4.5 Finishing the mission, the player/group of players must begin its run no later than 10 min after installing the token on a mission.<br /><br />4.6 If the map two missions 300-400 meters. the player/players/team (clan) you can take them both at once. Notes: if you took a static mission and there is still a regular mission of 300-400 meters, then the usual mission is prohibited to work artillery or mortar!<br />4.7 If you put a minus, and leave without waiting for undermining her please tag her in the blue chat on the map!<br /> Full server rules in VK and Discord group<br />"};
      };*/
      /*class fourth
      {
         menuName = "РУКОВОДСТВО";
         title = "РУКОВОДСТВО ПОЛЬЗОВАТЕЛЯ";
         content[] = {""};
      };*/
      /*class fifth
      {
         menuName = "СКРИПТЫ";
         title = "ЧТО ЕСТЬ НА СЕРВЕРЕ:";
         content[] = {""};
      };*/
      class seventh
      {
         menuName = "ДОНАТ";
         title = "ДОНАТ";
         content[] = {
            "<t size='1.25'>Детали можете узнать в ЛС дискорда MAGIC#3214</t>",
            "<br />",
            "<t size='1.25'>MAGIC Exile PvE</t>"
         };
      };
   };
};
